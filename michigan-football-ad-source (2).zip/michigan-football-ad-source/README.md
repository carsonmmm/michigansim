# Michigan Football: source and tests

The game ships as one self-contained file, `michigan-football-ad.html`. That file is built from the modules in `src/`. It opens on a home screen with two modes: AD Mode (run Michigan's athletic department) and Player Career (one player from high school to the NFL Draft).

## Layout

| File | Role |
|---|---|
| `src/data.js` | League data (138 FBS programs, the 2026 roster and schedule, constants) and the seeded random generator |
| `src/core.js` | Game simulation, weekly flow, polls, postseason, finance levers |
| `src/features.js` | Events, recruiting, offseason steps, save migration from older versions |
| `src/systems.js` | Season systems: coaching carousel, deals, board meeting, compliance, Auto-AD |
| `src/storage.js` | Save slots, the save queue, loading and validating saves, save codes |
| `src/career.js` | Player Career engine: the player, stars and recruiting, NIL, the 138-team league season, college, transfer portal, draft, saving |
| `src/cgame.js` | Player Career games: drives, position-by-position snap decisions, stat lines and grades |
| `src/theme.js` | Per-device display settings: theme, light/dark mode, sidebar or top tabs, animations, text size |
| `src/ui.js` | Views, dialogs, the live game, Settings |
| `src/admin.js` | Admin panel view |
| `src/cui.js` | Home screen and every Player Career screen, including the game dialog |
| `src/app.js` | AD actions, click and keyboard handling, multi-season sim |
| `src/capp.js` | Home screen and Player Career actions, startup |
| `src/shell.html` | Markup and styles for all five themes; `build.py` inserts the scripts here |

The engine files (`data`, `core`, `features`, `systems`, `career`, `cgame`) never touch the page. The engine tests rely on this: they run those files in Node with no browser.

## Build

```
python3 build.py            # writes michigan-football-ad.html
```

## Tests

```
node tests/engine.test.js                                     # AD engine + storage, about 15 s
node tests/career.test.js                                     # Player Career engine: full careers, balance, NIL, portal, draft, about 10 s
NODE_PATH=$(npm root -g) node tests/browser.test.js michigan-football-ad.html   # full interface in headless Chromium, about 1 min
NODE_PATH=$(npm root -g) node tests/career.browser.test.js michigan-football-ad.html  # home screen and Player Career in headless Chromium
NODE_PATH=$(npm root -g) node tests/repro_browser.js michigan-football-ad.html  # the original bug reproductions
```

- The browser tests need Playwright with Chromium.
- `tests/fixtures/` holds saved games from every earlier version (v1, v2, v2 offseason, v3, v3 custom program). The tests load each fixture and check that it keeps playing.
- You can point `engine.test.js` at an older source folder. It shows which checks failed before the fixes.

## Saves

- AD Mode and Player Career each have five save slots in browser storage (`mfad-slot-N` and `mfpc-slot-N`). Neither mode touches the other's slots.
- Player Career rosters are rebuilt from the career's seed, so saves stay small.

## Reproducing a run

- A new career accepts an optional seed: Save file → New career → Advanced.
- The admin panel can reseed a running career: Admin → Game settings.
- Each save stores its random position, so the same save plus the same choices gives the same results.
