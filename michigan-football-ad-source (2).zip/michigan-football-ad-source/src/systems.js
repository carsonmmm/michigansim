/* ===================== SEASON SYSTEMS ===================== */
function oppOf(g) { return g.h === 'MICH' ? g.a : g.h; }
function econ() { if (!state.me) return 1; const c = CONFS[T('MICH').conf]; return c.p4 ? 0.85 : T('MICH').conf === 'IND' ? 0.6 : 0.3; }
const capacity = () => (state.me && state.me.cap) || STADIUM_CAP;
const rosterLimit = () => ROSTER_LIMIT - (state.schRed && state.schRed.s === state.season + 1 ? state.schRed.n : 0) - (state.schRed && state.schRed.s === state.season && state.phase !== 'offseason' ? state.schRed.n : 0);
const CUSTOM_FAC = { stadium: null, building: 'Football operations building', indoor: 'Indoor practice facility', weight: 'Strength & conditioning', med: 'Sports medicine & recovery', academic: 'Player development center' };
function facName(id) { if (state.me) return id === 'stadium' ? state.me.stadium : CUSTOM_FAC[id]; return FAC_DEFS.find(f => f.id === id).name; }
function clsLabel(p) { return (p.rsUsed ? 'RS ' : '') + p.cls; }

/* ---------- personalities & captains ---------- */
function rollPers(real) {
  const r = R();
  if (real) return r < 0.1 ? 'leader' : r < 0.28 ? 'worker' : r < 0.38 ? 'clutch' : 'steady';
  return r < 0.08 ? 'leader' : r < 0.22 ? 'worker' : r < 0.3 ? 'clutch' : r < 0.36 ? 'diva' : r < 0.42 ? 'fragile' : 'steady';
}
function clutchCount() { let n = 0; ['QB', 'RB', 'WR'].forEach(pos => starters(pos).forEach(p => { if (p.pers === 'clutch') n++; })); return n; }
function captainsList() { return (state.captains || []).map(P).filter(Boolean); }
function autoCaptains() {
  const pool = state.roster.filter(p => ['Sr', 'Gr', 'Jr'].includes(p.cls) && state.depth[p.pos].indexOf(p.id) < START[p.pos]);
  pool.sort((a, b) => ((b.pers === 'leader') * 20 + b.ovr + CLASSES.indexOf(b.cls) * 2) - ((a.pers === 'leader') * 20 + a.ovr + CLASSES.indexOf(a.cls) * 2));
  const off = pool.filter(p => ['QB', 'RB', 'WR', 'TE', 'OL'].includes(p.pos)).slice(0, 2), def = pool.filter(p => ['DE', 'DT', 'LB', 'CB', 'S'].includes(p.pos)).slice(0, 2);
  state.captains = off.concat(def).map(p => p.id);
}
function leadership() { return captainsList().reduce((s, p) => s + (p.pers === 'leader' ? 3 : 1) + (['Sr', 'Gr'].includes(p.cls) ? 0.5 : 0), 0); }
function weeklyTeam(mg) {
  if (state.phase === 'offseason') return;
  let d = (leadership() - 5) * 0.25;
  let divas = 0, leaders = 0;
  state.roster.forEach(p => { const idx = state.depth[p.pos].indexOf(p.id); if (p.pers === 'diva' && p.ovr >= 74 && idx >= START[p.pos]) divas++; if (p.pers === 'leader' && idx < START[p.pos] && avail(p)) leaders++; });
  d += Math.min(1.5, leaders * 0.3) - Math.min(2, divas * 0.5);
  state.meters.morale = clamp(Math.round((state.meters.morale + d) * 10) / 10, 0, 100);
  state.meters.morale = Math.round(state.meters.morale);
  if (state.practice === 'youth') state.roster.forEach(p => { if (['Fr', 'So'].includes(p.cls) && state.depth[p.pos].indexOf(p.id) >= START[p.pos]) p.xp = (p.xp || 0) + 1; });
  // compliance drift
  const b = annualBudget(); let risk = 0;
  if (b.niltop > 5) risk += 0.8; if (state.fin.recruit > 7) risk += 0.5; risk -= ((state.fin.compliance == null ? 1 : state.fin.compliance) - 1) * 0.5;
  state.meters.risk = clamp(Math.round((state.meters.risk + risk) * 10) / 10, 0, 100);
}

/* ---------- play calling ---------- */
function startPlayDrive(sim, s, qtr, clock, ot) {
  const start = ot ? 75 : clamp(25 + Math.round((sim.shortField[s] || 0) * 60), 20, 60); sim.shortField[s] = 0;
  sim.pending = { type: 'drive', s, qtr, clock, ot, ds: { yl: start, start, down: 1, togo: 10, plays: [], log: [], calls: [] } };
}
function playModel(sim) {
  const mu = michUnits(); const o = isFCS(sim.oppId) ? { runD: strength(sim.oppId).def, passD: strength(sim.oppId).def } : oppUnits(sim.oppId);
  const W = WX[sim.wx.k] || {};
  const qb = starters('QB')[0]; const rb = starters('RB')[0];
  return { runA: (mu.run - o.runD) / 10 + (W.run || 0) * 0.3, passA: (mu.pass - o.passD) / 10 + (W.pass || 0) * 0.35, acc: (qb && qb.tr && qb.tr.acc) || 60, arm: (qb && qb.tr && qb.tr.arm) || 60, spd: (rb && rb.tr && rb.tr.spd) || 70 };
}
function playHints(sim) {
  const m = playModel(sim);
  return { inside: `~${(3.4 + m.runA * 1.4).toFixed(1)} yds`, outside: `~${(3.8 + m.runA * 1.3 + (m.spd - 75) * 0.05).toFixed(1)} yds, boom or bust`, short: `${Math.round(clamp(0.67 + (m.acc - 75) * 0.006 + m.passA * 0.04, 0.4, 0.85) * 100)}% catch, ~6 yds`, deep: `${Math.round(clamp(0.36 + (m.arm - 75) * 0.006 + m.passA * 0.05, 0.15, 0.6) * 100)}% catch, 18+ yds, risky`, screen: 'Safe, sometimes breaks big' };
}
function runPlay(sim, call) {
  const p = sim.pending; if (!p || p.type !== 'drive') return;
  const ds = p.ds; const m = playModel(sim); const ctx = sim.ctx;
  const rep = ds.calls.slice(-2).filter(c => c === call).length; const pred = rep * 1.2;
  const clutch = (p.qtr >= 4 || p.ot) ? sim.clutch * 0.5 : 0;
  const rbs = starters('RB', 2), wrs = starters('WR', 3), tes = starters('TE', 1);
  let pl = { pass: false, comp: false, y: 0 }; let txt = '';
  const nm = x => x ? x.n : 'The runner';
  if (call === 'inside' || call === 'outside') {
    const who = call === 'outside' && R() < 0.15 && ctx.qb ? ctx.qb : R() < 0.85 ? rbs[0] : (rbs[1] || rbs[0]);
    let y = call === 'inside' ? Math.round(3.4 + m.runA * 1.4 + gauss() * 2.6 - pred + clutch + (ds.togo <= 2 ? 1 : 0)) : Math.round(3.8 + m.runA * 1.3 + (m.spd - 75) * 0.05 + gauss() * 4.2 - pred + clutch);
    if (R() < (call === 'inside' ? 0.035 : 0.06) + m.runA * 0.01) y += ri(12, 45);
    pl = { pass: false, comp: true, y, who };
    if (R() < 0.012) { pl.fum = true; pl.comp = false; txt = `${CALLS[call]}: ${nm(who)} fumbles! ${teamName(sim.oppId)} recovers.`; }
    else txt = `${CALLS[call]}: ${nm(who)} ${y >= 0 ? 'for ' + y : 'loses ' + -y} yard${Math.abs(y) === 1 ? '' : 's'}.`;
  } else {
    const sackP = call === 'deep' ? 0.08 : call === 'short' ? 0.045 - m.passA * 0.01 : 0.02;
    const cp = call === 'deep' ? clamp(0.36 + (m.arm - 75) * 0.006 + m.passA * 0.05, 0.15, 0.6) : call === 'short' ? clamp(0.67 + (m.acc - 75) * 0.006 + m.passA * 0.04, 0.4, 0.85) : 0.82;
    const intP = call === 'deep' ? 0.055 : call === 'short' ? 0.015 : 0.01;
    const who = call === 'screen' ? (R() < 0.7 ? rbs[0] : wrs[2] || wrs[0]) : call === 'deep' ? (R() < 0.55 ? wrs[0] : wrs[1] || wrs[0]) : wpick(ctx.tg);
    if (R() < Math.max(0.01, sackP)) { const y = -ri(4, 9); pl = { pass: true, comp: false, sack: true, y: 0, ly: y }; txt = `${CALLS[call]}: ${ctx.qb ? ctx.qb.n : 'QB'} is sacked for a loss of ${-y}.`; pl.yl = y; }
    else if (R() < intP) { pl = { pass: true, comp: false, int: true, y: 0 }; txt = `${CALLS[call]}: intercepted! ${teamName(sim.oppId)} takes over.`; }
    else if (R() < cp + clutch * 0.02) {
      let y = call === 'deep' ? ri(16, 42) : call === 'short' ? Math.round(5.5 + m.passA + gauss() * 3.2 - pred + clutch) : Math.round(3 + m.runA * 0.8 + gauss() * 5 - pred);
      if (call !== 'deep' && R() < (call === 'screen' ? 0.05 : 0.04)) y += ri(10, 35);
      pl = { pass: true, comp: true, y, who }; txt = `${CALLS[call]}: ${ctx.qb ? ctx.qb.n : 'QB'} to ${nm(who)} for ${y} yard${Math.abs(y) === 1 ? '' : 's'}.`;
    } else { pl = { pass: true, comp: false, y: 0 }; txt = `${CALLS[call]}: incomplete${who ? ', intended for ' + who.n : ''}.`; }
  }
  ds.calls.push(call);
  const gain = pl.sack ? pl.yl : pl.y;
  ds.plays.push(pl);
  if (pl.int || pl.fum) { ds.log.push(txt); endPlayDrive(sim, 'to'); return; }
  ds.yl = Math.min(100, ds.yl + gain); ds.togo -= gain;
  if (ds.yl >= 100) { ds.log.push(txt + ' Touchdown!'); pl.y += 0; endPlayDrive(sim, 'td'); return; }
  if (ds.yl <= 0) { ds.yl = 1; }
  if (ds.togo <= 0) { ds.down = 1; ds.togo = Math.min(10, 100 - ds.yl); txt += ' First down.'; }
  else { ds.down++; if (ds.down > 4) { ds.log.push(txt + ' Turnover on downs.'); sim.shortField[1 - p.s] = clamp((ds.yl - 25) / 60, 0, 0.6); endPlayDrive(sim, 'downs'); return; } }
  ds.log.push(txt);
}
function fgRange(ds) { return 117 - ds.yl <= 60; }
function kickFromDrive(sim, kind) {
  const p = sim.pending; if (!p || p.type !== 'drive') return; const ds = p.ds;
  if (kind === 'fg') { p.fgDist = 117 - ds.yl; ds.log.push(`Field goal try from ${p.fgDist} yards.`); endPlayDrive(sim, 'fg'); }
  else { ds.log.push('Punt.'); endPlayDrive(sim, 'punt'); }
}
function endPlayDrive(sim, out) {
  const p = sim.pending; sim.pending = null; const ds = p.ds;
  if (!ds.plays.length) ds.plays.push({ pass: false, comp: true, y: 0, who: starters('RB')[0] });
  const drv = { s: p.s, qtr: p.qtr, clock: p.clock, ot: p.ot, out, yards: Math.max(0, ds.yl - ds.start), plays: ds.plays, fgDist: p.fgDist, pr: { d: 0 }, called: ds.log.slice() };
  sim.lastCalled = ds.log.slice();
  execDrive(sim, drv);
}

/* ---------- press conferences ---------- */
function maybePresser(g) {
  if (state.event) return;
  const opp = g.h === 'MICH' ? g.a : g.h; const win = g.mResult === 'W'; const ms = g.h === 'MICH' ? g.hs : g.as, os = g.h === 'MICH' ? g.as : g.hs;
  const big = g.oppRk || rivalOf(opp) || g.type !== 'reg' || !win || ms - os >= 28;
  if (!big || R() > 0.6) return;
  const o = teamName(opp);
  const q = win ? pick([`Reporter: "That was a statement against ${o}. Is this team a real contender?"`, `Reporter: "${ms}-${os}. What did you see out there today?"`, `Reporter: "Fans are fired up after beating ${o}. What's your message to them?"`])
    : pick([`Reporter: "Tough loss to ${o}. Is the program headed in the right direction?"`, `Reporter: "${os}-${ms}. Does the head coach still have your full support?"`, `Reporter: "Fans are frustrated after the ${o} game. What do you tell them?"`]);
  const next = mGames().find(x => !x.done && x !== g); const nextOpp = next ? oppOf(next) : null;
  const opts = win ? [
    { label: 'Stay humble', hint: 'Board +1, fans +1', fx: { board: 1, fan: 1 } },
    { label: 'Talk big', hint: 'Fans +3, locker room +2, board −1', fx: { fan: 3, morale: 2, board: -1 } },
    { label: 'Credit the players', hint: 'Locker room +3', fx: { morale: 3 } },
    ...(nextOpp && !isFCS(nextOpp) ? [{ label: `Send a message to ${teamName(nextOpp)}`, hint: 'Fans +2, but they will be fired up next week', fx: { fan: 2 }, bulletin: nextOpp }] : []),
  ] : [
    { label: 'Own it', hint: 'Board +1, locker room +1, fans −1', fx: { board: 1, morale: 1, fan: -1 } },
    { label: 'Blame the officials', hint: 'Fans +2, board −3, possible conference fine', fx: { fan: 2, board: -3 }, fine: true },
    { label: 'Back the head coach', hint: 'Hot seat −8; fans −2 if he is already on it', fx: { hot: -8, fan: state.meters.hot > 60 ? -2 : 0, morale: 1 } },
    { label: 'Call out the players', hint: 'Locker room −5, fans +1, hot seat −3', fx: { morale: -5, fan: 1, hot: -3 } },
  ];
  state.event = { key: 'presser', wk: state.week, title: 'Press conference', text: q, opts, data: {}, def: 0 };
}
function resolvePresser(i) {
  const ev = state.event; const o = ev.opts[i]; const fx = o.fx || {};
  Object.entries(fx).forEach(([k, v]) => { if (k === 'hot') state.meters.hot = clamp(state.meters.hot + v, 0, 100); else mv(k, v); });
  let msg = `You chose to ${o.label.toLowerCase()}.`;
  if (o.bulletin) { state.bulletin = o.bulletin; msg += ` ${teamName(o.bulletin)} put your quote on their bulletin board.`; }
  if (o.fine && R() < 0.4) { state.fin.balance -= 0.05; state.fin.ytd.eventx += 0.05; msg += ' The conference fined the department $50,000.'; }
  return msg;
}

/* ---------- contract negotiation ---------- */
function negOdds(c, o, ext) {
  const m = state.meters; const ask = ext ? c.salary * 1.12 : c.salary; const wantYrs = ext ? 3 : c.years;
  const prestige = 70 + (rankOf('MICH') ? 12 - rankOf('MICH') * 0.3 : 0) + (m.board - 60) * 0.1 + (facLvl('building') - 3) * 3;
  let p = ext ? 0.55 + (state.meters.morale - 60) / 200 : 0.5 + (prestige - coachOvr(c)) / 40;
  p += (o.sal / ask - 1) * 1.6 + (o.yrs - wantYrs) * 0.04 + (o.buy - 0.5) * 0.3 + (o.incConf ? 0.03 : 0) + (o.incCFP ? 0.04 : 0) - (c.fails || 0) * 0.15;
  return clamp(p, 0.02, 0.98);
}
function canExtend(c) { return !!c && !c.interim && c.extS !== state.season; }
function negotiateExt(role, o) {
  const c = state.staff[role]; if (!c || c.interim) return 'gone'; if (!canExtend(c)) return 'done';
  if (R() < negOdds(c, o, true)) { c.salary = r1(o.sal); c.years = o.yrs; c.buyPct = o.buy; c.inc = { conf: o.incConf ? r1(c.salary * 0.1) : 0, cfp: o.incCFP ? r1(c.salary * 0.15) : 0 }; c.fails = 0; c.extS = state.season; mv('morale', 2); if (role === 'HC') { if (state.meters.hot > 50) { mv('fan', -5); mv('boost', -4); } state.meters.hot = Math.max(5, state.meters.hot - 15); } addNews(`${c.name} signs a new deal: ${o.yrs} years at $${c.salary.toFixed(1)}M per year.`); return 'signed'; }
  c.fails = (c.fails || 0) + 1; if (c.fails >= 3) { c.fails = 0; state.hcUnhappy = role === 'HC' ? true : state.hcUnhappy; addNews(`Extension talks with ${c.name} broke down.`, 'bad'); return 'broke'; }
  return 'counter';
}

/* ---------- media & partner deals ---------- */
function dealOffers(d) {
  const mr = rankOf('MICH'); const base = DEAL_DEFS.find(x => x.id === d.id).amt * econ() * (0.85 + state.meters.fan / 250 + (mr ? (26 - mr) * 0.008 : -0.05));
  return [
    { k: 'short', label: 'Short deal', yrs: 3, amt: r1(base * 1.05), bonus: 0, perf: false, desc: 'Three years at a strong rate. Renegotiate soon.' },
    { k: 'long', label: 'Long deal', yrs: 8, amt: r1(base * 0.93), bonus: r1(base * 1.5), perf: false, desc: `Eight years, slightly less per year, plus a $${r1(base * 1.5)}M signing bonus now.` },
    { k: 'perf', label: 'Performance deal', yrs: 5, amt: r1(base * 0.8), bonus: 0, perf: true, desc: 'Five years at a lower base. +$1.5M for each playoff trip and +$0.5M for each 10-win season.' },
  ];
}
function signDeal(id, k) {
  const d = state.deals.find(x => x.id === id); if (!d || !dealOpen(d)) return; const o = dealOffers(d).find(x => x.k === k); if (!o) return;
  d.amt = o.amt; d.thru = state.season + o.yrs; d.perf = o.perf; d.kind = o.label;
  if (o.bonus) { state.fin.balance += o.bonus; state.fin.ytd.events += o.bonus; }
  addNews(`New ${d.name.toLowerCase()}: $${o.amt}M per year through ${d.thru}${o.bonus ? ` with a $${o.bonus}M signing bonus` : ''}.`);
}
const dealOpen = d => d.thru - state.season <= 1;

/* ---------- board meeting ---------- */
function boardApprove(base) { return clamp(base + (state.meters.board - 60) / 100 + (state.off && state.off.review && state.off.review.fin.net > 0 ? 0.12 : -0.12), 0.05, 0.95); }
function presentBoard(ch) {
  if (state.off && state.off.boardRes) return; // one meeting per offseason
  const res = [];
  if (ch.stance === 'invest') { if (R() < boardApprove(0.5)) { const before = state.fin.recruit; state.fin.recruit = r1(clamp(before + 1.5, 1, 10)); state.mediaBonus = state.mediaBonus || 0; res.push(state.fin.recruit > before ? `Approved: more money for recruiting (+$${r1(state.fin.recruit - before)}M).` : 'Approved, but the recruiting budget is already at the $10M maximum.'); } else { mv('board', -2); res.push('Rejected: the board would not raise football spending.'); } }
  else if (ch.stance === 'lean') { if (state.fin.recruit > 1) { state.fin.recruit = r1(clamp(state.fin.recruit - 1, 1, 10)); mv('board', 3); res.push('Approved: a leaner budget. The board appreciates the discipline.'); } else res.push('No change: the recruiting budget is already at the $1M minimum.'); }
  else res.push('Approved: a balanced budget.');
  if (ch.fac && ch.fac !== 'none') { const f = state.facilities.find(x => x.id === ch.fac); if (f && !f.building && f.lvl < 5) { if (R() < boardApprove(0.45)) { const c = facCost(f.lvl) * 0.5; state.fin.balance -= c; f.building = true; res.push(`Approved: the university pays half of the ${facName(f.id)} upgrade. You pay ${c.toFixed(1)}M.`); } else res.push(`Rejected: no university money for ${facName(f.id)} this year.`); } }
  if (ch.tix === 'raise') { if (state.fin.ticket >= LEVERS.ticket.max) res.push(`No change: tickets are already at the $${LEVERS.ticket.max} maximum.`); else if (R() < (state.meters.fan >= 55 ? 0.85 : 0.4)) { const d = Math.min(10, LEVERS.ticket.max - state.fin.ticket); state.fin.ticket += d; mv('fan', -Math.round(3 * d / 10)); res.push(`Approved: ticket prices go up $${d}.`); } else res.push('Rejected: no ticket increase.'); }
  else if (ch.tix === 'cut') { if (state.fin.ticket <= LEVERS.ticket.min) res.push(`No change: tickets are already at the $${LEVERS.ticket.min} minimum.`); else { const d = Math.min(10, state.fin.ticket - LEVERS.ticket.min); state.fin.ticket -= d; mv('fan', Math.round(3 * d / 10)); res.push(`Approved: ticket prices drop $${d}.`); } }
  const v = state.off.vote;
  if (v) { v.yes = ch.vote === 'yes'; v.passed = R() < (v.yes ? 0.85 : 0.25); res.push(v.passed ? `The conference approved adding ${v.teams.map(teamName).join(' and ')}. They join next season.` : `Expansion failed. ${v.teams.map(teamName).join(' and ')} stay put.`); }
  state.off.boardRes = res; res.forEach(r => addNews('Board meeting: ' + r));
}

/* ---------- compliance ---------- */
function extraContact(id) { const r = state.rec.list.find(x => x.id === id); if (!r || r.contact || r.status !== 'open') return; r.contact = true; r.interest = clamp(r.interest + 8, 1, 99); state.meters.risk = clamp(state.meters.risk + 3, 0, 100); }
function investigate() {
  const risk = state.meters.risk; const chance = risk / 200 * (1 - ((state.fin.compliance == null ? 1 : state.fin.compliance) - 1) * 0.15);
  let out = null;
  if (R() < chance) {
    if (risk < 40) { state.fin.balance -= 1; mv('board', -5); out = 'Minor violation: $1M fine.'; }
    else if (risk < 70) { state.fin.balance -= 2; state.schRed = { s: state.season + 1, n: 5 }; mv('board', -10); out = 'Level II violation: $2M fine and five fewer roster spots next season.'; }
    else { state.ban = state.season + 1; mv('board', -18); mv('fan', -8); const h = state.history[state.history.length - 1]; if (h) h.vacated = true; out = `Level I violation: a postseason ban for ${state.season + 1} and this season's wins are vacated.`; }
    state.investigations.push({ s: state.season, out }); addNews('NCAA investigation: ' + out, 'bad');
  }
  state.meters.risk = Math.round(risk * 0.6);
  return out;
}

/* ---------- league: realignment, carousel, national recruiting ---------- */
function expansionCandidates() { const me = T('MICH').conf; return Object.values(state.teams).filter(t => t.conf !== me && ['ACC', 'B12'].includes(t.conf) && t.id !== 'ND').sort((a, b) => b.rating - a.rating).slice(0, 2).map(t => t.id); }
function realign() {
  const moves = [];
  if (state.off && state.off.vote && state.off.vote.passed) { state.off.vote.teams.forEach(id => { moves.push([id, T(id).conf, T('MICH').conf]); T(id).conf = T('MICH').conf; }); state.mediaBonus = (state.mediaBonus || 0) + 3; }
  if (R() < 0.15) {
    const g6 = Object.values(state.teams).filter(t => !CONFS[t.conf].p4 && t.id !== 'ND' && t.id !== 'MICH' && t.rating >= 64).sort((a, b) => b.rating - a.rating)[0];
    if (g6) { const to = pick(['B12', 'ACC', 'P12'].filter(c => c !== g6.conf)); moves.push([g6.id, g6.conf, to]); g6.conf = to; }
  }
  if (moves.length) { rebuildConfs(); moves.forEach(([id, from, to]) => addNews(`Realignment: ${teamName(id)} moves from the ${CONFS[from].name} to the ${CONFS[to].name}.`, 'big')); state.confMoves = (state.confMoves || []).concat(moves.map(m => ({ s: state.season + 1, id: m[0], from: m[1], to: m[2] }))); }
}
function otherCarousel() {
  const changes = [];
  Object.values(state.teams).forEach(t => {
    if (t.id === 'MICH') return; const last = { w: t.w, l: t.l };
    const p4 = CONFS[t.conf].p4;
    if ((p4 && last.w <= 4 && R() < 0.55) || (!p4 && last.w <= 3 && R() < 0.4)) {
      const old = t.coach; t.coach = genName(); const bump = gauss() * 2.5; t.rating = r1(clamp(t.rating + bump, 38, 96)); t.off = r1(t.rating + gauss() * 2); t.def = r1(2 * t.rating - t.off);
      changes.push(`${t.name} fires ${old} and hires ${t.coach}.`);
    }
  });
  if (changes.length) { changes.slice(0, 5).forEach(c => addNews('Coaching carousel: ' + c)); if (changes.length > 5) addNews(`Coaching carousel: ${changes.length} programs changed head coaches this offseason.`); }
}
function nationalClasses(mine) {
  const rc = state.rec; const stolen = {};
  rc.list.forEach(r => { if (r.status === 'lost' && r.to && T(r.to)) stolen[r.to] = (stolen[r.to] || 0) + (r.star === 5 ? 100 : r.star === 4 ? 60 : 28) + r.pot * 0.2; });
  const rows = Object.values(state.teams).filter(t => t.id !== 'MICH').map(t => ({ id: t.id, sc: Math.round((t.rating - 40) * 26 + (CONFS[t.conf].p4 ? 260 : 0) + (t.elo - 1500) * 0.3 + gauss() * 110 + (stolen[t.id] || 0)) }));
  rows.push({ id: 'MICH', sc: Math.round(classScore(mine)) });
  rows.sort((a, b) => b.sc - a.sc);
  rows.forEach((r, i) => { T(r.id).classRank = i + 1; });
  rc.nat = rows.slice(0, 25);
  const mine2 = rows.findIndex(r => r.id === 'MICH') + 1; state.natClasses = { s: state.season, rows: rows.slice(0, 25), mine: mine2 };
  return mine2;
}

/* ---------- walk-ons ---------- */
function holdTryouts() {
  if (state.tryouts === state.season) return; state.tryouts = state.season; state.fin.balance -= 0.1;
  state.walkons = [];
  for (let i = 0; i < 6; i++) { const pos = pick(POS_ORDER); const gem = R() < 0.12; const b = genBody(pos); state.walkons.push({ id: 'w' + i + Math.floor(R() * 1e6), n: genName(), pos, ovr: ri(48, 64), pot: gem ? ri(84, 93) : ri(56, 78), gem, home: pick(TOWNS)[0], ht: b.ht, wt: b.wt }); }
}
function addWalkon(id) {
  const w = (state.walkons || []).find(x => x.id === id); if (!w || w.added) return 'gone'; if (state.roster.length >= rosterLimit()) return 'full';
  const p = makePlayer({ num: freeNumber(w.pos), n: w.n, pos: w.pos, cls: 'Fr', ht: w.ht, wt: w.wt, home: w.home, ovr: w.ovr, pot: w.pot, real: false, walkon: true, pay: 0 });
  state.roster.push(p); rebuildPMap(); state.depth[w.pos].push(p.id); w.added = true; addNews(`Walk-on ${w.n} (${w.pos}) joins the program after tryouts.`); return 'ok';
}
function awardScholarship(pid) { const p = P(pid); if (!p || !p.walkon) return; p.walkon = false; p.exWalkon = true; p.pay = Math.max(p.pay, 0.02); mv('morale', 1); addNews(`${p.n} is put on scholarship. The locker room erupts.`, 'win'); }

/* ---------- careers ---------- */
function recordCareers() {
  state.roster.forEach(p => { (p.hist = p.hist || []).push({ s: state.season, cls: clsLabel(p), pos: p.pos, ovr: p.ovr, gp: p.gp, st: Object.assign({}, p.st) }); });
}
function applyRedshirts() {
  state.roster.forEach(p => { if (!p.rsUsed && p.gp <= 4 && p.cls !== 'Gr') { p.rsUsed = true; p.rsThisYear = true; if (p.injSE) p.medRS = true; } });
}

/* ---------- season recap ---------- */
function buildRecap(delta) {
  const games = mGames().filter(g => g.done);
  const val = g => { const opp = oppOf(g); const e = T(opp) ? T(opp).elo : 1200; const mm = (g.h === 'MICH' ? g.hs - g.as : g.as - g.hs); return e + mm * 5; };
  const wins = games.filter(g => g.mResult === 'W'), losses = games.filter(g => g.mResult === 'L');
  const best = wins.sort((a, b) => val(b) - val(a))[0], worst = losses.sort((a, b) => val(a) - val(b))[0];
  const comeback = wins.filter(g => (g.minM || 0) <= -10).sort((a, b) => a.minM - b.minM)[0];
  const top = state.roster.filter(p => Object.keys(p.st).length).map(p => ({ n: p.n, pos: p.pos, sc: heisScore(p.st, p.pos, 'MICH'), line: statLineRaw(p.pos, p.st) })).sort((a, b) => b.sc - a.sc).slice(0, 3);
  const sc = g => { const a = g.h === 'MICH' ? g.hs : g.as, b = g.h === 'MICH' ? g.as : g.hs; return `${a}-${b}`; };
  return {
    best: best ? { opp: teamName(oppOf(best)), score: sc(best), id: best.id } : null, worst: worst ? { opp: teamName(oppOf(worst)), score: sc(worst), id: worst.id } : null,
    comeback: comeback ? { opp: teamName(oppOf(comeback)), score: sc(comeback), down: -comeback.minM } : null,
    top, grade: delta >= 12 ? 'A' : delta >= 5 ? 'B' : delta >= -2 ? 'C' : delta >= -8 ? 'D' : 'F',
  };
}
function statLineRaw(pos, st) { const g = k => st[k] || 0; if (pos === 'QB') return `${g('py')} pass yds, ${g('ptd')} TD`; if (pos === 'RB') return `${g('ry')} rush yds, ${g('rtd')} TD`; if (['WR', 'TE'].includes(pos)) return `${g('rcy')} rec yds, ${g('rctd')} TD`; return `${g('tk')} tkl, ${g('sk')} sk, ${g('int')} INT`; }

/* ---------- achievements & legacy ---------- */
function unlock(id) { if (state.ach[id]) return; state.ach[id] = { s: state.season }; const a = ACH.find(x => x[0] === id); addNews(`Achievement unlocked: ${a[1]}. ${a[2]}`, 'big'); state.achToast = a[1]; }
function checkAch(when, g) {
  const games = mGames(); const wins = games.filter(x => x.mResult === 'W');
  if (wins.length) unlock('first_win');
  if (g && g.done && g.mResult === 'W') {
    const opp = oppOf(g); const m = g.h === 'MICH' ? g.hs - g.as : g.as - g.hs;
    if (opp === 'OSU' && !state.me) unlock('beat_osu');
    if (g.oppRk && g.oppRk <= 10 && m >= 21) unlock('blowout');
    if ((g.minM || 0) <= -17) unlock('comeback');
  }
  if (rankOf('MICH') === 1) unlock('no1');
  if (wins.length >= 10) unlock('ten');
  if (!state.me) { const yrs = {}; state.rivalLog.filter(x => x.win).forEach(x => (yrs[x.s] = yrs[x.s] || new Set()).add(x.opp)); if (Object.values(yrs).some(s => s.size >= 3)) unlock('triple'); const osu = state.rivalLog.filter(x => x.opp === 'OSU'); if (osu.length >= 5 && osu.slice(-5).every(x => x.win)) unlock('osu5'); }
  if (state.roster.some(p => (p.walkon || p.exWalkon) && state.depth[p.pos].indexOf(p.id) < START[p.pos])) unlock('walkon');
  if (state.facilities.some(f => f.lvl >= 5)) unlock('maxfac');
  if (when === 'final') {
    if (games.some(x => x.type === 'cfp')) unlock('cfp');
    if (state.champ === 'MICH') unlock('natl');
    if (games.some(x => x.type === 'ccg' && x.mResult === 'W')) unlock('b1g');
    if (games.length >= 12 && games.every(x => x.mResult === 'W')) unlock('undefeated');
    const home = games.filter(x => x.att); if (home.length >= 5 && home.every(x => x.att >= 107000)) unlock('fullhouse');
  }
  if (when === 'season') {
    const h = state.history; const aw = state.awards[state.awards.length - 1];
    if (aw && aw.heis[0] && aw.heis[0].tm === 'MICH') unlock('heisman');
    if (h.length >= 3 && h.slice(-3).every(x => x.net >= 0)) unlock('profit3');
    if (h.length >= 5 && h.slice(0, 5).every(x => x.net >= 0)) unlock('profit_all');
    if (state.settings.diff === 'hard' && !state.gameOver) unlock('hard');
    if (h.length >= 10) unlock('decade');
    if (h.length >= 5 && !state.investigations.some(x => x.s > state.season - 5)) unlock('clean');
  }
  if (when === 'draft') { const byYr = {}; state.draft.filter(d => d.rd === 1).forEach(d => byYr[d.s] = (byYr[d.s] || 0) + 1); if (Object.values(byYr).some(n => n >= 3)) unlock('picks3'); }
  if (when === 'class' && state.rec && state.rec.classRank && state.rec.classRank <= 5) unlock('class5');
}
function legacyScore() {
  const h = state.history; const tr = state.trophies;
  const natl = tr.filter(t => t.k === 'natl').length, conf = tr.filter(t => t.k === 'conf').length, cfp = tr.filter(t => t.k === 'cfp').length;
  const wins = h.reduce((s, x) => s + (x.vacated ? 0 : x.w), 0); const osu = state.rivalLog.filter(x => x.opp === 'OSU' && x.win).length;
  const profit = h.filter(x => x.net >= 0).length; const r1c = state.draft.filter(d => d.rd === 1).length, picks = state.draft.length - r1c;
  const heis = state.awards.filter(a => a.heis[0] && a.heis[0].tm === 'MICH').length;
  const ach = Object.keys(state.ach || {}).reduce((s, id) => s + (ACH.find(a => a[0] === id) || [0, 0, 0, 0])[3], 0);
  const raw = natl * 100 + conf * 40 + cfp * 20 + wins * 2 + osu * 10 + profit * 5 + r1c * 8 + picks * 2 + heis * 30 + ach;
  return Math.round(raw * (LEGACY_MULT[state.settings.diff] || 1));
}

/* ---------- custom program ---------- */
function applyCustom(c) {
  const t = state.teams.MICH; t.name = c.name; t.conf = c.conf; t.style = genStyle();
  state.me = { name: c.name, ab: (c.ab || c.name.slice(0, 4)).toUpperCase().slice(0, 5), stadium: c.stadium || c.name + ' Stadium', cap: clamp(+c.cap || 60000, 15000, 115000), c1: c.c1 || '#F5C518', c2: c.c2 || '#00274C', tier: c.tier, cfg: c };
  const mates = Object.values(state.teams).filter(x => x.conf === c.conf && x.id !== 'MICH'); const avg = mates.length ? mates.reduce((a, x) => a + x.rating, 0) / mates.length : 70;
  state.me.base = Math.round(clamp(avg + { power: 10, mid: 1, rebuild: -6 }[c.tier], 50, 88));
  t.rating = state.me.base; t.elo = 1500 + (t.rating - 70) * 12;
  state.deals = DEAL_DEFS.map(d => Object.assign({}, d, { amt: r1(d.amt * econ()) }));
  state.facilities.forEach(f => f.lvl = c.tier === 'power' ? 4 : c.tier === 'mid' ? 3 : 2);
}
function genCustomRoster(base) {
  const counts = { QB: 4, RB: 5, WR: 10, TE: 5, OL: 16, DE: 9, DT: 8, LB: 9, CB: 9, S: 8, K: 2, P: 2, LS: 1 };
  Object.entries(counts).forEach(([pos, n]) => {
    for (let i = 0; i < n; i++) {
      const cls = pick(['Fr', 'Fr', 'So', 'So', 'Jr', 'Jr', 'Sr', 'Sr', 'Gr']); const b = genBody(pos);
      const starterish = i < START[pos] + 1; const ovr = clamp(Math.round(base + (starterish ? 2 : -7) + gauss() * 4 + CLASSES.indexOf(cls) * 1.2), 45, 92);
      const pot = clamp(ovr + { Fr: 14, So: 10, Jr: 6, Sr: 3, Gr: 1 }[cls] + ri(0, 8), ovr, 97);
      state.roster.push(makePlayer({ num: 0, n: genName(), pos, cls, ht: b.ht, wt: b.wt, home: pick(TOWNS)[0], ovr, pot, real: false }));
    }
  });
  rebuildPMap(); state.roster.forEach(p => { p.num = freeNumber(p.pos); });
}
function genCustomStaff(base) {
  const st = {}; STAFF_ROLES.forEach(r => { const c = genCandidates(r, 3)[1]; c.salary = r1(Math.max(0.1, c.salary * Math.max(0.3, econ()))); if (r === 'HC') { ['off', 'def', 'rec', 'dev', 'gm'].forEach(k => c[k] = clamp(Math.round(base + gauss() * 4), 55, 92)); } else c.ovr = clamp(Math.round(base - 2 + gauss() * 4), 55, 90); c.bg = 'Current staff'; st[r] = c; });
  return st;
}
function ownSchedule() {
  const me = T('MICH'); const c = CONFS[me.conf]; const cg = c.confGames ? Math.min(c.confGames, c.teams.length - 1) : 0;
  const sched = []; const used = new Set(['MICH']); const book = ncBooked(state.season);
  const nonConf = Object.values(state.teams).filter(t => t.conf !== me.conf && t.id !== 'MICH');
  const g5 = nonConf.filter(t => !CONFS[t.conf].p4 && t.id !== 'ND');
  const addBook = wk => { const b = book.find(x => x.wk === wk); if (b && !used.has(b.opp) && (isFCS(b.opp) || T(b.opp).conf !== me.conf)) { used.add(b.opp); sched.push([wk, b.opp, b.site !== 'A' ? 1 : 0, b.site === 'N' ? { neutral: true, payout: b.payout, loc: b.loc, name: 'Neutral site: ' + b.loc } : b.fee ? { fee: b.fee } : null]); return true; } return false; };
  if (cg) {
    [1, 2, 3].forEach(wk => { if (!addBook(wk)) { const o = pick(g5.filter(t => !used.has(t.id))).id; used.add(o); sched.push([wk, o, 1, { fee: r1(rnd(1.2, 1.8)) }]); } });
    const mich = !state.me && me.conf === 'B1G' && c.teams.includes('OSU') && c.teams.includes('MSU');
    const pool = shuffle(c.teams.filter(t => t !== 'MICH' && !(mich && (t === 'OSU' || t === 'MSU'))));
    const opps = mich ? pool.slice(0, cg - 2).concat(['MSU']) : pool.slice(0, cg);
    const bye = ri(5, 9); const weeks = []; for (let w = 4; w <= 13; w++) if (w !== bye && !(mich && w === 13)) weeks.push(w);
    const wsel = shuffle(weeks).slice(0, opps.length).sort((a, b) => a - b);
    shuffle(opps).forEach((o, i) => { used.add(o); sched.push([wsel[i], o, i % 2 === 0 ? 1 : 0]); });
    if (mich) { used.add('OSU'); sched.push([13, 'OSU', state.season % 2 === 1 ? 1 : 0]); }
    const open = []; for (let w = 4; w <= 13; w++) if (!sched.some(x => x[0] === w)) open.push(w);
    while (sched.length < 12 && open.length > 1) { const w = open.splice(ri(0, open.length - 1), 1)[0]; const o = pick(nonConf.filter(t => !used.has(t.id))).id; used.add(o); sched.push([w, o, R() < 0.5 ? 1 : 0]); }
  } else {
    const pool = shuffle(nonConf.slice()); const bye = ri(5, 9); let k = 0;
    for (let w = 1; w <= 13; w++) { if (w === bye) continue; if (w <= 3 && addBook(w)) continue; const o = pool.find(t => !used.has(t.id)).id; used.add(o); sched.push([w, o, k++ % 2 === 0 ? 1 : 0]); }
  }
  return sched;
}

/* ---------- automation for multi-year sims ---------- */
function autoBoard() { if (!state.off.boardRes) presentBoard({ stance: finTotals().net >= 0 ? 'balanced' : 'lean', fac: 'none', tix: 'hold', vote: 'yes' }); }
function autoDeals() { (state.deals || []).forEach(d => { if (d.thru < state.season + 1) signDeal(d.id, 'short'); }); }
function autoSeason() {
  autoSeasonRecruiting(); let n = 0;
  while (state.phase !== 'offseason' && !state.gameOver && n++ < 40) advance();
  if (!state.gameOver) autoOffseason();
}

function autoFinishDrive(sim) {
  let g = 0; while (sim.pending && sim.pending.type === 'drive' && g++ < 60) { const ds = sim.pending.ds; if (ds.down === 4) { if (fgRange(ds) && 117 - ds.yl <= 52) kickFromDrive(sim, 'fg'); else if (ds.togo <= 2 && ds.yl >= 45) runPlay(sim, 'inside'); else kickFromDrive(sim, 'punt'); } else runPlay(sim, pick(['inside', 'outside', 'short', 'short', 'screen', 'deep'])); }
}
