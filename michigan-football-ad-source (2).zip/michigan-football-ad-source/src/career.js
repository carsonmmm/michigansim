/* ===================== PLAYER CAREER: engine ===================== */
// Player Career mode: one player from high school (or straight into college) to the NFL Draft.
// Everything here works on `cs`, the active player career, and never touches the page.
// League data (teams, conferences, bowls, name lists) comes from data.js; drive odds reuse
// driveProbs()/rollOut() from core.js. AD mode's `state` is never read or written here.

let cs = null;

/* ---------- positions, attributes, play styles ---------- */
const CPOS = ['QB', 'RB', 'WR', 'TE', 'CB', 'DE', 'LB', 'S'];
const CPOS_NAME = { QB: 'Quarterback', RB: 'Running back', WR: 'Wide receiver', TE: 'Tight end', CB: 'Cornerback', DE: 'Defensive end', LB: 'Linebacker', S: 'Safety' };
const cSide = pos => (['QB', 'RB', 'WR', 'TE'].includes(pos) ? 'off' : 'def');
const CATTR = {
  QB: [['acc', 'Accuracy'], ['dec', 'Decision-making'], ['arm', 'Arm strength'], ['pres', 'Poise under pressure'], ['mob', 'Mobility']],
  RB: [['spd', 'Speed'], ['vis', 'Vision'], ['elu', 'Elusiveness'], ['pow', 'Power'], ['bsec', 'Ball security'], ['hnd', 'Hands']],
  WR: [['rte', 'Route running'], ['hnd', 'Hands'], ['spd', 'Speed'], ['rel', 'Release'], ['ctc', 'Contested catch']],
  TE: [['hnd', 'Hands'], ['blk', 'Blocking'], ['rte', 'Route running'], ['pow', 'Strength'], ['spd', 'Speed']],
  CB: [['man', 'Man coverage'], ['spd', 'Speed'], ['zon', 'Zone coverage'], ['bsk', 'Ball skills'], ['prs', 'Press']],
  S: [['zon', 'Zone coverage'], ['tkl', 'Tackling'], ['iq', 'Play recognition'], ['spd', 'Speed'], ['bsk', 'Ball skills']],
  DE: [['rsh', 'Pass-rush moves'], ['bst', 'Burst'], ['pow', 'Strength'], ['rnd', 'Run defense'], ['tkl', 'Tackling']],
  LB: [['tkl', 'Tackling'], ['iq', 'Play recognition'], ['cov', 'Coverage'], ['spd', 'Speed'], ['blz', 'Blitzing']],
};
const CWT = {
  QB: { acc: 0.27, dec: 0.23, arm: 0.2, pres: 0.16, mob: 0.14 }, RB: { spd: 0.22, vis: 0.2, elu: 0.18, pow: 0.16, bsec: 0.12, hnd: 0.12 },
  WR: { rte: 0.24, hnd: 0.22, spd: 0.22, rel: 0.16, ctc: 0.16 }, TE: { hnd: 0.24, blk: 0.22, rte: 0.2, pow: 0.18, spd: 0.16 },
  CB: { man: 0.26, spd: 0.22, zon: 0.2, bsk: 0.16, prs: 0.16 }, S: { zon: 0.24, tkl: 0.2, iq: 0.2, spd: 0.18, bsk: 0.18 },
  DE: { rsh: 0.28, bst: 0.22, pow: 0.2, rnd: 0.18, tkl: 0.12 }, LB: { tkl: 0.24, iq: 0.24, cov: 0.18, spd: 0.18, blz: 0.16 },
};
// the attribute that helps a player read the play before the snap
const CREAD = { QB: 'dec', RB: 'vis', WR: 'rte', TE: 'rte', CB: 'bsk', S: 'iq', DE: 'rsh', LB: 'iq' };
const CSTYLES = {
  QB: [['pocket', 'Pocket passer', 'Big arm, reads the field from the pocket.', { arm: 6, acc: 4, mob: -7 }], ['dual', 'Dual-threat', 'Beats you with his legs as well as his arm.', { mob: 11, arm: 1, acc: -4, pres: -2 }], ['general', 'Field general', 'Smart and unflappable. Rarely makes the costly mistake.', { dec: 7, pres: 5, arm: -5 }]],
  RB: [['power', 'Power back', 'Runs through contact and protects the ball.', { pow: 8, bsec: 5, spd: -5, elu: -3 }], ['speed', 'Speed back', 'One cut and gone.', { spd: 8, elu: 5, pow: -6 }], ['receiving', 'Receiving back', 'A weapon out of the backfield.', { hnd: 9, elu: 3, pow: -5 }]],
  WR: [['deep', 'Deep threat', 'Stretches the field vertically.', { spd: 9, rel: 3, ctc: -5 }], ['possession', 'Possession receiver', 'Sure hands and wins the 50-50 balls.', { hnd: 6, ctc: 6, spd: -6 }], ['technician', 'Route technician', 'Creates separation with precise routes.', { rte: 8, rel: 4, spd: -4 }]],
  TE: [['blocking', 'Blocking tight end', 'An extra lineman who can catch.', { blk: 9, pow: 5, spd: -6, rte: -3 }], ['receiving', 'Receiving tight end', 'A big target who creates mismatches.', { hnd: 6, rte: 5, spd: 4, blk: -7 }]],
  CB: [['lockdown', 'Lockdown corner', 'Sticks to receivers in man coverage.', { man: 8, prs: 5, zon: -4, bsk: -3 }], ['ballhawk', 'Ball hawk', 'Reads the quarterback and takes the ball away.', { bsk: 8, zon: 5, prs: -6 }], ['speed', 'Speed corner', 'Nobody runs past him.', { spd: 9, man: 2, prs: -5 }]],
  S: [['center', 'Centerfielder', 'Covers the deep middle and hunts interceptions.', { zon: 6, spd: 4, bsk: 5, tkl: -7 }], ['box', 'Box safety', 'A hard hitter who plays like a linebacker.', { tkl: 8, iq: 4, bsk: -5, zon: -3 }]],
  DE: [['speed', 'Speed rusher', 'Explodes off the edge.', { bst: 9, rsh: 4, pow: -6, rnd: -3 }], ['power', 'Power rusher', 'Walks tackles back into the quarterback.', { pow: 9, rsh: 3, bst: -6 }], ['run', 'Run stopper', 'Sets the edge and makes tackles.', { rnd: 8, tkl: 5, rsh: -5, bst: -3 }]],
  LB: [['run', 'Run stopper', 'Fills gaps and finishes tackles.', { tkl: 8, iq: 3, cov: -6 }], ['coverage', 'Coverage linebacker', 'Runs with backs and tight ends.', { cov: 8, spd: 4, blz: -5, tkl: -3 }], ['blitz', 'Blitzer', 'Gets after the quarterback.', { blz: 9, spd: 3, cov: -6 }]],
};
const cStyle = p => (CSTYLES[p.pos].find(s => s[0] === p.style) || CSTYLES[p.pos][0]);
function cOvr(p) { const w = CWT[p.pos]; let s = 0; for (const k in w) s += w[k] * (p.a[k] || 40); return Math.round(s); }
// skill points: each +1 costs more as the attribute climbs
function cCost(v) { return v < 50 ? 1 : v < 58 ? 2 : v < 66 ? 3 : v < 74 ? 4 : v < 82 ? 5 : v < 88 ? 6 : v < 94 ? 8 : 10; }
const CATTR_MAX = 99;

/* ---------- geography ---------- */
const CSTATES = { AL: 'Alabama', AK: 'Alaska', AZ: 'Arizona', AR: 'Arkansas', CA: 'California', CO: 'Colorado', CT: 'Connecticut', DE: 'Delaware', DC: 'Washington, D.C.', FL: 'Florida', GA: 'Georgia', HI: 'Hawaii', ID: 'Idaho', IL: 'Illinois', IN: 'Indiana', IA: 'Iowa', KS: 'Kansas', KY: 'Kentucky', LA: 'Louisiana', ME: 'Maine', MD: 'Maryland', MA: 'Massachusetts', MI: 'Michigan', MN: 'Minnesota', MS: 'Mississippi', MO: 'Missouri', MT: 'Montana', NE: 'Nebraska', NV: 'Nevada', NH: 'New Hampshire', NJ: 'New Jersey', NM: 'New Mexico', NY: 'New York', NC: 'North Carolina', ND: 'North Dakota', OH: 'Ohio', OK: 'Oklahoma', OR: 'Oregon', PA: 'Pennsylvania', RI: 'Rhode Island', SC: 'South Carolina', SD: 'South Dakota', TN: 'Tennessee', TX: 'Texas', UT: 'Utah', VT: 'Vermont', VA: 'Virginia', WA: 'Washington', WV: 'West Virginia', WI: 'Wisconsin', WY: 'Wyoming' };
const CREGION = { NE: 'ME NH VT MA RI CT NY NJ PA', MA: 'DE MD DC VA WV', SE: 'NC SC GA FL AL MS TN KY', SC: 'LA AR TX OK', MW: 'OH MI IN IL WI MN IA MO', PL: 'KS NE SD ND', MT: 'CO UT WY MT ID NM AZ NV', W: 'CA OR WA AK HI' };
const REGION_OF = {}; Object.entries(CREGION).forEach(([r, s]) => s.split(' ').forEach(st => REGION_OF[st] = r));
const TEAM_STATE = {};
('ILL IL;IU IN;IOWA IA;MD MD;MICH MI;MSU MI;MINN MN;NEB NE;NW IL;OSU OH;ORE OR;PSU PA;PUR IN;RUTG NJ;UCLA CA;USC CA;UW WA;WIS WI;ALA AL;ARK AR;AUB AL;FLA FL;UGA GA;UK KY;LSU LA;MISS MS;MSST MS;MIZ MO;OU OK;SC SC;TENN TN;TEX TX;TAMU TX;VAN TN;' +
  'ARIZ AZ;ASU AZ;BAY TX;BYU UT;CIN OH;COLO CO;HOU TX;ISU IA;KU KS;KSU KS;OKST OK;TCU TX;TTU TX;UCF FL;UTAH UT;WVU WV;BC MA;CAL CA;CLEM SC;DUKE NC;FSU FL;GT GA;LOU KY;MIA FL;NCST NC;UNC NC;PITT PA;SMU TX;STAN CA;SYR NY;UVA VA;VT VA;WAKE NC;ND IN;UCONN CT;' +
  'BSU ID;CSU CO;FRES CA;ORST OR;SDSU CA;TXST TX;USU UT;WSU WA;ARMY NY;CLT NC;ECU NC;FAU FL;MEM TN;NAVY MD;UNT TX;RICE TX;USF FL;TEM PA;TUL LA;TLSA OK;UAB AL;UTSA TX;AF CO;HAW HI;NEV NV;UNM NM;NDSU ND;NIU IL;SJSU CA;UNLV NV;UTEP TX;WYO WY;' +
  'APP NC;ARST AR;CCU SC;GASO GA;GAST GA;JMU VA;ULL LA;LT LA;MRSH WV;ODU VA;USA AL;USM MS;TROY AL;ULM LA;AKR OH;BALL IN;BGSU OH;BUFF NY;CMU MI;EMU MI;KENT OH;M-OH OH;OHIO OH;SAC CA;TOL OH;UMASS MA;WMU MI;DEL DE;FIU FL;JVST AL;KENN GA;LIB VA;MTSU TN;MOST MO;NMSU NM;SHSU TX;WKU KY')
  .split(';').forEach(s => { const [id, st] = s.split(' '); TEAM_STATE[id] = st; });

/* ---------- league reference data ---------- */
// Career mode keeps its own copy of the 2026 alignment, so an AD custom program can't change it.
const CTEAMS0 = {}; const CCONF = {};
CONF_DEFS.forEach(([cid, name, p4, cg, list]) => { CCONF[cid] = { id: cid, name, p4: !!p4, confGames: cg, teams: [] }; list.split(';').forEach(s => { const [nm, id, r] = s.split('|'); CTEAMS0[id] = { name: nm, conf: cid, base: +r }; CCONF[cid].teams.push(id); }); });
const CONF_HONOR = { B1G: 'All-Big Ten', SEC: 'All-SEC', B12: 'All-Big 12', ACC: 'All-ACC', P12: 'All-Pac-12', AAC: 'All-AAC', MW: 'All-Mountain West', SBC: 'All-Sun Belt', MAC: 'All-MAC', CUSA: 'All-Conference USA' };
const CONF_NIL = { B1G: 1.3, SEC: 1.3, B12: 0.95, ACC: 0.9, IND: 0.5, P12: 0.55, AAC: 0.5, MW: 0.45, SBC: 0.4, MAC: 0.35, CUSA: 0.35 };
const NFL_TEAMS = ['Arizona Cardinals', 'Atlanta Falcons', 'Baltimore Ravens', 'Buffalo Bills', 'Carolina Panthers', 'Chicago Bears', 'Cincinnati Bengals', 'Cleveland Browns', 'Dallas Cowboys', 'Denver Broncos', 'Detroit Lions', 'Green Bay Packers', 'Houston Texans', 'Indianapolis Colts', 'Jacksonville Jaguars', 'Kansas City Chiefs', 'Las Vegas Raiders', 'Los Angeles Chargers', 'Los Angeles Rams', 'Miami Dolphins', 'Minnesota Vikings', 'New England Patriots', 'New Orleans Saints', 'New York Giants', 'New York Jets', 'Philadelphia Eagles', 'Pittsburgh Steelers', 'San Francisco 49ers', 'Seattle Seahawks', 'Tampa Bay Buccaneers', 'Tennessee Titans', 'Washington Commanders'];
const HS_PLACES = ['Lincoln', 'Jefferson', 'Westfield', 'Ridgeview', 'Cedar Creek', 'North Valley', 'Lakeside', 'Riverside', 'Oak Ridge', 'Pine Bluff', 'Stonebridge', 'Hillcrest', 'Eastbrook', 'Clearwater', 'Fairview', 'Summit', 'Bayside', 'Prairie View', 'Heritage', 'Maple Grove', 'Granite Falls', 'Willow Park', 'Brookhaven', 'Red Hill', 'Silver Lake', 'Kingsway', 'Harbor City', 'Fox Run', 'Eagle Point', 'Mill Creek'];
const HS_MASCOTS = ['Eagles', 'Tigers', 'Wildcats', 'Panthers', 'Mustangs', 'Rams', 'Titans', 'Knights', 'Hawks', 'Bulldogs', 'Warriors', 'Falcons', 'Cougars', 'Chargers', 'Raiders', 'Spartans', 'Vikings', 'Bears', 'Lions', 'Hornets', 'Trojans', 'Pirates', 'Wolves', 'Rebels'];
const HS_CLS = ['Freshman', 'Sophomore', 'Junior', 'Senior'];
const CDIFF = {
  easy: { label: 'Easy', desc: 'Faster development, friendlier recruiters and more of your snap decisions work.', xp: 1.3, dec: 0.06, star: 1.5 },
  normal: { label: 'Normal', desc: 'The intended experience.', xp: 1, dec: 0, star: 0 },
  hard: { label: 'Hard', desc: 'Slower development, tougher reads and pickier recruiters.', xp: 0.8, dec: -0.06, star: -1.5 },
};
const cdiff = () => CDIFF[(cs && cs.diff) || 'normal'];

/* ---------- small helpers ---------- */
// A separate, repeatable random stream for generated rosters, so names and ratings never
// have to be saved and never disturb the main random sequence.
function hrng(str) { let s = (Math.floor(hash(str) * 4294967295) >>> 0) || 1; return () => { let t = (s = (s + 0x6D2B79F5) >>> 0); t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const hpick = (r, a) => a[Math.floor(r() * a.length)];
const hgauss = r => { let u = 0, v = 0; while (!u) u = r(); while (!v) v = r(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
function binom(n, p) { let k = 0; for (let i = 0; i < n; i++) if (R() < p) k++; return k; }
const cName = p => p.first + ' ' + p.last;
const cLast = n => String(n).split(' ').slice(-1)[0];
function money(x) { x = Math.round(x || 0); if (Math.abs(x) >= 1e6) return '$' + (x / 1e6).toFixed(x >= 1e7 ? 1 : 2).replace(/\.0+$/, '') + 'M'; if (Math.abs(x) >= 1000) return '$' + Math.round(x / 1000) + 'K'; return '$' + x; }
function interp(pts, x) { if (x <= pts[0][0]) return pts[0][1]; for (let i = 1; i < pts.length; i++) if (x <= pts[i][0]) { const [x0, y0] = pts[i - 1], [x1, y1] = pts[i]; return y0 + (y1 - y0) * (x - x0) / (x1 - x0); } return pts[pts.length - 1][1]; }
function cNews(txt, kind) { cs.news.unshift({ y: cs.year, wk: cs.week, lvl: cs.lvl, txt, kind: kind || '' }); if (cs.news.length > 120) cs.news.length = 120; }

/* ---------- stars and recruiting rankings ---------- */
// Recruit score is on the college OVR scale: roughly what the player is projected to be at
// the end of high school, nudged by production, camps and all-star invitations.
const HS_GROWTH_LEFT = [21, 14, 7, 0];
// growth still expected before the end of high school, from this point in the calendar
function growthLeft() {
  if (cs.lvl !== 'hs') return 0; const c = cs.hs.cls;
  if (cs.phase === 'hs') return [17, 11, 5.5, 0][c] + Math.max(0, 1 - (cs.week - 1) / 10) * [4, 3.5, 3, 2][c];
  return [17, 11, 5.5, 0][c];
}
function starsOf(score) { return score >= 79 ? 5 : score >= 73 ? 4 : score >= 66 ? 3 : score >= 58 ? 2 : 1; }
function compositeOf(score) { return interp([[50, 0.75], [58, 0.8], [66, 0.84], [73, 0.8900], [79, 0.9834], [86, 1]], score); }
function natRankOf(score) { return Math.max(1, Math.round(Math.exp(interp([[58, Math.log(3200)], [66, Math.log(1400)], [73, Math.log(330)], [79, Math.log(32)], [86, 0]], score)))); }
function posRankOf(score, pos) { const share = { QB: 0.055, RB: 0.06, WR: 0.13, TE: 0.045, CB: 0.1, DE: 0.08, LB: 0.08, S: 0.07 }[pos]; return Math.max(1, Math.round(natRankOf(score) * share)); }
function recruitScore() {
  const p = cs.p; const r = p.rec;
  const proj = cOvr(p) + growthLeft();
  return r1(proj + (r.prod || 0) + (r.camp || 0) + (r.aa || 0) + cdiff().star);
}
// Transfers are rated on what they have already shown in college.
function transferScore() { const p = cs.p; const pr = cs.col && cs.col.lastRatio != null ? clamp((cs.col.lastRatio - 1) * 6, -3, 5) : -1; return r1(cOvr(p) - 5 + pr); }

/* ---------- player creation ---------- */
function newPlayer(o) {
  const pos = o.pos; const st = CSTYLES[pos].find(s => s[0] === o.style) || CSTYLES[pos][0];
  const body = POS_BODY[pos]; const hIn = ri(body[0], body[1]) + (o.style === 'power' || o.style === 'blocking' ? 1 : 0);
  const p = {
    first: o.first, last: o.last, pos, num: o.num, home: o.home, style: st[0], a: {}, ht: Math.floor(hIn / 12) + '-' + (hIn % 12), wt: ri(body[2], body[3]),
    xp: 0, trust: 50, inj: 0, injName: '', bank: 0, earned: 0, spent: 0, awards: [], seasons: [], rec: { prod: 0, camp: 0, aa: 0 }, auto: false,
  };
  const target = o.target; // average attribute level to start from
  CATTR[pos].forEach(([k]) => { p.a[k] = clamp(Math.round(target + (st[3][k] || 0) + gauss() * 2), 30, 95); });
  return p;
}
function newCareer(o) {
  const sd = freshSeed(); setSeed(sd);
  cs = {
    v: 1, kind: 'career', seed: sd, created: Date.now(), diff: o.diff || 'normal', pace: o.pace || 'every', year: 2026, week: 1, phase: 'hs', lvl: 'hs',
    p: null, hs: null, col: null, rec: null, portal: null, off: null, news: [], ss: null, league: null, hist: [], event: null, done: null, nilLog: [], admin: 0,
  };
  const skip = o.path === 'college';
  cs.p = newPlayer({ pos: o.pos, style: o.style, first: o.first, last: o.last, num: o.num, home: o.home, target: skip ? { 1: 58, 2: 63, 3: 68.5, 4: 74, 5: 79.5 }[o.stars] : 49 });
  cs.league = lgNew(2026);
  if (skip) {
    cs.p.rec.fixed = { 1: 55, 2: 62, 3: 69.5, 4: 76, 5: 82 }[o.stars];
    cs.lvl = 'col'; cs.phase = 'sign'; cs.hsSkipped = o.stars;
    startRecruiting(true);
    cNews(`${cName(cs.p)}, a ${o.stars}-star ${CPOS_NAME[o.pos].toLowerCase()} from ${CSTATES[o.home]}, is ready to pick a college. Offers are on the Recruiting tab.`, 'big');
  } else {
    const r = hrng(sd + 'hs');
    cs.hs = { name: o.hsName || (hpick(r, HS_PLACES) + ' High'), mascot: o.hsMascot || hpick(r, HS_MASCOTS), q: r1(56 + hgauss(r) * 3), cls: 0, titles: 0, w: 0, l: 0 };
    startRecruiting(false);
    hsNewSeason();
    cNews(`${cName(cs.p)} starts his freshman year at ${cs.hs.name}. Recruiters will be watching.`, 'big');
  }
  return cs;
}

/* ---------- league (all 138 FBS teams) ---------- */
function lgNew(year) {
  const L = { year, week: 1, teams: {}, games: [], polls: [], champ: null, cfp: null, hist: [], heis: null };
  Object.entries(CTEAMS0).forEach(([id, t]) => {
    const r = t.base; const off = r1(r + gauss() * 2.5);
    L.teams[id] = { id, name: t.name, conf: t.conf, base: r, rating: r, off, def: r1(2 * r - off), elo: 1500 + (r - 70) * 12, w: 0, l: 0, cw: 0, cl: 0, pf: 0, pa: 0, ap: 0, coach: genName(), cy: ri(1, 8), need: {} };
    teamNeeds(L.teams[id]);
  });
  PRESEASON_AP.forEach((id, i) => { if (L.teams[id]) L.teams[id].elo = 1860 - i * 9; });
  Object.values(L.teams).forEach(t => { if (!PRESEASON_AP.includes(t.id)) t.elo = Math.min(t.elo, 1612 - (80 - t.rating)); });
  lgSchedule(L); lgPoll(L, 'Preseason');
  return L;
}
function teamNeeds(t) { CPOS.forEach(p => t.need[p] = r1(clamp(1 + gauss() * 0.3, 0.4, 1.6))); }
const LT = id => cs.league.teams[id];
function cTeamName(id) { if (!id) return 'TBD'; if (id.startsWith('FCS:')) return id.slice(4); if (id.startsWith('HS:')) return id.slice(3); const t = cs && cs.league && cs.league.teams[id]; return t ? t.name : (CTEAMS0[id] ? CTEAMS0[id].name : id); }
const isFcsId = id => !!id && id.startsWith('FCS:');
const p4Team = id => !!CCONF[CTEAMS0[id] ? CTEAMS0[id].conf : 'MAC'].p4 || id === 'ND';
function lgSchedule(L) {
  const ids = Object.keys(L.teams); const T_ = id => L.teams[id];
  const busy = {}; ids.forEach(id => busy[id] = new Set());
  const games = []; const played = new Set(); const key = (a, b) => a < b ? a + '|' + b : b + '|' + a;
  const homeCt = {}, cnt = {}, confCnt = {}; ids.forEach(id => { homeCt[id] = 0; cnt[id] = 0; confCnt[id] = 0; });
  let n = 0;
  const add = (wk, h, a, conf) => { games.push({ id: L.year + '-' + (++n), wk, h, a, conf, neutral: false, done: false, type: 'reg' }); if (!isFcsId(h)) busy[h].add(wk); if (!isFcsId(a)) busy[a].add(wk); played.add(key(h, a)); if (!isFcsId(h)) { homeCt[h]++; cnt[h]++; } if (!isFcsId(a)) cnt[a]++; };
  for (const c of Object.values(CCONF)) {
    if (!c.confGames) continue;
    const need = Math.min(c.confGames, c.teams.length - 1); let best = null;
    for (let attempt = 0; attempt < 400; attempt++) {
      const lc = {}; c.teams.forEach(t => lc[t] = confCnt[t]);
      const lbusy = {}; c.teams.forEach(t => lbusy[t] = new Set(busy[t]));
      const lplayed = new Set(played); const tg = [];
      for (let wk = 4; wk <= 13; wk++) {
        const av = c.teams.filter(t => !lbusy[t].has(wk) && lc[t] < need);
        const urg = t => { let free = 0; for (let w = wk; w <= 13; w++) if (!lbusy[t].has(w)) free++; return (need - lc[t]) - free; };
        const sorted = av.map(t => [t, urg(t) + R() * 0.9]).sort((a, b) => b[1] - a[1]).map(x => x[0]);
        const used = new Set();
        for (const t of sorted) {
          if (used.has(t)) continue;
          const u = sorted.find(x => x !== t && !used.has(x) && !lplayed.has(key(t, x)));
          if (!u) continue;
          used.add(t); used.add(u); lc[t]++; lc[u]++; lbusy[t].add(wk); lbusy[u].add(wk); lplayed.add(key(t, u)); tg.push([wk, t, u]);
        }
      }
      const short = c.teams.reduce((s, t) => s + (need - lc[t]), 0);
      if (!best || short < best.short) best = { short, tg };
      if (short === 0) break;
    }
    best.tg.forEach(([wk, a, b]) => { const h = homeCt[a] <= homeCt[b] ? a : b; add(wk, h, h === a ? b : a, true); confCnt[a]++; confCnt[b]++; });
  }
  for (let wk = 1; wk <= 13; wk++) {
    const free = t => { let f = 0; for (let w = wk; w <= 13; w++) if (!busy[t].has(w)) f++; return f; };
    const cands = ids.filter(t => !busy[t].has(wk) && cnt[t] < 12);
    const must = [], opt = [];
    cands.forEach(t => { if (wk <= 3 || free(t) <= 12 - cnt[t]) must.push(t); else opt.push(t); });
    shuffle(must); shuffle(opt);
    const used = new Set();
    for (const t of must) {
      if (used.has(t)) continue; used.add(t);
      const p4 = CCONF[T_(t).conf].p4;
      if (p4 && wk <= 3 && R() < 0.22 && !games.some(g => g.h === t && isFcsId(g.a))) { add(wk, t, 'FCS:' + pick(FCS_NAMES), false); continue; }
      const ok = x => !used.has(x) && T_(x).conf !== T_(t).conf && !played.has(key(t, x));
      const u = must.find(ok) || opt.find(ok);
      if (!u) { add(wk, t, 'FCS:' + pick(FCS_NAMES), false); continue; }
      used.add(u);
      const tr = T_(t).rating, ur = T_(u).rating;
      const h = Math.abs(tr - ur) > 8 ? (tr > ur ? t : u) : (homeCt[t] <= homeCt[u] ? t : u);
      add(wk, h, h === t ? u : t, false);
    }
  }
  L.games = games; L.gid = n;
}
function lgStrength(L, id) {
  if (isFcsId(id)) { const r = 40 + hash(id) * 14; return { off: r, def: r }; }
  const t = L.teams[id]; return { off: t.off, def: t.def };
}
// Fast drive-by-drive score for games that don't involve the player.
function fastGame(L, g) {
  const A = lgStrength(L, g.h), B = lgStrength(L, g.a); const adv = g.neutral ? 0 : 0.22;
  const F = [{ off: A.off + gauss() * 2.4, def: A.def + gauss() * 2.4 }, { off: B.off + gauss() * 2.4, def: B.def + gauss() * 2.4 }];
  const pts = [0, 0]; const N = ri(11, 13);
  for (let s = 0; s < 2; s++) for (let i = 0; i < N; i++) { const o = rollOut(driveProbs(F[s].off, F[1 - s].def, s === 0 ? adv : 0)); if (o === 'td') pts[s] += R() < 0.96 ? 7 : 6; else if (o === 'fg') pts[s] += 3; }
  let ot = 0; while (pts[0] === pts[1] && ot < 6) { ot++; for (let s = 0; s < 2; s++) { const o = rollOut(driveProbs(F[s].off, F[1 - s].def, 0, true), true); if (o === 'td') pts[s] += ot >= 3 ? 2 : 7; else if (o === 'fg' && ot < 3) pts[s] += 3; } }
  if (pts[0] === pts[1]) pts[R() < 0.5 ? 0 : 1] += 2;
  g.hs = pts[0]; g.as = pts[1]; g.ot = ot;
}
function lgApply(L, g) {
  g.done = true; const H = L.teams[g.h], A = L.teams[g.a]; const hw = g.hs > g.as;
  const upd = (t, us, them, win, oppElo) => {
    if (!t) return; t.pf += us; t.pa += them; if (win) t.w++; else t.l++;
    if (g.conf) { if (win) t.cw++; else t.cl++; }
    const exp = 1 / (1 + Math.pow(10, (oppElo - t.elo) / 400)); const mov = Math.log(Math.abs(us - them) + 1) * 0.9;
    t.elo += 26 * mov * ((win ? 1 : 0) - exp);
  };
  const he = H ? H.elo : 1180 + hash(g.h) * 120, ae = A ? A.elo : 1180 + hash(g.a) * 120;
  upd(H, g.hs, g.as, hw, ae); upd(A, g.as, g.hs, !hw, he);
}
function lgPoll(L, label) {
  const sc = t => t.elo + (CCONF[t.conf].p4 || t.id === 'ND' ? 0 : -45) - t.l * 30;
  const list = Object.values(L.teams).sort((a, b) => sc(b) - sc(a));
  list.forEach(t => t.ap = 0); list.slice(0, 25).forEach((t, i) => t.ap = i + 1);
  L.polls.push({ label, top: list.slice(0, 25).map(t => t.id) }); if (L.polls.length > 24) L.polls.shift();
}
function lgStandings(L, cid) {
  return CCONF[cid].teams.map(id => L.teams[id]).sort((a, b) => ((b.cw - b.cl) - (a.cw - a.cl)) || ((b.w - b.l) - (a.w - a.l)) || (b.elo - a.elo));
}
function lgNewGame(L, wk, h, a, o) { return Object.assign({ id: L.year + '-' + (++L.gid), wk, h, a, done: false, neutral: true, type: 'post' }, o || {}); }
// Sims every game this week except the player's own (handled by the game engine).
function lgSimWeek(L, wk, skipId) {
  L.games.filter(g => g.wk === wk && !g.done && g.id !== skipId).forEach(g => { fastGame(L, g); lgApply(L, g); });
}
function lgAfterWeek(L, wk) {
  if (wk <= 13) lgPoll(L, 'Week ' + (wk + 1));
  if (wk === 13) lgSetupCCG(L);
  if (wk === 14) { lgPoll(L, 'Final regular season'); lgSetupCFP(L); }
  if (wk >= 15 && wk <= 17) lgNextRound(L, wk);
  if (wk === 18) { const f = L.games.find(g => g.round === 4); if (f && f.done) L.champ = f.hs > f.as ? f.h : f.a; lgPoll(L, 'Final'); }
  L.week = wk + 1;
}
function lgSetupCCG(L) {
  Object.values(CCONF).forEach(c => { if (!c.confGames) return; const st = lgStandings(L, c.id); const [a, b] = st; if (!a || !b) return; L.games.push(lgNewGame(L, 14, a.id, b.id, { type: 'ccg', name: c.name + ' Championship', conf: false, cid: c.id })); });
}
function lgSetupCFP(L) {
  const champs = new Set(L.games.filter(g => g.type === 'ccg' && g.done).map(g => g.hs > g.as ? g.h : g.a));
  const ranked = Object.values(L.teams).filter(t => t.ap).sort((a, b) => a.ap - b.ap).map(t => t.id);
  const all = Object.values(L.teams).sort((a, b) => (a.ap || 99) - (b.ap || 99) || b.elo - a.elo).map(t => t.id);
  const auto = all.filter(id => champs.has(id)).slice(0, 5);
  const field = new Set(auto); for (const id of all) { if (field.size >= 12) break; field.add(id); }
  const seeds = [...field].sort((a, b) => all.indexOf(a) - all.indexOf(b));
  L.cfp = { seeds, champs: [...champs] };
  const pair = [[5, 12], [6, 11], [7, 10], [8, 9]];
  pair.forEach(([x, y], i) => L.games.push(lgNewGame(L, 15, seeds[x - 1], seeds[y - 1], { type: 'cfp', round: 1, slot: i, neutral: false, name: 'CFP First Round' })));
  // bowls for everyone else with six wins
  const eligible = all.filter(id => !field.has(id) && L.teams[id].w >= 6);
  const bowls = BOWLS.slice(0, Math.floor(eligible.length / 2));
  bowls.forEach((b, i) => { const h = eligible[i * 2], a = eligible[i * 2 + 1]; if (h && a) L.games.push(lgNewGame(L, 16, h, a, { type: 'bowl', name: b })); });
  void ranked;
}
function lgNextRound(L, wk) {
  const S = L.cfp.seeds; const win = g => g.hs > g.as ? g.h : g.a;
  if (wk === 15) { const r1g = L.games.filter(g => g.round === 1).sort((a, b) => a.slot - b.slot); [[0, 3], [1, 2], [2, 1], [3, 0]].forEach(([top, i], k) => L.games.push(lgNewGame(L, 16, S[top], win(r1g[i]), { type: 'cfp', round: 2, slot: k, name: QF_NAMES[k] }))); }
  if (wk === 16) { const q = L.games.filter(g => g.round === 2).sort((a, b) => a.slot - b.slot); [[0, 3], [1, 2]].forEach(([i, j], k) => L.games.push(lgNewGame(L, 17, win(q[i]), win(q[j]), { type: 'cfp', round: 3, slot: k, name: SF_NAMES[k] }))); }
  if (wk === 17) { const s = L.games.filter(g => g.round === 3); L.games.push(lgNewGame(L, 18, win(s[0]), win(s[1]), { type: 'cfp', round: 4, slot: 0, name: 'CFP National Championship' })); }
}
function lgFinishSeason(L) { for (let wk = L.week; wk <= 18; wk++) { lgSimWeek(L, wk, null); lgAfterWeek(L, wk); } }
// Next season: ratings drift, coaches come and go, a new schedule is drawn.
function lgRollover(L) {
  const top = Object.values(L.teams).filter(t => t.ap).sort((a, b) => a.ap - b.ap);
  L.hist.unshift({ year: L.year, champ: L.champ, top: top.slice(0, 10).map(t => [t.id, t.w + '-' + t.l]), heis: L.heis });
  if (L.hist.length > 12) L.hist.length = 12;
  const changes = [];
  Object.values(L.teams).forEach(t => {
    const expW = 6 + (t.rating - 68) / 4;
    t.rating = r1(clamp(t.rating + (t.base - t.rating) * 0.3 + gauss() * 2.6 + clamp(t.w - expW, -4, 4) * 0.35, 38, 96));
    const off = r1(t.rating + gauss() * 2.5); t.off = off; t.def = r1(2 * t.rating - off);
    // coaching carousel
    let fired = false, left = false;
    if (t.cy >= 2 && t.w < expW - 3 && R() < 0.55) fired = true;
    else if (!CCONF[t.conf].p4 && t.w >= 10 && R() < 0.35) left = true;
    else if (R() < 0.03) left = true;
    if (fired || left) { const old = t.coach; t.coach = genName(); t.cy = 0; changes.push({ id: t.id, old, now: t.coach, why: fired ? 'fired' : 'left' }); }
    t.cy++; teamNeeds(t);
    t.w = t.l = t.cw = t.cl = t.pf = t.pa = 0; t.ap = 0;
    t.elo = 0.45 * t.elo + 0.55 * (1500 + (t.rating - 70) * 12);
  });
  L.year++; L.week = 1; L.champ = null; L.cfp = null; L.polls = []; L.heis = null;
  lgSchedule(L); lgPoll(L, 'Preseason');
  return changes;
}

/* ---------- generated rosters ---------- */
// Every team's roster is rebuilt on demand from the career seed, so it costs nothing to save.
// A player keeps his name and development path from season to season.
const CPOS_ALL = ['QB', 'RB', 'WR', 'TE', 'OL', 'DE', 'DT', 'LB', 'CB', 'S', 'K', 'P'];
const CLASS_MIX = { QB: 1.1, RB: 1.6, WR: 3, TE: 1.3, OL: 4.2, DE: 2, DT: 2, LB: 2.2, CB: 2.2, S: 2, K: 0.3, P: 0.3 };
const START_N = { QB: 1, RB: 1, WR: 3, TE: 1, OL: 5, DE: 2, DT: 2, LB: 3, CB: 2, S: 2, K: 1, P: 1 };
const rosterCache = new Map();
function teamLevel(tid) { const t = cs.league.teams[tid]; return t ? t.base * 0.6 + t.rating * 0.4 : 55; }
// a team rating on the player OVR scale: roughly what its starters are rated
const starterLvl = r => 60 + (r - 60) * 0.7;
function genClass(tid, cy) {
  const r = hrng(cs.seed + ':' + tid + ':' + cy); const lvl = starterLvl(CTEAMS0[tid] ? CTEAMS0[tid].base : 60); const out = [];
  CPOS_ALL.forEach(pos => {
    let n = Math.floor(CLASS_MIX[pos]) + (r() < CLASS_MIX[pos] % 1 ? 1 : 0);
    for (let i = 0; i < n; i++) {
      const start = lvl - 9.5 + hgauss(r) * 4.2 + (r() < 0.06 ? 5 : 0); const grow = 3.4 + hgauss(r) * 0.9;
      const stay5 = r() < 0.3; const leaveAt = r() < 0.2 ? 1 + Math.floor(r() * 3) : 9;
      out.push({ id: tid + cy + pos + i, n: hpick(r, FIRST) + ' ' + hpick(r, LAST), pos, cy, start, grow, stay5, leaveAt, num: 1 + Math.floor(r() * 99) });
    }
  });
  return out;
}
function teamRoster(tid, year) {
  const key = tid + '@' + year + '@' + cs.seed; if (rosterCache.has(key)) return rosterCache.get(key);
  const adj = cs.league.teams[tid] ? (cs.league.teams[tid].rating - cs.league.teams[tid].base) * 0.35 : 0;
  const list = [];
  for (let cy = year - 4; cy <= year; cy++) {
    const k = year - cy;
    genClass(tid, cy).forEach(pl => {
      if (k >= pl.leaveAt) return; if (k === 4 && !pl.stay5) return;
      list.push({ id: pl.id, n: pl.n, pos: pl.pos, num: pl.num, cls: ['Fr', 'So', 'Jr', 'Sr', 'Gr'][k], ovr: Math.round(clamp(pl.start + pl.grow * k + adj, 38, 97)) });
    });
  }
  list.sort((a, b) => b.ovr - a.ovr);
  if (rosterCache.size > 400) rosterCache.clear();
  rosterCache.set(key, list); return list;
}
// High school teammates at the player's position (plus a few names for play-by-play).
function hsRoster(year) {
  const r = hrng(cs.seed + ':hs:' + year); const out = [];
  ['QB', 'RB', 'WR', 'WR', 'WR', 'TE', 'DE', 'DE', 'LB', 'LB', 'LB', 'CB', 'CB', 'S', 'S'].forEach((pos, i) => {
    for (let j = 0; j < 2; j++) { const c = Math.floor(r() * 4); out.push({ id: 'h' + year + i + j, n: hpick(r, FIRST) + ' ' + hpick(r, LAST), pos, cls: ['Fr', 'So', 'Jr', 'Sr'][c], ovr: Math.round(clamp(cs.hs.q - 9 + c * 3.5 + hgauss(r) * 4.5, 35, 72)) }); }
  });
  return out.sort((a, b) => b.ovr - a.ovr);
}
function mateName(pos, i) {
  const list = cs.lvl === 'hs' ? hsRoster(cs.year) : teamRoster(cs.col.tid, cs.year);
  const m = list.filter(x => x.pos === pos && !(pos === cs.p.pos && x.me)); const x = m[Math.min(i || 0, m.length - 1)];
  return x ? x.n : genName();
}
function oppName(tid, pos) {
  if (cs.lvl === 'hs' || !tid || isFcsId(tid) || !cs.league.teams[tid]) { const r = hrng(cs.seed + ':' + tid + ':' + pos + cs.year); return hpick(r, FIRST) + ' ' + hpick(r, LAST); }
  const m = teamRoster(tid, cs.year).filter(x => x.pos === pos); return m.length ? m[0].n : genName();
}

/* ---------- depth chart and playing time ---------- */
const ROT_SHARE = { QB: [1, 0.04], RB: [1, 0.45, 0.12], WR: [1, 1, 1, 0.35, 0.1], TE: [1, 0.35, 0.08], CB: [1, 1, 0.55, 0.1], S: [1, 1, 0.25, 0.08], DE: [1, 1, 0.4, 0.3, 0.08], LB: [1, 1, 1, 0.25, 0.08] };
function depthScore() { const p = cs.p; return cOvr(p) + (cs.lvl === 'col' ? (p.trust - 50) * 0.1 : 0); }
function myDepth() {
  const p = cs.p; const pos = p.pos;
  const mates = (cs.lvl === 'hs' ? hsRoster(cs.year) : teamRoster(cs.col.tid, cs.year)).filter(x => x.pos === pos);
  const me = { id: 'me', n: cName(p), pos, cls: cs.lvl === 'hs' ? ['Fr', 'So', 'Jr', 'Sr'][cs.hs.cls] : colCls(), ovr: cOvr(p), me: true, sc: depthScore() };
  const all = mates.map(m => Object.assign({ sc: m.ovr + ({ Sr: 0.6, Gr: 0.8, Jr: 0.3 }[m.cls] || 0) }, m)).concat([me]).sort((a, b) => b.sc - a.sc);
  const rank = all.findIndex(x => x.me);
  return { all, rank, me };
}
function myShare() {
  const p = cs.p; if (p.inj > 0) return 0;
  if (cs.lvl === 'col' && cs.col.rs && cs.ss.gp >= 4) return 0;
  const d = myDepth(); const s = ROT_SHARE[p.pos][d.rank];
  return s != null ? s : 0.04;
}
function roleOf(share) { return share >= 0.9 ? 'Starter' : share >= 0.3 ? 'Rotation' : share > 0 ? 'Backup' : 'Not playing'; }
function colCls() { const c = cs.col; if (!c) return ''; const yrs = c.years; const lbl = ['Fr', 'So', 'Jr', 'Sr', 'Sr'][Math.min(4, c.seasons)]; return (c.rsYear && c.years > c.seasons ? 'RS-' : '') + lbl + (yrs >= 5 ? ' (5th yr)' : ''); }

/* ---------- NIL ---------- */
function nilBase(stars) { return Math.exp(interp([[1, Math.log(3000)], [2, Math.log(15000)], [3, Math.log(60000)], [4, Math.log(230000)], [5, Math.log(480000)], [5.6, Math.log(700000)]], stars)); }
const NIL_POS = { QB: 2.6, WR: 1.1, DE: 1.2, CB: 1.05, RB: 0.9, S: 0.8, LB: 0.85, TE: 0.8 };
function schoolMoney(tid) { const t = cs.league.teams[tid]; const r = t ? t.rating : 55; const cm = tid === 'ND' ? 1.2 : CONF_NIL[CTEAMS0[tid].conf] || 0.4; return cm * clamp(0.7 + (r - 55) / 50, 0.6, 1.5); }
function nilOffer(tid, starsF, interest) {
  const j = 0.9 + hash(cs.seed + tid + cs.year + 'nil') * 0.2;
  const v = nilBase(Math.min(5.15, starsF)) * NIL_POS[cs.p.pos] * schoolMoney(tid) * (0.8 + clamp(interest, 0, 100) * 0.003) * j;
  return v < 2000 ? Math.round(v / 250) * 250 : v < 100000 ? Math.round(v / 1000) * 1000 : Math.round(v / 5000) * 5000;
}
const starsFloat = score => clamp(interp([[50, 0.6], [58, 2], [66, 3], [73, 4], [79, 5], [86, 5.6]], score), 0.6, 5.6);

/* ---------- recruiting (high school and the skip-to-college path) ---------- */
// Each school: interest 0-100 in the player, whether it has offered, its NIL offer and visits.
function teamTarget(tid) { return 60 + (teamLevel(tid) - 45) * 0.45; }
function startRecruiting(quick) {
  cs.rec = { schools: {}, committed: null, signed: null, visits: 0, offVisits: 0, visitLog: [], quick: !!quick, pulled: [] };
  Object.keys(cs.league.teams).forEach(id => cs.rec.schools[id] = { i: 0, off: false, nil: 0, v: 0, fav: false });
  if (quick) { cs.p.rec.score = cs.p.rec.fixed; cs.p.stars = starsOf(cs.p.rec.fixed); recruitTick('quick'); }
}
function proximity(tid) { const st = TEAM_STATE[tid]; const h = cs.p.home; return st === h ? 16 : REGION_OF[st] === REGION_OF[h] ? 7 : 0; }
function schoolInterest(tid, score) {
  const s = cs.rec.schools[tid]; const t = cs.league.teams[tid]; const T = teamTarget(tid);
  const fit = score - T; let i = 50 + clamp(fit, -12, 6) * 5 - Math.max(0, fit - 10) * 2;
  i += proximity(tid) + (t.need[cs.p.pos] - 1) * 14 + s.v * 12 + (cs.rec.committed === tid ? 15 : 0) + (s.bump || 0);
  return Math.round(clamp(i, 0, 100));
}
// A school offers players in its range. Far better players get the odd long-shot offer,
// mostly from schools close to home.
function canOffer(tid, score) { const gap = score - teamTarget(tid); return gap >= -4 - (cs.rec.schools[tid].v ? 2 : 0) && gap < 22; }
function fitWeight(tid, score) { const gap = score - teamTarget(tid); const w = gap < -4 ? 0 : gap < 0 ? 0.7 : gap <= 6 ? 1 : gap <= 10 ? 0.3 : gap <= 15 ? 0.08 : 0.02; return w * (proximity(tid) ? 2 : 1); }
// how many offers a prospect of this level ends up with, and how far along the calendar is
const offerTarget = score => interp([[52, 2], [58, 4], [66, 10], [73, 20], [79, 32], [86, 42]], score);
function offerTimeline(when) {
  if (when === 'quick') return 1; if (cs.lvl !== 'hs') return 1; const c = cs.hs.cls;
  const w = cs.phase === 'hs' ? Math.min(1, (cs.week - 1) / 10) : 1;
  return [[0, 0.06], [0.08, 0.25], [0.3, 0.7], [0.75, 1]][c].reduce((a, b, k) => k ? a + (b - a) * w : a, 0);
}
function recruitTick(when) {
  const p = cs.p; const score = cs.p.rec.fixed != null ? cs.p.rec.fixed : recruitScore(); p.rec.score = score;
  const sf = starsFloat(score); const out = []; const S = cs.rec.schools; const weekly = when === 'week';
  Object.keys(S).forEach(tid => {
    const s = S[tid]; s.i = schoolInterest(tid, score);
    if (s.off) {
      s.nil = Math.max(s.nil, nilOffer(tid, sf, s.i));
      // a school can move on if the player falls well below what it needs, or it fills the spot
      if (cs.rec.committed !== tid && !cs.rec.signed && (score < teamTarget(tid) - 8 || (weekly && s.i < 40 && R() < 0.01))) { s.off = false; s.nil = 0; cs.rec.pulled.push(tid); out.push(['pulled', tid]); }
    }
  });
  const minFr = score >= 75 ? 1 : 0;
  const want = Math.round(offerTarget(score) * (cs.lvl === 'hs' && cs.hs.cls === 0 && !minFr ? 0 : offerTimeline(when)));
  let have = Object.values(S).filter(s => s.off).length;
  const pool = Object.keys(S).filter(tid => !S[tid].off && canOffer(tid, score) && !cs.rec.pulled.includes(tid)).map(tid => [tid, fitWeight(tid, score) * (0.3 + S[tid].i / 100)]).filter(x => x[1] > 0);
  let guard = 0;
  while (have < want && pool.length && guard++ < 80) {
    const tid = wpick(pool); const k = pool.findIndex(x => x[0] === tid); pool.splice(k, 1);
    if (weekly && R() < 0.5) continue;
    S[tid].off = true; S[tid].nil = nilOffer(tid, sf, S[tid].i); have++; out.push(['offer', tid]);
  }
  // nobody reaches signing day without a place to play
  if ((when === 'quick' || (cs.lvl === 'hs' && cs.hs.cls >= 3 && cs.phase === 'hsoff')) && have < 3) {
    Object.keys(S).filter(t => !S[t].off).sort((a, b) => Math.abs(teamTarget(a) - score - 2) - Math.abs(teamTarget(b) - score - 2) || proximity(b) - proximity(a)).slice(0, 3 - have).forEach(tid => { S[tid].off = true; S[tid].nil = nilOffer(tid, sf, Math.max(45, S[tid].i)); out.push(['offer', tid]); });
  }
  const c = cs.rec.committed;
  if (c && !S[c].off) { cs.rec.committed = null; out.push(['decommitted', c]); }
  return out;
}
function offersList() { return Object.entries(cs.rec.schools).filter(([, s]) => s.off).map(([id, s]) => Object.assign({ id }, s)).sort((a, b) => b.i - a.i || teamLevel(b.id) - teamLevel(a.id)); }
// how the depth chart at a school looks for the player's first year there
function depthOutlook(tid, year, ovrThen) {
  const r = teamRoster(tid, year).filter(x => x.pos === cs.p.pos).map(x => x.ovr + ({ Sr: 0.6, Gr: 0.8, Jr: 0.3 }[x.cls] || 0)).sort((a, b) => b - a);
  const n = START_N[cs.p.pos]; const cut = r[n - 1] || 0; const ahead = r.filter(v => v > ovrThen).length;
  if (ovrThen >= cut + 1) return { k: 'start', txt: 'Could start right away', ahead };
  if (ovrThen >= cut - 3) return { k: 'compete', txt: 'Competes for a starting job', ahead };
  if (ovrThen >= cut - 8) return { k: 'rotate', txt: 'Rotation or backup at first', ahead };
  return { k: 'deep', txt: 'Deep depth chart, likely redshirt', ahead };
}
function projOvrAtCollege() { return cs.lvl === 'hs' ? cOvr(cs.p) + growthLeft() * 0.9 : cOvr(cs.p); }
const MAX_UNOFFICIAL = 3, MAX_OFFICIAL = 5;
function canVisit(tid) {
  const s = cs.rec.schools[tid]; if (!s) return 'unknown';
  if (cs.portal) return 'portal'; if (cs.rec.signed) return 'signed';
  if (s.v >= 2) return 'done';
  const hs = cs.lvl === 'hs';
  const official = !hs || cs.hs.cls >= 3 || (cs.phase === 'hsoff' && cs.hs.cls >= 2);
  if (hs && cs.phase === 'hs' && !official) return 'season';
  if (official) return cs.rec.offVisits >= MAX_OFFICIAL ? 'limit' : 'official';
  return (cs.rec.uv && cs.rec.uv.y === cs.year ? cs.rec.uv.n : 0) >= MAX_UNOFFICIAL ? 'limit' : 'unofficial';
}
function doVisit(tid) {
  const k = canVisit(tid); if (k !== 'official' && k !== 'unofficial') return null;
  const s = cs.rec.schools[tid]; s.v++; if (k === 'official') cs.rec.offVisits++; else { if (!cs.rec.uv || cs.rec.uv.y !== cs.year) cs.rec.uv = { y: cs.year, n: 0 }; cs.rec.uv.n++; }
  const t = cs.league.teams[tid]; const score = cs.p.rec.score;
  s.i = schoolInterest(tid, score); const before = s.off;
  if (!s.off && canOffer(tid, score) && s.i >= 45 && R() < 0.35 + s.i / 250) { s.off = true; }
  if (s.off) s.nil = Math.round(Math.max(s.nil, nilOffer(tid, starsFloat(score), s.i)) * 1.08 / 1000) * 1000 || s.nil;
  const d = depthOutlook(tid, cs.lvl === 'hs' ? cs.year + (4 - cs.hs.cls) : cs.year + 1, projOvrAtCollege());
  const rep = { tid, kind: k, year: cs.year, offer: s.off && !before, coach: t.coach, rec: t.w + '-' + t.l, depth: d.txt, nil: s.off ? s.nil : 0 };
  cs.rec.visitLog.unshift(rep);
  cNews(`${k === 'official' ? 'Official' : 'Unofficial'} visit to ${t.name}.${rep.offer ? ' They offered a scholarship on the spot.' : ''}`, rep.offer ? 'win' : '');
  return rep;
}
function commitTo(tid) {
  const s = cs.rec.schools[tid]; if (!s || !s.off || cs.rec.signed) return false;
  const prev = cs.rec.committed; if (prev === tid) return false;
  if (prev) { cs.rec.schools[prev].bump = (cs.rec.schools[prev].bump || 0) - 20; cNews(`${cName(cs.p)} backs out of his commitment to ${cTeamName(prev)}.`, 'bad'); }
  cs.rec.committed = tid; s.i = schoolInterest(tid, cs.p.rec.score);
  cNews(`${cName(cs.p)} commits to ${cTeamName(tid)}${s.nil ? ' (NIL: ' + money(s.nil) + ' a year)' : ''}.`, 'big');
  return true;
}
function decommit() { const c = cs.rec.committed; if (!c || cs.rec.signed) return false; cs.rec.committed = null; cs.rec.schools[c].bump = (cs.rec.schools[c].bump || 0) - 20; cNews(`${cName(cs.p)} decommits from ${cTeamName(c)} and reopens his recruitment.`, 'bad'); return true; }
// Ask a school for more NIL money. It works more often when the school is very interested,
// but pushing too hard costs interest.
function negotiate(tid) {
  const s = cs.rec.schools[tid]; if (!s || !s.off || s.asked >= 2) return null;
  s.asked = (s.asked || 0) + 1;
  const pOk = clamp(0.2 + (s.i - 50) / 80 - (s.asked - 1) * 0.15, 0.08, 0.8);
  if (R() < pOk) { const raise = Math.round(s.nil * (0.1 + R() * 0.15) / 1000) * 1000 || 500; s.nil += raise; return { ok: true, raise }; }
  s.bump = (s.bump || 0) - 6; s.i = Math.max(0, s.i - 6); return { ok: false };
}

/* ---------- high school ---------- */
function hsNewSeason() {
  const h = cs.hs; const r = hrng(cs.seed + ':hsyr:' + cs.year);
  h.teamQ = r1(h.q + hgauss(r) * 3); h.w = 0; h.l = 0; h.po = null;
  const used = new Set(); const opp = () => { let n; do n = hpick(r, HS_PLACES) + ' ' + hpick(r, HS_MASCOTS); while (used.has(n) || n.startsWith(h.name.replace(' High', ''))); used.add(n); return n; };
  h.sched = [];
  for (let wk = 1; wk <= 10; wk++) h.sched.push({ wk, opp: opp(), oq: r1(clamp(h.q - 2 + hgauss(r) * 5, 42, 72)), home: wk % 2 === 1, done: false, type: wk >= 8 ? 'district' : 'reg' });
  // spotlight: the three toughest regular-season games plus any playoff games
  h.sched.slice().sort((a, b) => b.oq - a.oq).slice(0, 3).forEach(g => g.big = true);
  cs.week = 1; cs.phase = 'hs'; cs.ss = newSS(); cs.p.inj = 0; cs.p.injName = '';
  if (cs.league.week > 1 || cs.league.year !== cs.year) { /* league already aligned by rollover */ }
}
function newSS() { return { gp: 0, gs: 0, st: {}, games: [], ratios: [] }; }
function hsGameThisWeek() { return cs.phase === 'hs' ? cs.hs.sched.find(g => g.wk === cs.week && !g.done) : null; }
function hsAfterGame() {
  const h = cs.hs;
  if (cs.week === 10) {
    const qual = h.w >= 7 || (h.w === 6 && R() < 0.5);
    if (qual) { h.po = { round: 1 }; hsAddPlayoff(11, 1); cNews(`${h.name} (${h.w}-${h.l}) makes the state playoffs.`, 'win'); }
    else cNews(`${h.name} finishes ${h.w}-${h.l} and misses the playoffs.`);
  } else if (h.po && cs.week >= 11) {
    const g = h.sched.find(x => x.wk === cs.week); const won = g.us > g.them;
    if (won && h.po.round < 4) { h.po.round++; hsAddPlayoff(cs.week + 1, h.po.round); }
    else if (won) { h.titles++; h.po.champ = true; cs.p.awards.push({ y: cs.year, lvl: 'hs', a: 'State champion' }); cNews(`${h.name} wins the state championship!`, 'big'); }
    else h.po.out = true;
  }
}
function hsAddPlayoff(wk, round) {
  const r = hrng(cs.seed + ':po:' + cs.year + round); const nm = ['State playoffs, first round', 'State quarterfinal', 'State semifinal', 'State championship'][round - 1];
  cs.hs.sched.push({ wk, opp: hpick(r, HS_PLACES) + ' ' + hpick(r, HS_MASCOTS), oq: r1(clamp(cs.hs.q + round * 2.2 + hgauss(r) * 3, 48, 76)), home: round < 4 && R() < 0.5, neutral: round === 4, done: false, type: 'playoff', name: nm, big: true });
}
function hsSeasonOver() { const h = cs.hs; return cs.week > 10 && (!h.po || h.po.out || h.po.champ) && !hsGameThisWeek(); }

/* ---------- college ---------- */
function enrollCollege(tid) {
  const s = cs.rec.schools[tid];
  cs.col = { tid, years: 1, seasons: 0, rsYear: false, rs: false, trust0: 50, lastRatio: null, teams: [tid], nil: s ? s.nil : 0, coach: cs.league.teams[tid].coach, transfers: 0 };
  cs.rec.signed = tid; cs.lvl = 'col'; cs.p.trust = 50 + (cs.p.stars >= 5 ? 6 : cs.p.stars >= 4 ? 3 : 0);
  cs.p.stars0 = cs.p.stars; cs.p.score0 = cs.p.rec.score;
}
function myColGame() { return cs.league.games.find(g => g.wk === cs.week && !g.done && (g.h === cs.col.tid || g.a === cs.col.tid)); }
function myColGames() { return cs.league.games.filter(g => g.h === cs.col.tid || g.a === cs.col.tid).sort((a, b) => a.wk - b.wk); }
function colSeasonOver() { const t = cs.col.tid; return cs.week > 14 && !cs.league.games.some(g => !g.done && (g.h === t || g.a === t)) && !(cs.week <= 17 && cs.league.week <= 17 && pendingRoundFor(t)); }
// a team still alive in the playoff may get another game after this week's results
function pendingRoundFor(t) { const L = cs.league; if (!L.cfp || !L.cfp.seeds.includes(t)) return false; const games = L.games.filter(g => g.type === 'cfp' && (g.h === t || g.a === t)); const last = games[games.length - 1]; if (!last) return L.cfp.seeds.indexOf(t) < 4; if (!last.done) return true; return (last.hs > last.as ? last.h : last.a) === t && last.round < 4; }
// cs.col.years is the college year about to be (or being) played; the five-year clock and the
// three-years-out-of-high-school draft rule count completed years.
function eligibilityLeft() { const c = cs.col; return Math.max(0, Math.min(4 - c.seasons, 6 - c.years)); }
function draftEligible() { return cs.col && cs.col.years - 1 >= 3; }
function outOfEligibility() { return cs.col && (cs.col.seasons >= 4 || cs.col.years >= 6); }

/* ---------- skill points ---------- */
function upgrade(k, n) {
  const p = cs.p; let done = 0;
  for (let i = 0; i < (n || 1); i++) { const v = p.a[k]; if (v == null || v >= CATTR_MAX) break; const c = cCost(v); if (p.xp < c) break; p.xp -= c; p.a[k] = v + 1; done++; }
  return done;
}
// Spend points the way the play style would: best value per point first.
function autoAssign() {
  const p = cs.p; const w = CWT[p.pos]; const tilt = cStyle(p)[3]; let guard = 0;
  while (guard++ < 500) {
    let best = null;
    for (const [k] of CATTR[p.pos]) { const v = p.a[k]; if (v >= CATTR_MAX) continue; const c = cCost(v); if (c > p.xp) continue; const val = (w[k] + (tilt[k] > 0 ? 0.05 : 0)) / c - (v - 60) * 0.0006; if (!best || val > best.val) best = { k, val }; }
    if (!best) break; upgrade(best.k);
  }
}
function grantXP(n, why) { const g = Math.round(n * cdiff().xp); cs.p.xp += g; if (cs.p.auto) autoAssign(); return g; }
function naturalGrowth(amount) { const p = cs.p; CATTR[p.pos].forEach(([k]) => { p.a[k] = clamp(p.a[k] + Math.round(amount + gauss() * 0.7), 20, CATTR_MAX); }); }

/* ---------- training purchases (NIL money) ---------- */
// Prices scale with the player's NIL deal, so they matter whether he earns $5K or $2M a year.
const TRAIN = [
  { id: 'coach', name: 'Private position coach', desc: 'One-on-one work all offseason. +10 skill points.', xp: 10, min: 2000, pct: 0.06 },
  { id: 'speed', name: 'Speed and strength program', desc: '+2 to your two physical ratings.', phys: 2, min: 3500, pct: 0.1 },
  { id: 'film', name: 'Film study package', desc: '+3 to your read-the-play rating, and your coach notices.', read: 3, trust: 3, min: 1500, pct: 0.04 },
  { id: 'recovery', name: 'Recovery and nutrition staff', desc: 'Fewer and shorter injuries next season.', rec: true, min: 2500, pct: 0.07 },
  { id: 'guru', name: 'Elite trainer (the pros use him)', desc: 'A big jump: +26 skill points.', xp: 26, min: 9000, pct: 0.25 },
];
function trainCost(t) { const base = cs.col ? cs.col.nil : 0; const v = Math.max(t.min, base * t.pct); return v < 10000 ? Math.round(v / 100) * 100 : Math.round(v / 1000) * 1000; }
const PHYS = { QB: ['arm', 'mob'], RB: ['spd', 'pow'], WR: ['spd', 'rel'], TE: ['pow', 'spd'], CB: ['spd', 'prs'], S: ['spd', 'tkl'], DE: ['bst', 'pow'], LB: ['spd', 'tkl'] };
function buyTraining(id) {
  const t = TRAIN.find(x => x.id === id); const p = cs.p; cs.bought = cs.bought || {};
  const cost = t ? trainCost(t) : 0;
  if (!t || cs.bought[id] === cs.year || p.bank < cost) return false;
  p.bank -= cost; p.spent += cost; cs.bought[id] = cs.year;
  if (t.xp) grantXP(t.xp); if (t.phys) PHYS[p.pos].forEach(k => p.a[k] = Math.min(CATTR_MAX, p.a[k] + t.phys));
  if (t.read) p.a[CREAD[p.pos]] = Math.min(CATTR_MAX, p.a[CREAD[p.pos]] + t.read); if (t.trust) p.trust = clamp(p.trust + t.trust, 0, 100);
  if (t.rec) cs.recovery = cs.year + 1;
  cs.nilLog.unshift({ y: cs.year, txt: t.name, amt: -cost });
  return true;
}
function payNil(amt, txt) { cs.p.bank += amt; cs.p.earned += amt; cs.nilLog.unshift({ y: cs.year, txt, amt }); if (cs.nilLog.length > 80) cs.nilLog.length = 80; }

/* ---------- this week's game ---------- */
function hsAbbr(name) { const w = String(name).replace(/ High$/, '').split(/\s+/); return (w.length > 1 ? w.map(x => x[0]).join('') : w[0].slice(0, 4)).toUpperCase().slice(0, 4); }
function myGameSpec() {
  if (cs.phase === 'hs') {
    const g = hsGameThisWeek(); if (!g) return null; const h = cs.hs;
    const me = { off: h.teamQ + 0.8, def: h.teamQ - 0.8 }, op = { off: g.oq, def: g.oq };
    const myHome = g.home || g.neutral;
    const hsName = h.name + ' ' + h.mascot;
    return { lvl: 'hs', wk: g.wk, home: myHome, neutral: !!g.neutral, name: g.name || '', type: g.type, ids: myHome ? [hsAbbr(h.name), hsAbbr(g.opp)] : [hsAbbr(g.opp), hsAbbr(h.name)], names: myHome ? [hsName, g.opp] : [g.opp, hsName], base: myHome ? [me, op] : [op, me], oppTid: 'HS:' + g.opp, hsIdx: h.sched.indexOf(g), big: !!g.big };
  }
  if (cs.phase === 'col') {
    const g = myColGame(); if (!g) return null; const L = cs.league; const tid = cs.col.tid;
    const myHome = g.h === tid; const opp = myHome ? g.a : g.h;
    return { lvl: 'col', wk: g.wk, home: myHome, neutral: !!g.neutral, name: g.name || '', type: g.type, ids: [g.h, g.a].map(x => isFcsId(x) ? 'FCS' : x), names: [cTeamName(g.h), cTeamName(g.a)], base: [lgStrength(L, g.h), lgStrength(L, g.a)], oppTid: opp, lgId: g.id, big: g.type !== 'reg' || (L.teams[opp] && L.teams[opp].ap > 0) };
  }
  return null;
}
function cStartGame() { const sp = myGameSpec(); if (!sp) return null; cs.liveWk = cs.week; cs.liveRng = RNG.s; cg = cgNew(sp); cg.spec = sp; return cg; }
// Apply a finished game: score, record, stats, development, trust, injuries.
function cFinishGame(g) {
  const sp = g.spec; const mi = g.mi; const us = g.pts[mi], them = g.pts[1 - mi]; const won = us > them;
  cs.liveWk = null; cs.liveRng = null;
  if (sp.lvl === 'hs') { const hg = cs.hs.sched[sp.hsIdx]; hg.done = true; hg.us = us; hg.them = them; if (won) cs.hs.w++; else cs.hs.l++; }
  else { const lg = cs.league.games.find(x => x.id === sp.lgId); lg.hs = g.pts[0]; lg.as = g.pts[1]; lg.ot = g.ot; lgApply(cs.league, lg); }
  const ss = cs.ss; const played = g.share > 0 && !!g.decN + Object.keys(g.line).length >= 0 && g.share > 0;
  const opp = sp.lvl === 'hs' ? sp.oppTid.slice(3) : sp.oppTid;
  const rec = { wk: sp.wk, opp, home: sp.home, neutral: sp.neutral, name: sp.name, us, them, w: won, line: g.line, grade: g.grade ? g.grade[1] : null, ratio: g.ratio, role: g.role, plays: g.plays.slice(-4) };
  ss.games.push(rec);
  let xp = 0; let trust = 0;
  if (played) {
    ss.gp++; if (g.share >= 0.9) ss.gs++;
    Object.entries(g.line).forEach(([k, v]) => ss.st[k] = (ss.st[k] || 0) + v);
    ss.imp = (ss.imp || 0) + impactPts(g.line, cs.p.pos);
    if (g.ratio != null) { ss.gImp = (ss.gImp || 0) + impactPts(g.line, cs.p.pos); ss.expImp = (ss.expImp || 0) + EXP_IMP[cs.p.pos] * expectedUsage(g); }
    if (g.ratio != null) ss.ratios.push(g.ratio);
    xp = g.grade ? (cs.lvl === 'hs' ? { 'A+': 5, A: 4.3, B: 3.3, C: 2.6, D: 2, F: 1.5 } : { 'A+': 4, A: 3.5, B: 3, C: 2.5, D: 2, F: 1.5 })[g.grade[1]] : 1.5;
    trust = ({ 'A+': 4, A: 3, B: 1, C: 0, D: -2, F: -3 }[g.grade ? g.grade[1] : 'C'] || 0) + g.trust;
  } else xp = cs.lvl === 'col' && cs.col.rs ? 2 : 1.2;
  rec.xp = grantXP(xp);
  if (cs.lvl === 'col') { cs.p.trust = clamp(cs.p.trust + trust, 0, 100); rec.trust = trust; }
  // injuries
  if (played) {
    const base = 0.014 + (['RB', 'DE', 'LB'].includes(cs.p.pos) ? 0.008 : 0);
    if (R() < base * (cs.recovery === cs.year ? 0.6 : 1)) {
      const t = wpick(INJ_TYPES.map(x => [x, x[3]])); const wks = t[1] >= 99 ? 30 : ri(t[1], t[2]) + (cs.recovery === cs.year ? 0 : 1);
      cs.p.inj = wks; cs.p.injName = t[0]; rec.inj = t[0];
      if (t[1] >= 99) { PHYS[cs.p.pos].forEach(k => cs.p.a[k] = Math.max(30, cs.p.a[k] - 2)); cNews(`${cName(cs.p)} suffers a ${t[0].toLowerCase()} and is out for the season.`, 'bad'); }
      else cNews(`${cName(cs.p)} is out ${wks} week${wks > 1 ? 's' : ''} with a ${t[0].toLowerCase()}.`, 'bad');
    }
  }
  if (played && g.grade && (g.grade[1] === 'A+' || (g.grade[1] === 'A' && R() < 0.4))) cNews(`${cName(cs.p)} stars in a ${us}–${them} ${won ? 'win over' : 'loss to'} ${sp.lvl === 'hs' ? opp : cTeamName(opp)}: ${lineText(g.line, cs.p.pos)}.`, 'win');
  if (sp.lvl === 'col' && cs.col.nil && sp.wk <= 13) { }
  cg = null;
  return rec;
}
function cByeOrNoGame() { if (cs.p.inj > 0) { } grantXP(cs.lvl === 'col' && cs.col && cs.col.rs ? 2 : 1); }
function cEndWeek() {
  const wk = cs.week; const L = cs.league;
  if (L.week === wk && wk <= 18) { lgSimWeek(L, wk, null); lgAfterWeek(L, wk); }
  if (cs.p.inj > 0) { cs.p.inj--; if (!cs.p.inj) { cNews(`${cName(cs.p)} is cleared to play.`); cs.p.injName = ''; } }
  if (cs.phase === 'hs') {
    hsAfterGame();
    if (cs.hs.cls >= 1) recruitTick('week').forEach(([k, tid]) => { if (k === 'offer' && teamLevel(tid) >= 70) cNews(`${cTeamName(tid)} offers ${cName(cs.p)} a scholarship.`, 'win'); if (k === 'pulled') cNews(`${cTeamName(tid)} pulls its scholarship offer.`, 'bad'); });
  }
  if (cs.phase === 'col' && wk <= 13 && cs.col.nil) payNil(Math.round(cs.col.nil / 13), `NIL payment, ${cTeamName(cs.col.tid)}`);
  cs.week++;
  cMaybeEvent();
  if (cs.phase === 'hs' && hsSeasonOver()) hsEndSeason();
  else if (cs.phase === 'col' && colSeasonOver()) colEndSeason();
}
// Play (or sim) this week. Returns the game record, or null for a bye week.
function cSimWeek() {
  if (cs.event) cResolveEvent(0);
  const g = cStartGame(); let rec = null;
  if (g) { cgAutoplay(g); rec = cFinishGame(g); } else cByeOrNoGame();
  cEndWeek();
  return rec;
}
function cInSeason() { return cs.phase === 'hs' || cs.phase === 'col'; }

/* ---------- random events ---------- */
const CEVENTS = [
  { id: 'film', lvl: 'col', txt: 'The veterans invite you to a late film session the night before a big exam.', opts: [['Go to film', 'Coaches notice. You lose a little sleep.', () => { cs.p.trust += 3; grantXP(1); }], ['Study for the exam', 'Stay on top of your classes.', () => { grantXP(1); }]] },
  { id: 'sign', lvl: 'col', cond: () => cs.p.stars >= 3 || cs.p.bank > 0, txt: () => `A booster wants you at a paid autograph signing during a practice day. It pays ${money(1500 + cs.p.stars * 1500)}.`, opts: [['Take the money', 'Easy cash, but you miss practice.', () => { payNil(1500 + cs.p.stars * 1500, 'Autograph signing'); cs.p.trust -= 3; }], ['Stay at practice', 'Your coach likes the commitment.', () => { cs.p.trust += 2; }]] },
  { id: 'sore', lvl: 'any', txt: 'You\'re banged up after last week. The trainer says you can sit out practice.', opts: [['Rest', 'Heal up. Lose a bit of practice time.', () => { }], ['Push through', 'Earn respect. A little more injury risk.', () => { grantXP(2); if (cs.lvl === 'col') cs.p.trust += 2; if (R() < 0.12) { cs.p.inj = 1; cs.p.injName = 'Hamstring strain'; cNews(`${cName(cs.p)} tweaks a hamstring in practice and will miss a week.`, 'bad'); } }]] },
  { id: 'media', lvl: 'col', txt: 'A reporter asks about the competition for playing time at your position.', opts: [['Stay humble', '"Whatever helps the team."', () => { cs.p.trust += 2; }], ['Talk yourself up', 'Fans love it. Your coach doesn\'t.', () => { cs.p.trust -= 2; payNil(1000 + cs.p.stars * 800, 'Social media deal after viral interview'); }]] },
  { id: 'extra', lvl: 'any', txt: 'Your position coach offers extra drills before school, every day for a week.', opts: [['Sign up', 'More reps, less sleep.', () => { grantXP(3); if (cs.lvl === 'col') cs.p.trust += 1; }], ['Pass', 'Stay fresh.', () => { }]] },
  { id: 'camp7', lvl: 'hs', cond: () => cs.hs.cls >= 1, txt: 'A college coach is at practice this week to watch you.', opts: [['Put on a show', 'Go all out. Could help your recruitment.', () => { const top = Object.keys(cs.rec.schools).sort((a, b) => teamLevel(b) - teamLevel(a)).find(t => canOffer(t, cs.p.rec.score || 60)); if (top) { cs.rec.schools[top].bump = (cs.rec.schools[top].bump || 0) + 8; cNews(`${cTeamName(top)} is paying close attention after watching practice.`); } grantXP(1); }], ['Practice like normal', 'Don\'t change what works.', () => { grantXP(2); }]] },
];
function cMaybeEvent() {
  if (cs.event || !cInSeason()) return;
  if (R() > (cs.lvl === 'col' ? 0.12 : 0.08)) return;
  const opts = CEVENTS.filter(e => (e.lvl === 'any' || e.lvl === cs.lvl) && (!e.cond || e.cond()));
  if (!opts.length) return; const e = pick(opts);
  cs.event = { id: e.id, txt: typeof e.txt === 'function' ? e.txt() : e.txt };
}
function cResolveEvent(i) { const ev = cs.event; if (!ev) return; const e = CEVENTS.find(x => x.id === ev.id); cs.event = null; if (!e) return; const o = e.opts[i] || e.opts[0]; o[2](); cs.p.trust = clamp(cs.p.trust, 0, 100); return o[0]; }

/* ---------- end of a season ---------- */
function seasonRatio(ss) { return ss.expImp ? (ss.gImp != null ? ss.gImp : ss.imp) / ss.expImp : null; }
function archiveSeason(extra) {
  const ss = cs.ss; const p = cs.p; const lvl = cs.lvl;
  const team = lvl === 'hs' ? cs.hs.name : cs.col.tid;
  const recStr = lvl === 'hs' ? cs.hs.w + '-' + cs.hs.l : LT(cs.col.tid).w + '-' + LT(cs.col.tid).l;
  const e = Object.assign({ year: cs.year, lvl, team, cls: lvl === 'hs' ? HS_CLS[cs.hs.cls] : colCls(), gp: ss.gp, gs: ss.gs, st: Object.assign({}, ss.st), ovr: cOvr(p), stars: p.stars, rec: recStr, ratio: seasonRatio(ss), awards: [] }, extra || {});
  p.seasons.push(e); return e;
}
function giveAward(e, name, cash) { e.awards.push(name); cs.p.awards.push({ y: e.year, lvl: e.lvl, a: name }); if (cash) payNil(cash, name + ' endorsements'); }
function hsEndSeason() {
  const h = cs.hs; const ss = cs.ss; const p = cs.p;
  const sr = seasonRatio(ss); const e = archiveSeason({ po: h.po ? (h.po.champ ? 'State champions' : 'Playoffs, round ' + h.po.round) : 'No playoffs' });
  const before = p.stars;
  p.rec.prod = ss.gp >= 4 && sr != null ? r1(clamp((sr - 1.1) * 3, -2, 2.5)) : ss.gp < 2 ? -1 : 0;
  if (ss.gp >= 5 && sr != null && ss.gs >= 5) {
    const as = sr + (recruitScore() - 72) * 0.06;
    if (as >= 2.1 && cs.hs.cls === 3 && p.stars >= 4 && R() < 0.6) giveAward(e, `Mr. Football (${CSTATES[p.home]})`);
    if (as >= 1.7) giveAward(e, 'All-State'); else if (as >= 1.25) giveAward(e, 'All-Conference');
  }
  if (cs.hs.cls === 2 && recruitScore() >= 77.5) { p.rec.aa = 1.5; giveAward(e, 'All-American Bowl invitation'); }
  p.rec.camp = r1((p.rec.camp || 0) * 0.5);
  p.rec.score = recruitScore(); p.stars = starsOf(p.rec.score); p.starsHist = (p.starsHist || []).concat([[cs.year, p.stars]]);
  e.stars = p.stars;
  // the rest of the college season plays out, then the calendar turns over
  lgFinishSeason(cs.league); const champ = cs.league.champ; const changes = lgRollover(cs.league);
  cs.year = cs.league.year;
  const offers = recruitTick('off');
  cs.phase = 'hsoff'; cs.week = 0;
  const steps = h.cls >= 3 ? ['review', 'signing'] : ['review', 'recruit', 'camp', 'train'];
  cs.off = { steps, i: 0, review: { year: e.year, e, before, after: p.stars, champ, newOffers: offers.filter(x => x[0] === 'offer').map(x => x[1]) }, grown: false };
  cNews(`${cName(p)} finishes his ${HS_CLS[h.cls].toLowerCase()} season: ${p.stars}-star ${p.pos}${p.stars !== before && h.cls > 0 ? (p.stars > before ? ' (up from ' + before + ')' : ' (down from ' + before + ')') : ''}.`, p.stars > before ? 'win' : '');
  if (champ) cNews(`${cTeamName(champ)} win the ${e.year} national championship.`);
  void changes;
}
function colEndSeason() {
  const ss = cs.ss; const p = cs.p; const c = cs.col; const L = cs.league;
  lgFinishSeason(L);
  const sr = seasonRatio(ss); const e = archiveSeason({ team: c.tid });
  const t = L.teams[c.tid]; e.rec = t.w + '-' + t.l; e.rank = t.ap || 0;
  const post = L.games.filter(g => (g.h === c.tid || g.a === c.tid) && g.type !== 'reg').map(g => g.name + ' (' + ((g.h === c.tid ? g.hs > g.as : g.as > g.hs) ? 'W' : 'L') + ')');
  e.post = post.join(', '); if (L.champ === c.tid) { e.awards.push('National champions'); p.awards.push({ y: e.year, lvl: 'col', a: 'National champion' }); }
  // awards
  const heis = heismanVote(e, sr); L.heis = heis.winner;
  if (ss.gp >= 8 && sr != null) {
    const first = c.years === 1 && c.seasons === 0;
    // national awards weigh the level of play as well as production
    const aw = sr + (cOvr(p) - 82) * 0.03 + (p4Team(c.tid) ? 0.08 : -0.18);
    if (heis.mine === 1) giveAward(e, 'Heisman Trophy', 1500000); else if (heis.mine && heis.mine <= 4) giveAward(e, 'Heisman finalist', 250000);
    const pa = { QB: 'Davey O\'Brien Award', RB: 'Doak Walker Award', WR: 'Biletnikoff Award', TE: 'John Mackey Award', CB: 'Jim Thorpe Award', S: 'Jim Thorpe Award', DE: 'Ted Hendricks Award', LB: 'Butkus Award' }[p.pos];
    if (aw >= 1.62 || (aw >= 1.5 && R() < 0.4)) giveAward(e, pa, 100000);
    if (aw >= 1.5) giveAward(e, 'First-team All-American', 120000); else if (aw >= 1.35) giveAward(e, 'Second-team All-American', 40000);
    const cn = CONF_HONOR[t.conf];
    if (cn && sr >= 1.25) giveAward(e, 'First-team ' + cn); else if (cn && sr >= 1.1) giveAward(e, 'Second-team ' + cn);
    if (first && aw >= 1.12) giveAward(e, 'Freshman All-American');
  }
  c.lastRatio = sr != null && ss.gp >= 4 ? sr : c.lastRatio; c.best = Math.max(c.best || 0, sr != null && ss.gp >= 6 ? sr : 0);
  // eligibility: a redshirt year (four games or fewer) doesn't count
  if (ss.gp <= 4 && !c.rsYear) { c.rsYear = true; e.rs = true; e.cls += ' (redshirt)'; if (!c.rs) cNews(`${cName(p)} played in ${ss.gp} game${ss.gp === 1 ? '' : 's'}, so the season counts as his redshirt year.`); } else c.seasons++;
  c.years++; c.rs = false;
  const champ = L.champ; const changes = lgRollover(L); cs.year = L.year;
  const mine = changes.find(x => x.id === c.tid);
  if (mine) { p.trust = 45; c.coach = LT(c.tid).coach; cNews(`${cTeamName(c.tid)} ${mine.why === 'fired' ? 'fires' : 'loses'} head coach ${mine.old}. ${mine.now} takes over, and every job is open again.`, 'bad'); }
  p.inj = p.inj > 12 ? 0 : 0; p.injName = '';
  cs.phase = 'coloff'; cs.week = 0;
  const steps = ['review']; if (draftEligible() || outOfEligibility()) steps.push('draft'); if (!outOfEligibility()) steps.push('portal', 'train');
  cs.off = { steps, i: 0, review: { year: e.year, e, heis, champ, coach: mine || null, post: e.post }, grown: false };
  if (champ) cNews(`${cTeamName(champ)} win the ${e.year} national championship.`, champ === c.tid ? 'big' : '');
}
function heismanVote(e, sr) {
  const L = cs.league; const p = cs.p; const t = L.teams[cs.col.tid];
  const mult = ({ QB: 1, RB: 0.95, WR: 0.9, TE: 0.6, CB: 0.55, S: 0.5, DE: 0.6, LB: 0.55 })[p.pos];
  const my = (cs.ss.imp || 0) * mult * (1 + (t.w - 8) * 0.05) * (t.ap && t.ap <= 6 ? 1.08 : 1) * (p4Team(cs.col.tid) ? 1 : 0.82);
  const tops = Object.values(L.teams).filter(x => x.ap && x.id !== cs.col.tid).sort((a, b) => a.ap - b.ap).slice(0, 10);
  const cands = tops.slice(0, 8).map((x, i) => { const pos = pick(['QB', 'QB', 'QB', 'RB', 'WR']); const n = oppName(x.id, pos); return { n, pos, tid: x.id, sc: 355 - i * 9 + gauss() * 36 }; });
  cands.push({ n: cName(p), pos: p.pos, tid: cs.col.tid, sc: my, me: true });
  cands.sort((a, b) => b.sc - a.sc);
  const mine = cs.ss.gp >= 8 ? cands.findIndex(x => x.me) + 1 : 0;
  return { list: cands.slice(0, 5).map(x => ({ n: x.n, pos: x.pos, tid: x.tid, me: !!x.me })), mine, winner: { n: cands[0].n, tid: cands[0].tid, pos: cands[0].pos } };
}

/* ---------- offseason steps ---------- */
const OFF_LABEL = { review: 'Season review', recruit: 'Recruiting', camp: 'Summer camps', train: 'Offseason training', signing: 'Signing day', draft: 'NFL Draft decision', portal: 'Transfer portal' };
function offStep() { return cs.off ? cs.off.steps[cs.off.i] : null; }
// Returns an error message if the current step still needs a choice.
function offBlocked() {
  const s = offStep();
  if (s === 'signing') return 'Choose where you\'ll sign first.';
  if (s === 'draft' && !cs.off.draftChoice) return 'Decide whether to enter the draft first.';
  if (s === 'portal' && cs.portal && !cs.portal.done) return 'Pick your new school from the portal first.';
  if (s === 'camp' && !cs.off.camp) return 'Choose a camp (or skip camps) first.';
  return '';
}
function offNext() {
  const s = offStep(); if (!s) return;
  if (offBlocked()) return offBlocked();
  if (s === 'train' && !cs.off.grown) doOffseasonGrowth();
  cs.off.i++;
  if (cs.off.i >= cs.off.steps.length) { cs.off = null; if (cs.lvl === 'hs') { cs.hs.cls++; hsNewSeason(); } else colNewSeason(); return ''; }
  const n = offStep();
  if (n === 'train' && !cs.off.grown) doOffseasonGrowth();
  return '';
}
function doOffseasonGrowth() {
  cs.off.grown = true; const hs = cs.lvl === 'hs';
  naturalGrowth(hs ? 3 : 1.4);
  const g = grantXP(hs ? 6 : 8);
  cs.off.growXP = g;
  if (!hs && cs.col) { // NIL retention: a school keeps a productive player's deal close to his market value
    const mkt = nilOffer(cs.col.tid, starsFloat(transferScore()), 70);
    if (mkt > cs.col.nil * 1.15) { const nv = Math.round(Math.max(cs.col.nil, mkt * 0.85) / 1000) * 1000; cNews(`${cTeamName(cs.col.tid)} bumps ${cName(cs.p)}'s NIL deal to ${money(nv)} a year.`, 'win'); cs.col.nil = nv; }
  }
}
const CAMPS = [
  { id: 'regional', name: 'Regional college camp', desc: 'Work out for nearby schools. Low pressure.', risk: 0.8, gain: 1.4, region: true },
  { id: 'national', name: 'National showcase', desc: 'The best prospects in the country, and every recruiting analyst. Big stakes.', risk: 2.2, gain: 3 },
  { id: 'none', name: 'Skip camps and train', desc: 'Stay home and put in the work. Extra skill points.', xp: 6 },
];
function doCamp(id) {
  const c = CAMPS.find(x => x.id === id); if (!c || cs.off.camp) return null; cs.off.camp = id;
  if (c.xp) { const g = grantXP(c.xp); return { txt: `You spend the summer training. +${g} skill points.` }; }
  const p = cs.p; const perf = (cOvr(p) + growthLeft() - (id === 'national' ? 74 : 65)) / 6 + gauss() * 0.9 + (p.a[CREAD[p.pos]] - 60) * 0.02;
  const d = r1(clamp(perf * c.gain / 2, -c.risk, c.gain)); p.rec.camp = r1((p.rec.camp || 0) + d);
  if (c.region) Object.keys(cs.rec.schools).forEach(t => { if (REGION_OF[TEAM_STATE[t]] === REGION_OF[p.home]) cs.rec.schools[t].bump = (cs.rec.schools[t].bump || 0) + 4; });
  const before = p.stars; p.rec.score = recruitScore(); p.stars = starsOf(p.rec.score);
  const offers = recruitTick('off').filter(x => x[0] === 'offer');
  const txt = (d >= 1 ? 'You were one of the standouts of the camp.' : d > 0 ? 'A solid showing.' : d > -1 ? 'An up-and-down camp.' : 'A rough camp. The analysts noticed.') + (p.stars !== before ? ` You are now a ${p.stars}-star prospect.` : '') + (offers.length ? ` New offers: ${offers.map(x => cTeamName(x[1])).join(', ')}.` : '');
  cNews(`${c.name}: ${txt}`, d > 0 ? 'win' : '');
  return { txt, d };
}
function signWith(tid) {
  const s = cs.rec.schools[tid]; if (!s || !s.off) return false;
  if (cs.rec.committed !== tid) cs.rec.committed = tid;
  enrollCollege(tid);
  cNews(`${cName(cs.p)} signs with ${cTeamName(tid)}${s.nil ? ', with an NIL deal worth ' + money(s.nil) + ' a year' : ''}.`, 'big');
  if (cs.off) { cs.off.i = cs.off.steps.length; cs.off = null; }
  colNewSeason();
  return true;
}
function colNewSeason() {
  cs.phase = 'col'; cs.lvl = 'col'; cs.week = 1; cs.ss = newSS(); cs.p.inj = 0; cs.p.injName = ''; cs.portal = null;
  if (cs.col) cs.col.coach = LT(cs.col.tid).coach;
}

/* ---------- transfer portal ---------- */
function enterPortal() {
  if (cs.portal || offStep() !== 'portal') return false;
  const from = cs.col.tid; cs.portal = { round: 1, from, offers: {}, done: false, log: [] };
  cs.col.nilPrev = cs.col.nil;
  portalRound();
  cNews(`${cName(cs.p)} enters the transfer portal.`, 'big');
  return true;
}
function portalScore() { return transferScore(); }
function portalRound() {
  const P = cs.portal; const sc = portalScore(); const sf = starsFloat(sc); const out = [];
  Object.keys(cs.league.teams).forEach(tid => {
    if (tid === P.from && P.round < 3) return;
    const cur = P.offers[tid];
    const d = depthOutlook(tid, cs.year, cOvr(cs.p));
    let i = 50 + clamp(sc - teamTarget(tid), -12, 10) * 5 + (d.k === 'start' ? 15 : d.k === 'compete' ? 6 : -10) + (cs.league.teams[tid].need[cs.p.pos] - 1) * 14 + proximity(tid) * 0.4;
    i = Math.round(clamp(i, 0, 100));
    if (cur) { if (R() < 0.12 && i < 55) { delete P.offers[tid]; out.push(['pulled', tid]); } return; }
    const room = d.k === 'start' ? -9 : d.k === 'compete' ? -7 : -5;
    if (sc - teamTarget(tid) < room || sc - teamTarget(tid) > 16 || i < 45) return;
    if (R() < 0.18 * (i / 70)) { P.offers[tid] = { i, nil: Math.round(nilOffer(tid, sf, i) * 1.1 / 1000) * 1000 || 1000, start: d.txt }; out.push(['offer', tid]); }
  });
  // nobody leaves the portal empty-handed
  if (P.round >= 2 && Object.keys(P.offers).length < 2) {
    Object.keys(cs.league.teams).filter(t => t !== P.from && !P.offers[t]).sort((a, b) => Math.abs(teamTarget(a) - sc - 3) - Math.abs(teamTarget(b) - sc - 3)).slice(0, 3).forEach(tid => { P.offers[tid] = { i: 55, nil: nilOffer(tid, sf, 55), start: depthOutlook(tid, cs.year, cOvr(cs.p)).txt }; out.push(['offer', tid]); });
  }
  P.log.push(out); return out;
}
function portalWait() { const P = cs.portal; if (!P || P.done || P.round >= 3) return null; P.round++; return portalRound(); }
function portalCommit(tid) {
  const P = cs.portal; if (!P || P.done || !P.offers[tid]) return false;
  const o = P.offers[tid]; const c = cs.col;
  P.done = true; P.to = tid;
  if (tid !== P.from) { c.transfers++; c.teams.push(tid); c.tid = tid; cs.p.trust = 45; }
  c.nil = o.nil; c.coach = LT(tid).coach;
  cNews(`${cName(cs.p)} ${tid === P.from ? 'returns to' : 'transfers to'} ${cTeamName(tid)}${o.nil ? ' (NIL: ' + money(o.nil) + ' a year)' : ''}.`, 'big');
  return true;
}

/* ---------- NFL Draft ---------- */
const POS_DRAFT = { QB: 2, DE: 1.5, CB: 1, WR: 0.5, LB: 0, S: -0.5, RB: -1, TE: -1 };
function draftProjection() {
  const p = cs.p; const aw = p.awards.filter(a => a.lvl === 'col').map(a => a.a);
  const bonus = (aw.includes('Heisman Trophy') ? 3 : 0) + (aw.some(a => a === 'First-team All-American') ? 2 : aw.some(a => a === 'Second-team All-American') ? 1 : 0);
  const sc = cOvr(p) + clamp(((cs.col.best || cs.col.lastRatio || 1) - 1) * 5, -2, 4) + bonus + POS_DRAFT[p.pos] + ((p.stars0 || 3) >= 4 ? 0.5 : 0);
  return r1(sc);
}
function draftRange(sc) {
  const T = [[93, 1, 6], [91, 5, 16], [89, 12, 32], [87, 33, 64], [85, 65, 100], [83, 101, 138], [81, 139, 176], [79, 177, 216], [77, 217, 257]];
  const row = T.find(x => sc >= x[0]); return row ? [row[1], row[2]] : null;
}
function projText(sc) { const r = draftRange(sc); if (!r) return 'Undrafted free agent'; const rd = n => Math.min(7, Math.floor((n - 1) / 32) + 1 + (n > 224 ? 0 : 0)); const a = rd(r[0]), b = rd(r[1]); return r[1] <= 32 ? (r[1] <= 10 ? 'Top 10 pick' : 'First round') : a === b ? `Round ${a}` : `Rounds ${a}–${b}`; }
function runDraft() {
  const sc = draftProjection() + gauss() * 1.2; const r = draftRange(sc);
  let res;
  if (!r) res = { pick: 0, round: 0, team: pick(NFL_TEAMS), udfa: true };
  else { const pk = ri(r[0], r[1]); res = { pick: pk, round: Math.min(7, Math.floor((pk - 1) / 32) + 1), team: pick(NFL_TEAMS) }; }
  res.year = cs.year; res.sc = r1(sc);
  cs.done = { draft: res, when: Date.now() };
  cs.phase = 'done'; cs.off = null;
  cNews(res.udfa ? `${cName(cs.p)} goes undrafted and signs with the ${res.team} as a free agent.` : `The ${res.team} select ${cName(cs.p)} in round ${res.round}, pick ${res.pick} overall.`, 'big');
  return res;
}
function declareDraft(yes) {
  if (offStep() !== 'draft') return false;
  if (!yes && outOfEligibility()) return false;
  cs.off.draftChoice = yes ? 'declare' : 'return';
  if (yes) { runDraft(); return true; }
  cNews(`${cName(cs.p)} announces he's coming back for another season.`);
  return true;
}
// career totals, summed across a level's seasons
function careerTotals(lvl) { const out = {}; cs.p.seasons.filter(s => !lvl || s.lvl === lvl).forEach(s => Object.entries(s.st).forEach(([k, v]) => out[k] = (out[k] || 0) + v)); return out; }

/* ---------- automatic play (sims) ---------- */
// Makes the obvious choice at each offseason step. Stops (returns false) when the player has
// to decide something that can't be undone: where to sign, the draft.
function autoOffStep() {
  const s = offStep(); if (!s) return false;
  if (s === 'recruit') { offersList().slice(0, 2).forEach(o => { if (canVisit(o.id) === 'unofficial') doVisit(o.id); }); }
  if (s === 'camp' && !cs.off.camp) doCamp(cs.p.stars >= 4 ? 'national' : 'regional');
  if (s === 'signing' || (s === 'draft' && !cs.off.draftChoice)) return false;
  if (s === 'train') { if (!cs.off.grown) doOffseasonGrowth(); autoAssign(); }
  offNext(); return true;
}
// Sim until `stop()` says so, a choice is needed, or `max` weeks pass.
function cSimUntil(stop, opt) {
  opt = opt || {}; let n = 0; const max = opt.max || 400;
  while (n++ < max && cs.phase !== 'done') {
    if (stop && stop()) return 'stop';
    if (cs.event) { if (opt.events) cResolveEvent(0); else return 'event'; }
    if (cInSeason()) { const r = cSimWeek(); if (r && opt.log) opt.log.push(r); if (opt.spend) autoAssign(); }
    else if (cs.phase === 'hsoff' || cs.phase === 'coloff') { if (!autoOffStep()) return 'choice'; }
    else return 'choice';
  }
  return n >= max ? 'max' : 'done';
}
// the spotlight games: the three toughest high school games, playoffs, ranked college opponents and the postseason
function isSpotlight() { const sp = myGameSpec(); return !!(sp && sp.big); }

/* ---------- saving ---------- */
const CSLOT_KEY = i => 'mfpc-slot-' + i, CMETA_KEY = 'mfpc-slots-meta', CACTIVE_KEY = 'mfpc-active';
let cslot = 1;
function cSummary() { const p = cs.p; return { name: cName(p), pos: p.pos, year: cs.year, lvl: cs.lvl, phase: cs.phase, team: cs.lvl === 'hs' ? (cs.hs ? cs.hs.name : '') : cs.col ? cTeamName(cs.col.tid) : 'Signing', stars: p.stars, ovr: cOvr(p), done: !!cs.done, saved: Date.now() }; }
function cMeta() { try { return JSON.parse(lsGet(CMETA_KEY) || '{}') || {}; } catch (e) { return {}; } }
const csave = { timer: null, chain: Promise.resolve(), pending: null };
function cSave() { if (!cs) return; cs.rng = RNG.s; csave.pending = { slot: cslot, json: JSON.stringify(cs), sum: cSummary() }; clearTimeout(csave.timer); csave.timer = setTimeout(cFlush, 150); }
function cFlush() { clearTimeout(csave.timer); const j = csave.pending; csave.pending = null; if (!j) return csave.chain; csave.chain = csave.chain.then(async () => { const data = await gz(j.json); if (lsSet(CSLOT_KEY(j.slot), data)) { const m = cMeta(); m[j.slot] = j.sum; lsSet(CMETA_KEY, JSON.stringify(m)); } else csave.failed = true; }).catch(e => console.error(e)); return csave.chain; }
function cFlushSync() { const j = csave.pending; if (!j) return; csave.pending = null; clearTimeout(csave.timer); if (lsSet(CSLOT_KEY(j.slot), 'RAW:' + j.json)) { const m = cMeta(); m[j.slot] = j.sum; lsSet(CMETA_KEY, JSON.stringify(m)); } }
async function cLoadSlot(i) {
  const raw = lsGet(CSLOT_KEY(i)); if (!raw) return { ok: false, err: 'That slot is empty.' };
  let c; try { c = JSON.parse(await gunz(raw)); } catch (e) { return { ok: false, err: 'The saved career is damaged.' }; }
  if (!c || c.kind !== 'career' || !c.p || !c.league || !CPOS.includes(c.p.pos)) return { ok: false, err: 'The saved career is damaged.' };
  cs = c; cslot = i; lsSet(CACTIVE_KEY, String(i)); RNG.s = (c.rng >>> 0) || freshSeed(); rosterCache.clear(); cg = null;
  // a game left unfinished when the page closed is played to the final from kickoff
  if (cs.liveWk != null && cs.liveWk === cs.week && cInSeason()) { if (cs.liveRng) RNG.s = cs.liveRng >>> 0; const g = cStartGame(); if (g) { cgAutoplay(g); const rec = cFinishGame(g); cEndWeek(); cs.settled = rec; } }
  cs.liveWk = null;
  return { ok: true };
}
async function cDeleteSlot(i) { await cFlush(); lsDel(CSLOT_KEY(i)); const m = cMeta(); delete m[i]; lsSet(CMETA_KEY, JSON.stringify(m)); }
