/* ===================== HOME SCREEN and PLAYER CAREER: actions and startup ===================== */
function cAfter(msg) { if (msg) cui.flash = msg; cSave(); render(); }
function defaultForm(i) { return { slot: i, first: pick(FIRST), last: pick(LAST), num: String(ri(1, 99)), home: 'MI', pos: 'QB', style: 'pocket', path: 'hs', stars: 3, hsName: '', diff: 'normal', pace: 'every', err: '' }; }
function cSnapshot() { return { nSeasons: cs.p.seasons.length, stars: cs.p.stars, ovr: cOvr(cs.p), offers: cs.rec ? Object.values(cs.rec.schools).filter(s => s.off).length : 0, phase: cs.phase, year: cs.year, committed: cs.rec && cs.rec.committed }; }
function recapRow(r) { return `<tr><td class="nowrap">${esc(cWeekLabel(r.wk))}</td><td>${r.home || r.neutral ? 'vs' : 'at'} ${cs.lvl === 'hs' || String(r.opp).indexOf(' ') > 0 && !cs.league.teams[r.opp] ? esc(r.opp) : cChip(r.opp, { rec: false })}</td><td class="nowrap"><b>${r.w ? 'W' : 'L'}</b> ${r.us}–${r.them}</td><td class="small">${r.role === 'Not playing' ? '<span class="muted">Did not play</span>' : esc(lineText(r.line, cs.p.pos) || '—')}</td><td>${gradeHTML(r.grade, true)}</td></tr>`; }
function cAfterSim(recs, before, stopped) {
  const now = cSnapshot(); const games = recs.filter(Boolean);
  const notes = [];
  if (now.ovr !== before.ovr) notes.push(`OVR ${before.ovr} → ${now.ovr}`);
  if (now.stars && now.stars !== before.stars && before.stars) notes.push(`Stars ${before.stars} → ${now.stars}`);
  if (now.offers > before.offers) notes.push(`${now.offers - before.offers} new offer${now.offers - before.offers > 1 ? 's' : ''}`);
  if (cs.p.xp > 0 && !cs.p.auto) notes.push(`${cs.p.xp} skill points to spend`);
  cSave(); render();
  if (games.length === 1 && !notes.length) { const r = games[0]; openModal(`<div class="eyebrow">${esc(cWeekLabel(r.wk))} · Final</div><h2 class="h2">${r.w ? 'Win' : 'Loss'}, ${r.us}–${r.them}</h2><div class="gsrow">${gradeHTML(r.grade)}<div>${r.role === 'Not playing' ? '<p class="muted">You didn\'t play.</p>' : `<div class="sline">${statLineHTML(r.line, cs.p.pos)}</div>`}<p class="small">+${r.xp} skill points${r.trust != null ? ` · Coach trust ${r.trust >= 0 ? '+' : ''}${r.trust}` : ''}${r.inj ? ` · Injured: ${esc(r.inj)}` : ''}</p></div></div>${r.plays && r.plays.length ? `<ul class="plays small">${r.plays.map(t => `<li><span class="when">Key play</span><span>${esc(t)}</span></li>`).join('')}</ul>` : ''}<div class="row gap mt"><button class="btn primary" data-act="close">Done</button></div>`, 'Game result'); return; }
  if (!games.length && !notes.length) return;
  const seasons = cs.p.seasons.slice(before.nSeasons);
  const sTable = seasons.length >= 2 ? `<div class="tw"><table class="tbl"><thead><tr><th>Season</th><th>Team</th><th>Record</th><th>Your season</th><th>Grade</th><th>Stars</th></tr></thead><tbody>${seasons.map(x => `<tr><td>${x.year}</td><td>${x.lvl === 'hs' ? esc(x.team) : cChip(x.team, { rec: false, norank: true })}</td><td>${esc(x.rec)}</td><td class="small">${x.gp} games · ${esc(lineText(x.st, cs.p.pos) || '—')}</td><td>${x.ratio != null && x.gp ? gradeOf(x.ratio)[1] : '—'}</td><td>${x.stars ? starsHTML(x.stars) : ''}</td></tr>`).join('')}</tbody></table></div>` : '';
  openModal(`<div class="eyebrow">Sim results</div><h2 class="h2">${seasons.length >= 2 ? seasons.length + ' seasons' : games.length + ' game' + (games.length === 1 ? '' : 's')} simulated</h2>${stopped ? `<p class="flash">${esc(stopped)}</p>` : ''}${notes.length ? `<p><b>${notes.map(esc).join(' · ')}</b></p>` : ''}${sTable}${!sTable && games.length ? `<div class="tw"><table class="tbl"><thead><tr><th>Week</th><th>Opponent</th><th>Result</th><th>Your game</th><th>Grade</th></tr></thead><tbody>${games.slice(-24).map(recapRow).join('')}</tbody></table></div>` : ''}<div class="row gap mt"><button class="btn primary" data-act="close">Done</button></div>`, 'Sim results');
}
function cgFinishUp() {
  clearTimeout(cui.gTimer); const wasDone = cg && cg.done; cg = null; cui.lastRec = null; cui.gRes = null; hideModal();
  if (wasDone && (cs.phase === 'hsoff' || cs.phase === 'coloff')) cui.flash = 'The season is over. The offseason starts on the Home tab.';
  cSave(); render();
}
function cSimTo(kind) {
  const before = cSnapshot(); const log = []; let first = true; let n = 0;
  const startLvl = cs.lvl;
  const stops = {
    spot: () => { if (first) { first = false; return false; } return !cInSeason() || isSpotlight(); },
    season: () => !cInSeason(),
    n5: () => n++ >= 5 || !cInSeason(),
    senior: () => cs.lvl !== 'hs' || (cs.phase === 'hs' && cs.hs.cls >= 3),
    signing: () => cs.lvl !== 'hs' || offStep() === 'signing',
  };
  const long = kind === 'senior' || kind === 'signing';
  const res = cSimUntil(stops[kind], { events: long, spend: long || cs.p.auto, log });
  let msg = '';
  if (res === 'event') msg = 'Stopped for a decision. It\'s on the Home tab.';
  else if (res === 'choice') msg = offStep() === 'signing' ? 'Signing day is here. Choose your school.' : offStep() === 'draft' ? 'Time to decide about the NFL Draft.' : 'A decision needs you.';
  else if (kind === 'spot' && cInSeason() && isSpotlight()) msg = 'Next up is a big game. Play it from the top of the page.';
  if (!cInSeason() && startLvl === cs.lvl && (cs.phase === 'hsoff' || cs.phase === 'coloff') && !msg) msg = 'The season is over. The offseason starts on the Home tab.';
  if (kind === 'senior' && cs.lvl === 'hs' && cs.hs.cls >= 3) msg = 'Your senior season is here. Skill points were spent for you along the way.';
  cui.tab = 'home';
  cAfterSim(log, before, msg);
}
async function enterAD() {
  if (appMode === 'career' && cs) { cSave(); await cFlush(); }
  appMode = 'ad'; hideModal();
  if (!state) { await boot(); return; }
  RNG.s = (state.rng >>> 0) || RNG.s; applyTheme(); render();
}
async function enterCareer(v) {
  if (appMode === 'ad' && state) { save(); await flushSave(); }
  appMode = 'career'; hideModal();
  if (!cs) { const a = +lsGet(CACTIVE_KEY) || 1; const r = lsGet(CSLOT_KEY(a)) ? await cLoadSlot(a) : { ok: false }; if (!r.ok) { const any = [1, 2, 3, 4, 5].find(i => i !== a && lsGet(CSLOT_KEY(i))); if (any) await cLoadSlot(any); } if (cs && cs.settled) { const s = cs.settled; cui.flash = `Your game in ${cWeekLabel(s.wk)} was still going when you left, so it was played to the final: ${s.w ? 'won' : 'lost'} ${s.us}–${s.them}.`; cs.settled = null; } }
  else RNG.s = (cs.rng >>> 0) || RNG.s;
  if (v === 'new' || !cs) { const free = [1, 2, 3, 4, 5].find(i => !lsGet(CSLOT_KEY(i))) || 1; cui.form = v === 'new' || !cs ? defaultForm(free) : null; cui.tab = 'saves'; }
  else if (v === 'saves') cui.tab = 'saves';
  else cui.tab = cui.tab && cui.tab !== 'saves' ? cui.tab : 'home';
  render(); window.scrollTo(0, 0);
  if (cui.form) { const el = document.getElementById('cf-first'); if (el) el.focus(); }
}
async function goHome() {
  if (appMode === 'ad') { if (ui.simming || liveBusy()) return notify(LIVE_LOCK_MSG); if (state) { save(); await flushSave(); } }
  if (appMode === 'career') { if (gameLocked()) return notify('Finish the game first, or close it and come back: it waits for you.'); if (cs) { cSave(); await cFlush(); } }
  appMode = 'home'; hideModal(); cui.confirm = null; cui.flash = ''; ui.flash = ''; render(); window.scrollTo(0, 0);
  const b = document.querySelector('#view [data-act="goad"]'); if (b) b.focus({ preventScroll: true });
}
Object.assign(actions, {
  gohome() { goHome(); },
  goad() { enterAD(); },
  gocareer(d) { enterCareer(d.v); },
  homeset() { cui.homeSet = true; openModal(displaySettingsHTML('home'), 'Display settings'); },
  ctab(d) { if (!$('#modal').hidden) { if (cg && cg.done) { cgFinishUp(); } else { clearTimeout(cui.gTimer); hideModal(); } } cui.tab = d.tab; cui.confirm = null; render(); window.scrollTo(0, 0); },
  cmore() { openModal(cMoreView(), 'All sections'); },
  cplay() { if (cs.event) return cAfter('Answer the decision on the Home tab first.'); if (!cInSeason() || !myGameSpec()) return; openGame(); cSave(); },
  cresume() { openGame(); },
  csim() { if (cs.event) return cAfter('Answer the decision on the Home tab first.'); if (!cInSeason()) return; const before = cSnapshot(); const rec = cSimWeek(); cAfterSim([rec], before); },
  csimto(d) { if (!cInSeason() && !(d.v === 'senior' || d.v === 'signing')) return; if (cs.event) return cAfter('Answer the decision on the Home tab first.'); cSimTo(d.v); },
  cpick(d) {
    if (!cg || !cg.pending) return; const r = cgChoose(cg, d.k); if (!r) return;
    cui.gRes = r; cui.gResI = cg.i; if (r.follow) { cgView(); return; }
    sfxFor(r); cgRun();
  },
  cgauto() { if (!cg || cg.done) return; clearTimeout(cui.gTimer); cgAutoplay(cg); cgRun(); },
  cgdone() { cgFinishUp(); },
  cevent(d) { const r = cResolveEvent(+d.i); cAfter(r ? `You chose: ${r}.` : ''); },
  coffnext() { const e = offNext(); if (e) return cAfter(e); cui.confirm = null; if (cInSeason()) { cui.tab = 'home'; cAfter(cs.lvl === 'hs' ? `Your ${HS_CLS[cs.hs.cls].toLowerCase()} season starts now.` : `The ${cs.year} season at ${cTeamName(cs.col.tid)} starts now.`); } else cAfter(); },
  ccamp(d) { const r = doCamp(d.v); if (r) cs.off.campTxt = r.txt; cAfter(); },
  cvisit(d) { const rep = doVisit(d.id); cAfter(rep ? `${rep.kind === 'official' ? 'Official' : 'Unofficial'} visit to ${cTeamName(d.id)}. Depth chart: ${rep.depth.toLowerCase()}.${rep.offer ? ' They offered you a scholarship!' : ''}` : 'You can\'t visit there right now.'); },
  ccommit(d) { if (commitTo(d.id)) cAfter(`You committed to ${cTeamName(d.id)}. You can still back out until you sign.`); },
  cdecommit() { if (decommit()) cAfter('You reopened your recruitment.'); },
  cask(d) { const r = negotiate(d.id); if (!r) return; cAfter(r.ok ? `${cTeamName(d.id)} raised its NIL offer by ${money(r.raise)}.` : `${cTeamName(d.id)} said no, and it's a little less interested now.`); },
  cask2(d) { readCForm(); cui.confirm = cui.confirm === d.k ? null : d.k; render(); const k = d.k.split('-'); const sel = k[0] === 'sign' ? `[data-act="csign"][data-id="${k[1]}"]` : k[0] === 'port' ? `[data-act="cpcommit"][data-id="${k[1]}"]` : k[0] === 'over' ? '[data-act="cstart"]' : `[data-act="cdel"][data-i="${k[1]}"]`; const b = document.querySelector(sel) || document.querySelector(`[data-k="${d.k}"]`); if (b) b.focus(); },
  csign(d) { const nm = cTeamName(d.id); if (signWith(d.id)) { cui.confirm = null; cui.tab = 'home'; cAfter(`You signed with ${nm}. Welcome to college football.`); } },
  cportal() { if (enterPortal()) { cui.tab = 'recruit'; cAfter(`You entered the transfer portal. ${Object.keys(cs.portal.offers).length} schools made offers in the first round.`); } },
  cstay() { const nm = cTeamName(cs.col.tid); offNext(); cAfter(`You're staying at ${nm}.`); },
  cpwait() { const out = portalWait(); if (!out) return; const nOff = out.filter(x => x[0] === 'offer').length, nPull = out.filter(x => x[0] === 'pulled').length; cAfter(`Round ${cs.portal.round}: ${nOff} new offer${nOff === 1 ? '' : 's'}${nPull ? `, ${nPull} withdrawn` : ''}.`); },
  cpcommit(d) { if (portalCommit(d.id)) { cui.confirm = null; cAfter(d.id === cs.portal.from ? `You're going back to ${cTeamName(d.id)}.` : `You're transferring to ${cTeamName(d.id)}.`); } },
  cdraft(d) {
    declareDraft(d.v === 'yes');
    if (cs.phase === 'done') { const r = cs.done.draft; cui.tab = 'home'; cSave(); render(); openModal(`<div class="eyebrow">${r.year} NFL Draft</div><h2 class="h2">${r.udfa ? 'Undrafted' : `Round ${r.round}, pick ${r.pick}`}</h2><p class="big">${r.udfa ? `No team called your name, but the ${esc(r.team)} sign you as a free agent.` : `The <b>${esc(r.team)}</b> select ${esc(cName(cs.p))}.`}</p><p class="muted">Your career summary is on the Home tab.</p><div class="row gap mt"><button class="btn primary" data-act="close">See the summary</button></div>`, 'NFL Draft'); }
    else cAfter();
  },
  cup(d) { const k = d.k; const n = upgrade(k, +(d.n || 1)); cSave(); render(); refocus({ act: 'cup', k, ...(d.n ? { n: d.n } : {}) }); if (n) announce(`${CATTR[cs.p.pos].find(a => a[0] === k)[1]} is now ${cs.p.a[k]}.`); },
  cauto() { autoAssign(); cAfter('Skill points spent.'); },
  ctrain(d) { const t = TRAIN.find(x => x.id === d.id); if (buyTraining(d.id)) cAfter(`Done: ${t.name}.`); },
  crs(d) { if (!cs.col) return; cs.col.rs = d.v === 'on'; cAfter(cs.col.rs ? 'Redshirt plan on. You\'ll play four games at most this season.' : 'Redshirt plan off.'); refocus({ act: 'crs', v: d.v }); },
  cpace(d) { if (PACES[d.v]) cs.pace = d.v; cAfter(); refocus({ act: 'cpace', v: d.v }); },
  cdiff(d) { if (CDIFF[d.v]) cs.diff = d.v; cAfter(); refocus({ act: 'cdiff', v: d.v }); },
  cautoset(d) { cs.p.auto = d.v === 'on'; if (cs.p.auto) autoAssign(); cAfter(); refocus({ act: 'cautoset', v: d.v }); },
  crecf(d) { cui.recF = d.v; render(); refocus({ act: 'crecf', v: d.v }); },
  clg(d) { cui.lgV = d.v; render(); refocus({ act: 'clg', v: d.v }); },
  cnew(d) { cui.form = defaultForm(+d.i); cui.confirm = null; render(); const el = document.getElementById('cnewform'); if (el) { el.scrollIntoView({ block: 'start' }); const f = document.getElementById('cf-first'); if (f) f.focus({ preventScroll: true }); } },
  cform(d) { readCForm(); const f = cui.form; if (!f) return; f[d.k] = d.k === 'stars' ? +d.v : d.v; if (d.k === 'pos') f.style = CSTYLES[d.v][0][0]; render(); refocus({ act: 'cform', k: d.k, v: d.v }); },
  ccancel() { cui.form = null; cui.confirm = null; render(); },
  async cstart() {
    readCForm(); const f = cui.form; if (!f) return; cui.confirm = null;
    f.first = String(f.first || '').trim(); f.last = String(f.last || '').trim(); const num = Math.round(+f.num);
    if (!f.first || !f.last) { f.err = 'Give your player a first and last name.'; render(); return; }
    if (!Number.isFinite(num) || num < 0 || num > 99) { f.err = 'Jersey numbers go from 0 to 99.'; render(); return; }
    if (cs) { cSave(); await cFlush(); }
    newCareer({ pos: f.pos, style: f.style, first: f.first, last: f.last, num, home: f.home, path: f.path, stars: f.stars, hsName: f.hsName ? String(f.hsName).trim().slice(0, 28) + (/high|academy|prep|school/i.test(f.hsName) ? '' : ' High') : '', diff: f.diff, pace: f.pace });
    cslot = f.slot; lsSet(CACTIVE_KEY, String(cslot)); cui.form = null; cui.tab = 'home'; cg = null; rosterCache.clear();
    cui.flash = f.path === 'college' ? 'Your offers are in. Compare them on the Recruiting tab, then sign.' : 'Welcome to high school football. Play your first game from the top of the page.';
    cSave(); await cFlush(); render(); window.scrollTo(0, 0);
  },
  async cload(d) { const i = +d.i; if (cs) { cSave(); await cFlush(); } const r = await cLoadSlot(i); if (!r.ok) { cui.flash = r.err; render(); return; } cui.tab = 'home'; cui.form = null; if (cs.settled) { const s = cs.settled; cui.flash = `Your game in ${cWeekLabel(s.wk)} was still going when you left, so it was played to the final.`; cs.settled = null; } else cui.flash = `Loaded ${cName(cs.p)}.`; cSave(); render(); },
  async cdel(d) { const i = +d.i; await cDeleteSlot(i); cui.confirm = null; if (cs && cslot === i) { cs = null; cg = null; } cui.flash = `Slot ${i} deleted.`; render(); },
});
function sfxFor(r) { try { if (typeof sfx === 'function' && cs && r && r.imm === 'td' && cg && cg.side === 'off') sfx('roar'); } catch (e) { } }
// career form fields, sort menus and admin inputs
document.addEventListener('change', e => {
  if (appMode !== 'career') return; const t = e.target;
  if (t.id === 'cautochk') { cs.p.auto = t.checked; if (t.checked) autoAssign(); cSave(); render(); refocus({}); const c = document.getElementById('cautochk'); if (c) c.focus(); return; }
  if (t.id === 'crecsort') { cui.recSort = t.value; render(); const s = document.getElementById('crecsort'); if (s) s.focus(); return; }
  if (t.id === 'cconfsel') { cui.lgConf = t.value; render(); const s = document.getElementById('cconfsel'); if (s) s.focus(); return; }
  if (t.id === 'cadmteam') { cui.admT = t.value; render(); const s = document.getElementById('cadmteam'); if (s) s.focus(); return; }
  if (t.dataset && t.dataset.cadm) { cAdmSet(t.dataset.cadm, t); return; }
  if (t.id && t.id.startsWith('cf-')) { readCForm(); return; }
});
window.addEventListener('pagehide', () => { if (cs) { cSave(); cFlushSync(); } });
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden' && cs) { cSave(); cFlushSync(); } });
// Start on the home screen.
function bootHome() { appMode = 'home'; render(); const b = document.querySelector('#view [data-act="goad"]'); if (b && !prefs.seen) { } }
bootHome();
