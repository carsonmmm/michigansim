/* ===================== PERSISTENCE: save slots, import/export ===================== */
const SAVE_KEY = 'mfad-save-v1';
const SLOT_KEY = i => 'mfad-slot-' + i, META_KEY = 'mfad-slots-meta', ACTIVE_KEY = 'mfad-active';
let slot = 1;
// True only when every slot held an unreadable save at startup: the fresh career then waits for
// the player to free a slot instead of overwriting one of them.
let saveBlocked = false;

function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
function lsSet(k, v) { try { localStorage.setItem(k, v); return true; } catch (e) { return false; } }
function lsDel(k) { try { localStorage.removeItem(k); } catch (e) { } }
function slotsMeta() { try { return JSON.parse(lsGet(META_KEY) || '{}') || {}; } catch (e) { return {}; } }
function setActiveSlot(i) { slot = i; saveBlocked = false; lsSet(ACTIVE_KEY, String(i)); }
function firstFreeSlot() { return [1, 2, 3, 4, 5].find(i => !lsGet(SLOT_KEY(i))) || null; }
async function gz(str) { try { if (!window.CompressionStream) return 'RAW:' + str; const cs = new Blob([str]).stream().pipeThrough(new CompressionStream('gzip')); const buf = new Uint8Array(await new Response(cs).arrayBuffer()); let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000)); return 'GZ:' + btoa(bin); } catch (e) { return 'RAW:' + str; } }
async function gunz(s) { if (s.startsWith('RAW:')) return s.slice(4); if (s.startsWith('GZ:')) { const bin = atob(s.slice(3)); const buf = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i); const ds = new Blob([buf]).stream().pipeThrough(new DecompressionStream('gzip')); return await new Response(ds).text(); } return s; }
function slotSummary() { return { name: teamName('MICH'), season: state.season, phase: state.phase, rec: T('MICH').w + '-' + T('MICH').l, legacy: legacyScore(), diff: state.settings.diff, custom: !!state.me, seasons: state.history.length, fired: !!state.gameOver, saved: Date.now() }; }

/* ---------- save queue ----------
 * save() snapshots the game right away and remembers it as the newest pending save for the
 * active slot. A short debounce batches rapid clicks. Writes run one at a time through a
 * promise chain, and each carries a sequence number, so an older snapshot can never land
 * on top of a newer one. flushSave() writes everything pending and resolves when storage
 * is up to date; career switches await it. If the page is hidden or closed before an async
 * write finishes, flushSync() writes the newest snapshot uncompressed, synchronously. */
const saveQ = { pending: {}, inflight: {}, timer: null, chain: Promise.resolve(), seq: 0, written: {}, failed: {} };
function saveStatus(msg) { ui.saveMsg = msg; const el = document.getElementById('savemsg'); if (el) el.textContent = msg; }
function save() {
  if (!state || saveBlocked) return;
  state.rng = RNG.s;
  saveQ.pending[slot] = { slot, seq: ++saveQ.seq, json: JSON.stringify(state), sum: slotSummary() };
  clearTimeout(saveQ.timer); saveQ.timer = setTimeout(flushSave, 150);
}
function commitMeta(job) { const m = slotsMeta(); m[job.slot] = job.sum; lsSet(META_KEY, JSON.stringify(m)); }
async function writeJob(job) {
  if ((saveQ.written[job.slot] || 0) > job.seq) return;
  saveQ.inflight[job.slot] = job;
  try {
    const data = await gz(job.json);
    if ((saveQ.written[job.slot] || 0) > job.seq) return; // a newer snapshot already landed
    if (lsSet(SLOT_KEY(job.slot), data)) { saveQ.written[job.slot] = job.seq; delete saveQ.failed[job.slot]; commitMeta(job); saveStatus(`Saved to slot ${job.slot} · ` + new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })); }
    else { saveQ.failed[job.slot] = job.seq; saveStatus('Could not save. Browser storage is full or blocked. Create a save code below to keep your progress.'); }
  } finally { if (saveQ.inflight[job.slot] === job) delete saveQ.inflight[job.slot]; }
}
function flushSave() {
  clearTimeout(saveQ.timer); saveQ.timer = null;
  const jobs = Object.values(saveQ.pending); saveQ.pending = {};
  jobs.forEach(job => { saveQ.chain = saveQ.chain.then(() => writeJob(job)).catch(e => console.error('save failed', e)); });
  return saveQ.chain;
}
function flushSync() {
  const latest = {};
  [...Object.values(saveQ.inflight), ...Object.values(saveQ.pending)].forEach(j => { if (!latest[j.slot] || j.seq > latest[j.slot].seq) latest[j.slot] = j; });
  Object.values(latest).forEach(j => {
    if ((saveQ.written[j.slot] || 0) >= j.seq) { delete saveQ.pending[j.slot]; return; }
    if (lsSet(SLOT_KEY(j.slot), 'RAW:' + j.json)) { saveQ.written[j.slot] = j.seq; delete saveQ.failed[j.slot]; commitMeta(j); delete saveQ.pending[j.slot]; }
    else saveQ.pending[j.slot] = j; // kept, so the next flush tries again if the page stays open
  });
}
// Saves the current career and waits for storage. Resolves false if the write failed, so a
// career switch can stop instead of leaving unsaved progress behind.
async function saveNow() { if (saveBlocked) return true; save(); await flushSave(); return !saveQ.failed[slot]; }
// Deleting a slot first lets queued writes finish, then retires them, so a late write can't
// bring the deleted career back.
async function deleteSlot(i) {
  await flushSave();
  delete saveQ.pending[i]; saveQ.written[i] = ++saveQ.seq;
  lsDel(SLOT_KEY(i)); const m = slotsMeta(); delete m[i]; lsSet(META_KEY, JSON.stringify(m));
}
window.addEventListener('pagehide', flushSync);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flushSync(); });

/* ---------- adopting a loaded or imported game ----------
 * A candidate is validated and migrated while the current game is kept aside. Only if
 * every check passes does it become the active game; otherwise the previous game, its
 * player index, conference lists and random position are restored untouched. */
function checkShape(s) {
  if (!s || typeof s !== 'object') throw new Error('The data is empty.');
  if (!s.teams || typeof s.teams !== 'object' || !s.teams.MICH) throw new Error('No program data was found.');
  if (Object.keys(s.teams).length < 100) throw new Error('The league data is incomplete.');
  if (!Array.isArray(s.roster) || s.roster.length < 22) throw new Error('The roster is missing or too small.');
  if (!Array.isArray(s.games) || !s.fin || typeof s.fin !== 'object' || !s.meters || !s.depth || !s.staff || !Number.isFinite(+s.season)) throw new Error('Required game data is missing.');
}
function checkIntegrity(s) {
  if (!s.settings || !POS_ORDER.every(p => Array.isArray(s.depth[p]))) throw new Error('The depth chart is damaged.');
  s.roster.forEach(p => { if (!p || !p.id || !POS_ORDER.includes(p.pos) || !Number.isFinite(p.ovr)) throw new Error('A player record is damaged.'); });
  Object.values(s.teams).forEach(t => { if (!CONFS[t.conf] || !Number.isFinite(t.rating)) throw new Error('A team record is damaged.'); });
  michStrength(); mGames(); legacyScore(); slotSummary();
  if (typeof validateRender === 'function') { try { validateRender(); } catch (e) { console.error(e); throw new Error('The game could not display this save (' + e.message + ').'); } }
}
function adoptState(cand) {
  const prev = { state, PMAP, rng: RNG.s };
  try {
    checkShape(cand);
    state = cand; rebuildPMap(); migrate(cand); state = cand; rebuildPMap();
    checkIntegrity(state);
    RNG.s = (cand.rng >>> 0) || freshSeed();
    settleLiveGame();
    return true;
  } catch (e) {
    state = prev.state; PMAP = prev.PMAP; RNG.s = prev.rng; if (state) rebuildConfs();
    throw e;
  }
}
function settleLiveGame() {
  const wk = state.liveWk, rng = state.liveRng; state.liveWk = null; state.liveRng = null; if (wk == null) return;
  const mg = michGameThisWeek(wk); if (!mg || state.week !== wk || state.gameOver) return;
  // Played from the random position at kickoff, so the result is the same however often the page is reloaded.
  if (rng) RNG.s = rng >>> 0;
  advance();
  const opp = oppOf(mg), us = mg.h === 'MICH' ? mg.hs : mg.as, them = mg.h === 'MICH' ? mg.as : mg.hs;
  ui.flash = `The live game against ${teamName(opp)} was still going when you left, so it was played to the final: ${us > them ? 'won' : 'lost'} ${us}–${them}.`;
}
async function loadSlot(i) {
  const raw = lsGet(SLOT_KEY(i)); if (!raw) return { ok: false, err: 'That slot is empty.' };
  let cand; try { cand = JSON.parse(await gunz(raw)); } catch (e) { console.error(e); return { ok: false, err: 'The saved data is damaged or incomplete.' }; }
  try { adoptState(cand); setActiveSlot(i); applyTheme(); return { ok: true }; }
  catch (e) { console.error(e); return { ok: false, err: e && e.message ? e.message : 'The save could not be read.' }; }
}
async function boot() {
  const legacy = lsGet(SAVE_KEY); if (legacy && !lsGet(SLOT_KEY(1)) && lsSet(SLOT_KEY(1), 'RAW:' + legacy)) lsDel(SAVE_KEY);
  const a = +lsGet(ACTIVE_KEY) || 1; let res = await loadSlot(a); const bad = [];
  if (!res.ok && lsGet(SLOT_KEY(a))) bad.push(a);
  for (let i = 1; i <= 5 && !res.ok; i++) { if (i === a) continue; res = await loadSlot(i); if (!res.ok && lsGet(SLOT_KEY(i))) bad.push(i); }
  if (!res.ok) {
    const free = firstFreeSlot(); newGame('normal'); setActiveSlot(free || 1);
    if (free) save(); else saveBlocked = true;
  }
  if (bad.length) ui.flash = saveBlocked
    ? 'None of the five save slots could be loaded, so they were left untouched and this new career is not being saved yet. Delete a slot on the Save file tab and this career will be saved there.'
    : `Slot ${bad.join(', ')} could not be loaded and was left untouched. You can still delete or reset it on the Save file tab.`;
  if (res.ok) save();
  applyTheme(); render();
}

/* ---------- save codes ---------- */
async function makeCode() {
  state.rng = RNG.s; const json = JSON.stringify(state);
  try { if (window.CompressionStream) { const cs = new Blob([json]).stream().pipeThrough(new CompressionStream('gzip')); const buf = new Uint8Array(await new Response(cs).arrayBuffer()); let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000)); return 'MFAD1:' + btoa(bin); } } catch (e) { }
  return 'MFAD0:' + btoa(unescape(encodeURIComponent(json)));
}
async function readCode(code) {
  code = (code || '').trim();
  try {
    if (code.startsWith('MFAD1:')) { const bin = atob(code.slice(6)); const buf = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i); const ds = new Blob([buf]).stream().pipeThrough(new DecompressionStream('gzip')); return JSON.parse(await new Response(ds).text()); }
    if (code.startsWith('MFAD0:')) return JSON.parse(decodeURIComponent(escape(atob(code.slice(6)))));
  } catch (e) { throw new Error('The code is incomplete or damaged.'); }
  throw new Error('Save codes start with MFAD.');
}
