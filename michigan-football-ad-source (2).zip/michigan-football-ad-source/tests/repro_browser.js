// Reproduces reported issues 1, 2, 4 and 6 against a built HTML file. On the previous build each
// line printed CONFIRMED; on the fixed build each prints "not reproduced".
//   NODE_PATH=$(npm root -g) node tests/repro_browser.js path/to/game.html
const { chromium } = require('playwright'); const path = require('path');
const file = path.resolve(process.argv[2] || 'michigan-football-ad.html');
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext(); const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto('file://' + file); await p.waitForTimeout(800);
  // ---- Issue 4
  const r4 = await p.evaluate(() => { state.fin.ticket = 40; const f0 = state.meters.fan; actions.tix({ d: -1 }); actions.tix({ d: -1 }); const f1 = state.meters.fan; state.fin.revPct = 100; const m0 = state.meters.morale; actions.rev({ d: 1 }); actions.rev({ d: 1 }); return { ticket: state.fin.ticket, fan: [f0, f1], rev: state.fin.revPct, morale: [m0, state.meters.morale] }; });
  console.log('ISSUE4', JSON.stringify(r4), (r4.fan[1] > r4.fan[0] || r4.morale[1] > r4.morale[0]) ? 'CONFIRMED' : 'not reproduced');
  // ---- Issue 1: create slot 2, change something, switch immediately
  await p.evaluate(async () => { await new Promise(r => setTimeout(r, 400)); localStorage.setItem('mfad-slot-2', localStorage.getItem('mfad-slot-1')); const m = JSON.parse(localStorage.getItem('mfad-slots-meta')); m[2] = m[1]; localStorage.setItem('mfad-slots-meta', JSON.stringify(m)); });
  await p.waitForTimeout(300);
  await p.evaluate(() => { state.fin.ticket = 150; actions.tix({ d: 1 }); actions.slotload({ i: '2' }); });
  await p.waitForTimeout(1500);
  const t1 = await p.evaluate(async () => { const s = JSON.parse(await gunz(localStorage.getItem('mfad-slot-1'))); return s.fin.ticket; });
  console.log('ISSUE1 slot 1 stored ticket after quick switch:', t1, t1 === 155 ? 'not reproduced' : 'CONFIRMED (change lost)');
  // ---- Issue 2: import a code that parses but fails migration
  await p.evaluate(() => actions.tab({ tab: 'file' }));
  const before = await p.evaluate(() => ({ season: state.season, teams: Object.keys(state.teams).length }));
  const bad = 'MFAD0:' + Buffer.from(JSON.stringify({ v: 1, teams: {}, roster: [] })).toString('base64');
  await p.fill('#importbox', bad); await p.click('[data-act=import]'); await p.waitForTimeout(500);
  const after = await p.evaluate(() => ({ season: state.season, teams: state.teams ? Object.keys(state.teams).length : null }));
  console.log('ISSUE2 before', JSON.stringify(before), 'after', JSON.stringify(after), after.teams !== before.teams ? 'CONFIRMED (state replaced)' : 'not reproduced');
  // fresh page for issue 6
  const p2 = await ctx.newPage(); await p2.goto('file://' + file); await p2.evaluate(() => { localStorage.clear(); }); await p2.reload(); await p2.waitForTimeout(800);
  await p2.click('#view [data-act=live]'); await p2.waitForTimeout(300); await p2.click('.mclose'); await p2.waitForTimeout(300);
  const r6 = await p2.evaluate(() => ({ done: mGames()[0].done, week: state.week, modalHidden: document.getElementById('modal').hidden }));
  console.log('ISSUE6 after clicking Close in live game:', JSON.stringify(r6), r6.done ? 'CONFIRMED (game was simulated)' : 'not reproduced');
  console.log('page errors:', errs.length);
  await b.close();
})();
