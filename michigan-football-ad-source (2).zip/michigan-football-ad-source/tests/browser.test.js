// Full-interface regression checks in headless Chromium.
//   NODE_PATH=$(npm root -g) node tests/browser.test.js [path/to/game.html]
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const file = path.resolve(process.argv[2] || path.join(__dirname, '..', 'michigan-football-ad.html'));
const url = 'file://' + file;
const root = [path.join(__dirname, 'fixtures'), path.join(__dirname, '..')].find(d => fs.existsSync(path.join(d, 'v1save.json'))) || __dirname; // saved games from earlier versions

let pass = 0, fail = 0; const out = [];
function check(name, cond, detail) { (cond ? pass++ : fail++); out.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail != null && detail !== '' ? '  (' + detail + ')' : ''}`); }
const sleep = ms => new Promise(r => setTimeout(r, ms));

// The site opens on the home screen; AD mode starts when it's picked there.
async function toAD(page) { await page.waitForSelector('#view [data-act=goad]'); await page.click('#view [data-act=goad]'); await page.waitForFunction(() => typeof state !== 'undefined' && state && appMode === 'ad' && document.querySelector('#hdr .brand')); }
async function fresh(browser, opts) {
  const ctx = await browser.newContext(opts || {}); const page = await ctx.newPage();
  const errors = []; page.on('pageerror', e => errors.push(e.message)); page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push('console: ' + m.text()); }); // web fonts are unreachable in the test sandbox
  await page.goto(url); await toAD(page);
  return { ctx, page, errors };
}
const inModal = page => page.evaluate(() => { const b = document.querySelector('#modal .mbox'); return !!b && b.contains(document.activeElement); });
const activeDesc = page => page.evaluate(() => { const a = document.activeElement; return a ? (a.dataset && a.dataset.act ? a.dataset.act : a.id || a.tagName) : null; });
async function readSlot(page, i) { return page.evaluate(async i => { const raw = localStorage.getItem('mfad-slot-' + i); return raw ? JSON.parse(await gunz(raw)) : null; }, i); }

(async () => {
  const browser = await chromium.launch();

  // ---------- boot, tabs ----------
  {
    const { ctx, page, errors } = await fresh(browser);
    const tabs = await page.evaluate(() => [...document.querySelectorAll('#tabs [data-act=tab]')].map(b => b.dataset.tab));
    const empty = [];
    for (const t of tabs) { await page.click(`#tabs [data-tab="${t}"]`); const n = await page.evaluate(() => document.querySelector('#view').textContent.trim().length); if (n < 20) empty.push(t); }
    check('every tab renders', empty.length === 0 && tabs.length >= 15, `${tabs.length} tabs${empty.length ? ', empty: ' + empty : ''}`);
    check('fresh career boots at Week 1 of 2026 with no errors', errors.length === 0 && (await page.evaluate(() => state.season === 2026 && state.week === 1)), errors[0]);
    await ctx.close();
  }

  // ---------- quick sim + dialog accessibility ----------
  {
    const { ctx, page, errors } = await fresh(browser);
    await page.click('#hdr [data-act=primary]');
    await page.waitForSelector('#modal:not([hidden])');
    const dlg = await page.evaluate(() => { const b = document.querySelector('#modal .mbox'); const id = b.getAttribute('aria-labelledby'); return { role: b.getAttribute('role'), modal: b.getAttribute('aria-modal'), title: id && document.getElementById(id).textContent, inert: ['hdr', 'tabs', 'view'].every(x => document.getElementById(x).inert), week: state.week, done: mGames()[0].done }; });
    check('quick sim plays the week and shows the box score', dlg.week === 2 && dlg.done);
    check('dialog has role, aria-modal and an accessible title', dlg.role === 'dialog' && dlg.modal === 'true' && dlg.title && dlg.title.length > 3, dlg.title);
    check('page behind an open dialog is inert', dlg.inert);
    check('focus starts inside the dialog', await inModal(page));
    let escaped = 0; for (let i = 0; i < 30; i++) { await page.keyboard.press('Tab'); if (!(await inModal(page))) escaped++; }
    for (let i = 0; i < 12; i++) { await page.keyboard.press('Shift+Tab'); if (!(await inModal(page))) escaped++; }
    check('Tab and Shift+Tab stay inside the dialog', escaped === 0, `${escaped} escapes in 42 presses`);
    await page.keyboard.press('Escape');
    const after = await page.evaluate(() => ({ hidden: document.getElementById('modal').hidden, inert: document.getElementById('view').inert, act: document.activeElement && document.activeElement.dataset.act }));
    check('Escape closes the dialog and returns focus to the sim button', after.hidden && !after.inert && after.act === 'primary', `focus on ${after.act}`);
    // focus returns to a re-rendered opener
    await page.click('#tabs [data-tab=roster]');
    const pid = await page.evaluate(() => document.querySelector('#view [data-act=player]').dataset.id);
    await page.click(`#view [data-act=player][data-id="${pid}"]`); await page.waitForSelector('#modal:not([hidden])');
    await page.click('#modal [data-act=paymkt]'); // re-renders the page and the dialog
    await page.keyboard.press('Escape');
    check('focus returns to the player link after the page re-rendered', await page.evaluate(id => document.activeElement && document.activeElement.dataset.id === id, pid));
    // quick sim through the regular season via the menu
    await page.click('#hdr .simmenu summary'); await page.click('#hdr [data-act=simreg]');
    check('sim to end of regular season', await page.evaluate(() => state.phase !== 'regular' && mGames().filter(g => g.wk <= 13 && g.done).length >= 12));
    check('no page errors during quick sim', errors.length === 0, errors[0]);
    await ctx.close();
  }

  // ---------- live game: close pauses, explicit sim finishes ----------
  {
    const { ctx, page, errors } = await fresh(browser);
    await page.click('#view [data-act=live]'); await page.waitForSelector('#modal:not([hidden]) .live');
    const title = await page.evaluate(() => document.getElementById('modaltitle').textContent);
    check('live game dialog is titled', /^Live game:/.test(title), title);
    await sleep(2600);
    const st = () => page.evaluate(() => ({ i: live.sim && live.sim.i, log: live.sim && live.sim.log.length, done: live.sim ? live.sim.done : null, week: state.week, hidden: document.getElementById('modal').hidden, gameDone: mGames()[0].done, open: live.open }));
    const s0 = await st();
    for (const how of ['Escape', 'backdrop', 'Close']) {
      if (how === 'Escape') await page.keyboard.press('Escape');
      if (how === 'backdrop') await page.mouse.click(4, 400);
      if (how === 'Close') await page.click('#modal .mclose');
      const a = await st(); await sleep(1500); const b = await st();
      check(`${how} pauses the live game instead of finishing it`, a.hidden && !a.open && !a.gameDone && a.week === 1 && b.log === a.log, `log ${a.log} -> ${b.log}`);
      const hdr = await page.evaluate(() => ({ resume: !!document.querySelector('#hdr [data-act=liveresume]'), primary: !!document.querySelector('#hdr [data-act=primary]'), focus: document.activeElement && document.activeElement.dataset.act }));
      check(`after ${how}, the header offers Resume and has focus`, hdr.resume && !hdr.primary && hdr.focus === 'liveresume');
      await page.click('#hdr [data-act=liveresume]'); await page.waitForSelector('#modal:not([hidden]) .live');
      const c1 = await st(); await sleep(2400); const c2 = await st();
      check(`resume after ${how} continues from the same point`, c1.log >= a.log && (c2.log > c1.log || c2.done || await page.evaluate(() => !!live.sim.pending)), `log ${a.log} -> ${c1.log} -> ${c2.log}`);
    }
    // conflicting actions are blocked while the game waits
    await page.keyboard.press('Escape');
    const blocked = await page.evaluate(() => { const b = document.createElement('button'); b.dataset.act = 'primary'; document.getElementById('view').appendChild(b); b.click(); return { week: state.week, flash: document.querySelector('#view .flash') && document.querySelector('#view .flash').textContent }; });
    check('quick sim is blocked while a live game is paused', blocked.week === 1 && /Finish the live game/.test(blocked.flash || ''), blocked.flash);
    const blocked2 = await page.evaluate(async () => { await simYears(1); return { season: state.season, week: state.week }; });
    check('multi-season sim is blocked while a live game is paused', blocked2.season === 2026 && blocked2.week === 1);
    await page.click('#hdr [data-act=liveresume]'); await page.waitForSelector('#modal:not([hidden]) .live');
    const lbl = await page.evaluate(() => { const b = document.querySelector('#modal [data-act=lskip]'); return b && b.textContent; });
    check('the finish control says what it does', lbl === 'Simulate the rest of the game', lbl);
    // answer any pending decision first (the button is only needed when no decision is waiting)
    await page.evaluate(() => { if (live.sim.pending) { const b = document.querySelector('#modal .decision button:not([disabled])'); if (b) b.click(); } });
    await page.click('#modal [data-act=lskip]');
    const fin = await st();
    check('"Simulate the rest of the game" finishes it', fin.done && fin.gameDone && fin.week === 2 && !fin.hidden);
    await page.click('#modal .mclose');
    const closed = await page.evaluate(() => ({ hidden: document.getElementById('modal').hidden, sim: live.sim, primary: !!document.querySelector('#hdr [data-act=primary]') }));
    check('closing a finished game clears it and restores the sim buttons', closed.hidden && closed.sim === null && closed.primary);
    check('no page errors in the live game', errors.length === 0, errors[0]);
    await ctx.close();
  }

  // ---------- live game with every decision made in the dialog ----------
  {
    const { ctx, page, errors } = await fresh(browser);
    await page.evaluate(() => { state.settings.ask = true; live.callPlays = true; });
    await page.click('#view [data-act=live]'); await page.waitForSelector('#modal:not([hidden]) .live');
    await page.click('#modal [data-act=lspeed][data-v="3"]');
    const kinds = new Set(); let guard = 0;
    while (guard++ < 600) {
      const s = await page.evaluate(() => ({ done: !live.sim || live.sim.done, p: live.sim && live.sim.pending ? live.sim.pending.type : null }));
      if (s.done) break;
      if (s.p) { kinds.add(s.p); await page.evaluate(() => { const b = document.querySelector('#modal .decision [data-act=lcall], #modal .decision [data-act=ldec], #modal .decision [data-act=lkick], #modal .decision [data-act=lhgo]'); if (b) b.click(); }); }
      await sleep(40);
    }
    const res = await page.evaluate(() => ({ done: live.sim && live.sim.done, gdone: mGames()[0].done, week: state.week }));
    check('a live game with play calling and halftime choices reaches the final', res.done && res.gdone && res.week === 2, [...kinds].join(', '));
    check('focus stays in the live dialog while it updates', await inModal(page));
    check('no page errors while calling plays', errors.length === 0, errors[0]);
    await ctx.close();
  }

  // ---------- a paused live game and a page reload ----------
  {
    const { ctx, page, errors } = await fresh(browser);
    await page.click('#view [data-act=live]'); await page.waitForSelector('#modal:not([hidden]) .live'); await sleep(1500);
    await page.keyboard.press('Escape');
    await page.click('#view [data-act=practice][data-v="conditioning"]').catch(() => page.evaluate(() => { state.practice = 'conditioning'; save(); }));
    await sleep(400);
    const stored = await page.evaluate(() => localStorage.getItem('mfad-slot-1'));
    const reload = async () => { await page.reload(); await toAD(page); return page.evaluate(() => { const g = state.games.find(x => x.wk === 1 && (x.h === 'MICH' || x.a === 'MICH')); return { week: state.week, done: g.done, score: g.hs + '-' + g.as, flash: document.querySelector('#view .flash') && document.querySelector('#view .flash').textContent, watch: !!document.querySelector('[data-act=live]') }; }); };
    const r1 = await reload();
    check('a live game left paused is played to the final after a reload, with a notice', r1.week === 2 && r1.done && /still going when you left/.test(r1.flash || ''), r1.flash);
    await page.evaluate(v => { localStorage.setItem('mfad-slot-1', v); }, stored);
    await page.evaluate(() => { saveQ.pending = {}; clearTimeout(saveQ.timer); window.removeEventListener('pagehide', flushSync); saveBlocked = true; });
    const r2 = await reload();
    check('reloading again gives the same final score', r2.score === r1.score, `${r1.score} and ${r2.score}`);
    check('no page errors around an interrupted live game', errors.length === 0, errors[0]);
    await ctx.close();
  }

  // ---------- review follow-ups: failed saves, all-damaged slots, focus, stale dialogs ----------
  {
    const { ctx, page, errors } = await fresh(browser);
    await sleep(400);
    await page.click('#tabs [data-tab=file]'); await page.click('#view [data-act=slotnew][data-i="2"]'); await page.click('#view [data-act=startcareer]'); await page.waitForFunction(() => slot === 2 && !ui.slotBusy);
    await page.click('#tabs [data-tab=file]'); await page.click('#view [data-act=slotload][data-i="1"]'); await page.waitForFunction(() => slot === 1 && !ui.slotBusy);
    await page.evaluate(() => { for (let i = 0; i < 3; i++) advance(); render(); const real = Storage.prototype.setItem; window.__realSet = real; Storage.prototype.setItem = function (k, v) { if (k === 'mfad-slot-1') throw new DOMException('full', 'QuotaExceededError'); return real.call(this, k, v); }; });
    await page.click('#tabs [data-tab=file]'); await page.click('#view [data-act=slotload][data-i="2"]'); await page.waitForFunction(() => !ui.slotBusy);
    const q = await page.evaluate(() => ({ slot, week: state.week, flash: document.querySelector('#view .flash') && document.querySelector('#view .flash').textContent }));
    check('a career switch stops when the current career cannot be saved', q.slot === 1 && q.week === 4 && /could not be saved/.test(q.flash || ''), q.flash);
    await page.evaluate(() => { Storage.prototype.setItem = window.__realSet; });
    // focus after an action that closes a dialog and re-renders the page
    await page.click('#tabs [data-tab=roster]');
    const pid = await page.evaluate(() => { const p = state.roster.find(x => state.depth[x.pos].indexOf(x.id) > 0); return p.id; });
    await page.evaluate(id => { ui.rpos = 'ALL'; render(); }, pid);
    await page.evaluate(id => { const b = document.querySelector(`#view [data-act=player][data-id="${id}"]`); b.focus(); b.click(); }, pid);
    await page.click('#modal [data-act=mkstarter]'); await sleep(50);
    const f = await page.evaluate(() => document.activeElement && document.activeElement.tagName);
    check('focus lands on a control, not the page body, after "Move to top of depth chart"', f !== 'BODY', f);
    // blocked action inside a dialog explains itself there
    await page.evaluate(() => { while (state.event) resolveEvent(0); render(); }); // a pending decision hides Watch live
    await page.click('#tabs [data-tab=office]'); await page.click('#view [data-act=live]'); await page.waitForSelector('#modal:not([hidden]) .live'); await page.keyboard.press('Escape');
    await page.click('#tabs [data-tab=roster]');
    const sw = await page.evaluate(() => { const p = state.roster.find(x => (SWITCH[x.pos] || []).length); document.querySelector(`#view [data-act=player][data-id="${p.id}"]`).click(); document.querySelector('#modal [data-act=switchpos]').click(); const el = document.querySelector('#modal .mflash'); return { msg: el && el.textContent, pos: P(p.id).pos === p.pos }; });
    check('a blocked action inside a dialog shows its message in the dialog', /Finish the live game/.test(sw.msg || '') && sw.pos, sw.msg);
    await page.keyboard.press('Escape'); await page.click('#hdr [data-act=liveresume]'); await page.click('#modal [data-act=lskip]'); await page.click('#modal .mclose');
    // a stale dialog does not survive starting over after a firing
    await page.evaluate(() => { openModal('<h2 class="h2">Old summary</h2>'); state.gameOver = { reason: 'Test.' }; render(); });
    await page.click('#over [data-act=newgame]');
    check('starting over after a firing closes any old dialog', await page.evaluate(() => document.getElementById('modal').hidden && !document.getElementById('view').inert));
    check('no page errors in the review follow-ups', errors.length === 0, errors[0]);
    await ctx.close();
  }
  {
    const ctx = await browser.newContext();
    await ctx.addInitScript(() => { if (!sessionStorage.getItem('seeded')) { for (let i = 1; i <= 5; i++) localStorage.setItem('mfad-slot-' + i, 'RAW:{"broken":' + i + '}'); sessionStorage.setItem('seeded', '1'); } });
    const page = await ctx.newPage(); const errors = []; page.on('pageerror', e => errors.push(e.message));
    await page.goto(url); await toAD(page);
    const before = await page.evaluate(() => { for (let i = 0; i < 3; i++) advance(); render(); return { week: state.week, untouched: [1, 2, 3, 4, 5].every(i => localStorage.getItem('mfad-slot-' + i) === 'RAW:{"broken":' + i + '}') }; });
    await sleep(400);
    await page.click('#tabs [data-tab=file]'); await page.click('#view [data-act=ask][data-k="del-1"]'); await page.click('#view [data-act=slotdel][data-i="1"]'); await page.waitForFunction(() => !ui.slotBusy); await sleep(400);
    const afterDel = await page.evaluate(async () => ({ week: state.week, slot, blocked: saveBlocked, stored: JSON.parse(await gunz(localStorage.getItem('mfad-slot-1'))).week }));
    check('with every slot damaged, nothing is overwritten until the player frees one', before.untouched);
    check('deleting a damaged slot keeps the unsaved career and saves it there', afterDel.week === before.week && afterDel.slot === 1 && !afterDel.blocked && afterDel.stored === before.week, JSON.stringify(afterDel));
    check('no page errors with damaged slots', errors.length === 0, errors[0]);
    await ctx.close();
  }

  // ---------- saves: switching, leaving the page, imports, damaged slots ----------
  {
    const { ctx, page, errors } = await fresh(browser);
    await sleep(400);
    await page.click('#tabs [data-tab=file]');
    await page.click('#view [data-act=slotnew][data-i="2"]'); await page.click('#view [data-act=startcareer]');
    await page.waitForFunction(() => slot === 2);
    await page.click('#tabs [data-tab=money]');
    const t0 = await page.evaluate(() => state.fin.ticket);
    await page.click('#view [data-act=tix][data-d="1"]');
    await page.click('#tabs [data-tab=file]'); await page.click('#view [data-act=slotload][data-i="1"]'); // immediately, inside the save debounce
    await page.waitForFunction(() => slot === 1 && !ui.slotBusy);
    const s2 = await readSlot(page, 2);
    check('a change made just before switching careers is saved to its slot', s2 && s2.fin.ticket === t0 + 5, `slot 2 ticket ${s2 && s2.fin.ticket}, expected ${t0 + 5}`);
    // leaving the page right after a change
    await page.click('#tabs [data-tab=money]'); await page.click('#view [data-act=tix][data-d="1"]'); await page.click('#view [data-act=tix][data-d="1"]');
    const want = await page.evaluate(() => state.fin.ticket);
    await page.reload(); await toAD(page);
    const got = await page.evaluate(() => ({ t: state.fin.ticket, slot }));
    check('a change made right before reloading survives the reload', got.t === want && got.slot === 1, `${got.t} vs ${want}`);
    // controls at their limits
    await page.click('#tabs [data-tab=money]');
    await page.evaluate(() => { state.fin.ticket = 40; state.fin.revPct = 100; render(); });
    const lim = await page.evaluate(() => { const fan = state.meters.fan, mor = state.meters.morale; const dn = document.querySelector('#view [data-act=tix][data-d="-1"]'), up = document.querySelector('#view [data-act=rev][data-d="1"]'); dn.click(); up.click(); return { dis: dn.disabled && up.disabled, same: state.meters.fan === fan && state.meters.morale === mor }; });
    check('finance buttons are disabled at their limits and clicking them does nothing', lim.dis && lim.same);
    // imports
    await page.click('#tabs [data-tab=file]');
    const before = await page.evaluate(() => ({ season: state.season, bal: state.fin.balance, n: state.roster.length, slot }));
    await page.evaluate(() => flushSave()); // let any save from the reload land first
    const stored1 = await page.evaluate(() => localStorage.getItem('mfad-slot-1'));
    const tryImport = async code => { await page.fill('#importbox', code); await page.click('#view [data-act=import]'); await page.waitForFunction(() => !ui.slotBusy); return page.evaluate(() => ({ msg: ui.importMsg, season: state.season, bal: state.fin.balance, n: state.roster.length, teams: Object.keys(state.teams).length })); };
    const garbage = await tryImport('MFAD1:not-a-real-code');
    const damagedObj = await page.evaluate(() => { const s = JSON.parse(JSON.stringify(state)); s.roster[2].pos = 'XX'; s.fin.balance = -999; return s; });
    const damaged = await tryImport('MFAD0:' + Buffer.from(JSON.stringify(damagedObj)).toString('base64'));
    const empty = await tryImport('MFAD0:' + Buffer.from(JSON.stringify({ v: 1, teams: {}, roster: [] })).toString('base64'));
    const same = r => r.season === before.season && r.bal === before.bal && r.n === before.n && r.teams === 138;
    check('a damaged code is rejected and the game is unchanged', same(garbage) && /damaged|incomplete/.test(garbage.msg), garbage.msg);
    check('a code with a broken player record is rejected and the game is unchanged', same(damaged) && /not changed/.test(damaged.msg), damaged.msg);
    check('an empty save is rejected and the game is unchanged', same(empty), empty.msg);
    await sleep(400);
    check('rejected imports leave the stored slot alone', (await page.evaluate(() => localStorage.getItem('mfad-slot-1'))) === stored1);
    await page.click('#view [data-act=export]'); await page.waitForSelector('#exportbox');
    const code = await page.$eval('#exportbox', el => el.value);
    await page.evaluate(() => { state.fin.balance += 50; save(); });
    const good = await tryImport(code);
    check('a valid save code round-trips', good.bal === before.bal && /loaded/i.test(good.msg), `${good.bal} vs ${before.bal}`);
    check('save codes carry the random position', await page.evaluate(async c => { const s = await readCode(c); return typeof s.rng === 'number' && s.rng > 0; }, code));
    // a damaged slot is skipped at startup and left in place
    await page.evaluate(() => { localStorage.setItem('mfad-slot-3', 'GZ:@@corrupt@@'); const m = JSON.parse(localStorage.getItem('mfad-slots-meta')); m[3] = Object.assign({}, m[1], { name: 'Corrupt' }); localStorage.setItem('mfad-slots-meta', JSON.stringify(m)); localStorage.setItem('mfad-active', '3'); });
    await page.reload(); await toAD(page);
    const boot = await page.evaluate(() => ({ slot, raw: localStorage.getItem('mfad-slot-3'), flash: document.querySelector('#view .flash') && document.querySelector('#view .flash').textContent }));
    check('a damaged slot is skipped at startup, reported, and left untouched', boot.slot !== 3 && boot.raw === 'GZ:@@corrupt@@' && /Slot 3/.test(boot.flash || ''), boot.flash);
    await page.click('#tabs [data-tab=file]'); await page.click('#view [data-act=slotload][data-i="3"]'); await page.waitForFunction(() => !ui.slotBusy);
    const bad3 = await page.evaluate(() => ({ slot, season: state.season, flash: document.querySelector('#view .flash') && document.querySelector('#view .flash').textContent }));
    check('loading a damaged slot keeps the current career open', bad3.slot === boot.slot && /could not be loaded/.test(bad3.flash || ''), bad3.flash);
    // delete the active slot
    await page.click('#view [data-act=ask][data-k="del-2"]'); await page.click('#view [data-act=slotdel][data-i="2"]'); await page.waitForFunction(() => !ui.slotBusy); await sleep(400);
    check('deleting a slot removes it for good', await page.evaluate(() => localStorage.getItem('mfad-slot-2') === null && !JSON.parse(localStorage.getItem('mfad-slots-meta'))[2]));
    check('no page errors in save handling', errors.filter(e => !/console: /.test(e)).length === 0, errors.filter(e => !/console: /.test(e))[0]);
    await ctx.close();
  }

  // ---------- multi-season sim: responsive, cancellable, no overlap ----------
  {
    const { ctx, page, errors } = await fresh(browser);
    await page.evaluate(() => { window.__gaps = []; let t = performance.now(); window.__mon = setInterval(() => { const n = performance.now(); window.__gaps.push(n - t); t = n; }, 10); });
    await page.click('#hdr .simmenu summary'); await page.click('#hdr [data-act=simyears][data-n="10"]');
    await page.waitForSelector('#simcancel');
    const labels = new Set(); for (let i = 0; i < 8; i++) { labels.add(await page.evaluate(() => { const w = document.getElementById('simwhere'); return w && w.textContent; })); await sleep(50); }
    const overlap = await page.evaluate(async () => { const s = state.season; const p = simYears(1); await p; return ui.simming !== null; });
    await page.keyboard.press('Escape');
    await page.waitForFunction(() => !ui.simming && document.querySelector('#modal:not([hidden]) h2') && /summary/i.test(document.getElementById('modaltitle').textContent), null, { timeout: 30000 });
    const r = await page.evaluate(() => ({ season: state.season, h2: document.querySelector('#modal .mbody h2').textContent, max: Math.max(...window.__gaps) }));
    check('multi-season sim reports week-by-week progress', labels.size >= 4, `${labels.size} distinct progress labels`);
    check('a second sim request during a run is ignored', overlap === true);
    check('Escape stops a multi-season sim early and keeps what was simulated', r.season < 2036 && /stopped early/.test(r.h2), r.h2);
    check('the page stays responsive during the sim', r.max < 400, `longest main-thread gap ${Math.round(r.max)} ms`);
    await page.click('#modal [data-act=close]');
    await page.evaluate(() => { window.__gaps = []; });
    const h0 = await page.evaluate(() => state.history.length);
    await page.click('#hdr .simmenu summary'); await page.click('#hdr [data-act=simyears][data-n="1"]');
    await page.waitForFunction(() => !ui.simming && /summary/i.test(document.getElementById('modaltitle').textContent), null, { timeout: 60000 });
    const r2 = await page.evaluate(() => ({ h: state.history.length, phase: state.phase, max: Math.max(...window.__gaps) }));
    check('a full one-season sim completes', r2.h === h0 + 1 || r2.h === h0, `history ${h0} -> ${r2.h}, phase ${r2.phase}`);
    check('no main-thread stall over 400 ms in a full season', r2.max < 400, `longest gap ${Math.round(r2.max)} ms`);
    check('no page errors during multi-season sims', errors.length === 0, errors[0]);
    await ctx.close();
  }

  // ---------- older saves and a custom program ----------
  for (const f of ['v1save.json', 'v2save.json', 'v2save_off.json', 'v3save.json', 'v3custom.json']) {
    const p = path.join(root, f); if (!fs.existsSync(p)) continue;
    const json = fs.readFileSync(p, 'utf8'); const src = JSON.parse(json);
    // The save is placed in storage before any game code runs, exactly as a returning player's browser would have it.
    const ctx = await browser.newContext();
    await ctx.addInitScript(j => { if (!sessionStorage.getItem('seeded')) { localStorage.clear(); localStorage.setItem('mfad-slot-1', 'RAW:' + j); localStorage.setItem('mfad-active', '1'); sessionStorage.setItem('seeded', '1'); } }, json);
    const page = await ctx.newPage(); const errors = []; page.on('pageerror', e => errors.push(e.message));
    await page.goto(url); await toAD(page);
    const r = await page.evaluate(() => ({ v: state.v, slot, season: state.season, week: state.week, phase: state.phase, n: state.roster.length, created: state.created, name: teamName('MICH'), custom: !!state.me, theme: document.getElementById('customTheme').textContent.length, flash: document.querySelector('#view .flash') && document.querySelector('#view .flash').textContent }));
    const same = r.season === src.season && r.week === src.week && r.phase === src.phase && r.n === src.roster.length && r.created === src.created;
    let played = true; try { await page.evaluate(() => { if (state.phase === 'offseason') { autoOffseason(); } else { advance(); } save(); render(); }); await sleep(300); } catch (e) { played = false; }
    const stored = await readSlot(page, 1);
    check(`older save ${f} loads as the same career, migrates and plays on`, same && r.v === 3 && r.slot === 1 && !/could not/.test(r.flash || '') && played && stored && stored.v === 3 && errors.length === 0,
      `${r.name} ${r.season} ${r.phase === 'offseason' ? 'offseason' : 'week ' + r.week}, ${r.n} players${r.custom ? ', custom colors ' + (r.theme > 0 ? 'applied' : 'MISSING') : ''}${errors[0] ? ', ' + errors[0] : ''}`);
    await ctx.close();
  }

  // ---------- settings: theme, mode, sidebar, persistence ----------
  {
    const { ctx, page, errors } = await fresh(browser, { viewport: { width: 1280, height: 860 } });
    await page.click('#tabs [data-tab=settings]');
    await page.waitForFunction(() => ui.tab === 'settings');
    await page.click('#view [data-act=setpref][data-k=skin][data-v=gazette]');
    await page.click('#view [data-act=setpref][data-k=mode][data-v=dark]');
    await page.click('#view [data-act=setpref][data-k=nav][data-v=side]');
    const a = await page.evaluate(() => ({ skin: document.documentElement.dataset.skin, mode: document.documentElement.dataset.mode, nav: document.documentElement.dataset.nav, pad: parseInt(getComputedStyle(document.body).paddingLeft), font: document.getElementById('fontlink').href }));
    check('settings switch theme, dark mode and the sidebar', a.skin === 'gazette' && a.mode === 'dark' && a.nav === 'side' && a.pad >= 200 && /Playfair/.test(a.font), JSON.stringify(a));
    await page.click('#tabs [data-act=toggleside]');
    const h = await page.evaluate(() => ({ side: document.documentElement.dataset.side, pad: parseInt(getComputedStyle(document.body).paddingLeft), menu: !!document.querySelector('#hdr [data-act=toggleside]') }));
    check('the sidebar can be hidden and a menu button brings it back', h.side === 'hidden' && h.pad < 100 && h.menu, JSON.stringify(h));
    await page.click('#hdr [data-act=toggleside]');
    await page.click('#hdr [data-act=togglemode]');
    await page.reload(); await toAD(page);
    const r = await page.evaluate(() => ({ skin: document.documentElement.dataset.skin, mode: document.documentElement.dataset.mode, nav: document.documentElement.dataset.nav, side: document.documentElement.dataset.side }));
    check('display settings survive a reload', r.skin === 'gazette' && r.mode === 'light' && r.nav === 'side' && r.side === 'shown', JSON.stringify(r));
    await page.evaluate(() => { ui.tab = 'settings'; render(); });
    await page.click('#view [data-act=setgame][data-k=diff][data-v=hard]');
    check('difficulty can be changed from Settings', await page.evaluate(() => state.settings.diff === 'hard'));
    check('no page errors while changing settings', errors.length === 0, errors[0]);
    await ctx.close();
  }

  // ---------- game over screen, admin seed, phone width ----------
  {
    const { ctx, page, errors } = await fresh(browser, { viewport: { width: 390, height: 844 } });
    const widths = [];
    const goTab = async t => { if (await page.$(`#mnav [data-tab=${t}]`)) await page.click(`#mnav [data-tab=${t}]`); else { await page.click('#mnav [data-act=moremenu]'); await page.click(`#modal [data-tab=${t}]`); } await page.waitForFunction(k => ui.tab === k && document.getElementById('modal').hidden, t); };
    const bar = await page.evaluate(() => ({ tabs: getComputedStyle(document.getElementById('tabs')).display, mnav: getComputedStyle(document.getElementById('mnav')).display }));
    check('phone width swaps the tab row for a bottom bar', bar.tabs === 'none' && bar.mnav !== 'none', JSON.stringify(bar));
    for (const t of ['office', 'money', 'file', 'recruit', 'admin']) { await goTab(t); widths.push(await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth)); }
    await page.click('#view [data-act=admtab][data-v=game]');
    await page.fill('#adm-set-seed', '777'); await page.dispatchEvent('#adm-set-seed', 'change');
    check('admin can set the random seed', await page.evaluate(() => state.seed === 777 && RNG.s === 777));
    await goTab('office');
    await page.click('#view [data-act=live]'); await page.waitForSelector('#modal:not([hidden]) .live'); await sleep(600);
    widths.push(await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth));
    await page.keyboard.press('Escape');
    check('no sideways scrolling at phone width, including the live game', widths.every(w => w <= 0), widths.join(','));
    await page.click('#hdr [data-act=liveresume]'); await page.click('#modal [data-act=lskip]'); await page.click('#modal .mclose');
    await page.evaluate(() => { state.gameOver = { reason: 'Test firing.' }; render(); });
    const ov = await page.evaluate(() => { const b = document.querySelector('#over .obox'); return { role: b.getAttribute('role'), focus: document.activeElement && document.activeElement.dataset.act, inert: document.getElementById('view').inert }; });
    let esc = 0; for (let i = 0; i < 5; i++) { await page.keyboard.press('Tab'); if (!(await page.evaluate(() => document.querySelector('#over .obox').contains(document.activeElement)))) esc++; }
    check('the game-over screen is an alert dialog that holds focus', ov.role === 'alertdialog' && ov.focus === 'newgame' && ov.inert && esc === 0);
    await page.click('#over [data-act=overhide]');
    const look = await page.evaluate(() => ({ hidden: document.getElementById('over').hidden, inert: document.getElementById('view').inert, link: !!document.querySelector('[data-act=overshow]') }));
    await page.click('[data-act=overshow]');
    check('"Look around first" hides the game-over screen and can bring it back', look.hidden && !look.inert && look.link && await page.evaluate(() => !document.getElementById('over').hidden), JSON.stringify(look));
    await page.click('#over [data-act=newgame]');
    check('starting over from the game-over screen restores the page', await page.evaluate(() => !state.gameOver && document.getElementById('over').hidden && !document.getElementById('view').inert && state.week === 1));
    check('no page errors at phone width', errors.length === 0, errors[0]);
    await ctx.close();
  }

  await browser.close();
  console.log(out.join('\n'));
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.log(out.join('\n')); console.error(e); process.exit(2); });
