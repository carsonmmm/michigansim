// Player Career engine checks. Runs the real source files in a Node VM (no browser).
//   node tests/career.test.js [sourceDir]      (default: ../src next to tests/)
const fs = require('fs'), path = require('path'), vm = require('vm');
const dir = path.resolve(process.argv[2] || ['src', 'v6'].map(d => path.join(__dirname, '..', d)).find(d => fs.existsSync(path.join(d, 'career.js'))));
const src = ['data.js', 'core.js', 'career.js', 'cgame.js'].map(f => fs.readFileSync(path.join(dir, f), 'utf8')).join('\n');
const EXPORTS = 'eligibilityLeft newCareer cSimUntil cSimWeek offStep offNext offersList signWith declareDraft draftProjection outOfEligibility draftEligible cOvr enterPortal portalWait portalCommit careerTotals starsOf recruitScore autoAssign upgrade cCost nilOffer starsFloat cStartGame cgStep cgChoose cgAutoplay cFinishGame cEndWeek mkDecision optDef OPT SCN FOLLOW CPOS CSTYLES newCareer LT teamLevel colEndSeason myColGames setSeed tpl lgNew RNG'.split(' ');
function ctx() {
  const c = { console, Math, JSON, Date, Object, Array, Set, Map, Promise, setTimeout, clearTimeout, String, Number, isFinite, parseInt };
  vm.createContext(c);
  vm.runInContext(src + `\n;this.api={${EXPORTS.map(k => k + ':' + k).join(',')}, get cs(){return cs}, set cs(v){cs=v}, get cg(){return cg}};`, c);
  return c.api;
}
let pass = 0, fail = 0; const out = [];
function check(name, cond, detail) { (cond ? pass++ : fail++); out.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail != null && detail !== '' ? '  (' + detail + ')' : ''}`); }
// Plays a career to the end, making simple choices at every decision point.
function playOut(A, pick) {
  let guard = 0; const info = {};
  while (A.cs.phase !== 'done' && guard++ < 250) {
    const r = A.cSimUntil(null, { events: true, spend: true });
    const s = A.offStep();
    if (A.cs.phase === 'sign' || s === 'signing') { const o = A.offersList(); info.offers = o.length; info.stars = A.cs.p.stars; info.score = A.cs.p.rec.score; const best = (pick || (l => l.slice().sort((a, b) => A.teamLevel(b.id) - A.teamLevel(a.id))[0]))(o); if (!best) { info.stuck = 'no offers'; break; } info.school = best.id; info.nil = best.nil; A.signWith(best.id); continue; }
    if (s === 'draft') { A.declareDraft(A.draftProjection() >= 87 || A.outOfEligibility() || A.cs.col.years >= 4); continue; }
    if (r === 'choice') { info.stuck = A.cs.phase + '/' + s; break; }
  }
  info.done = A.cs.phase === 'done'; return info;
}

// ---------- every position, both starting paths, all the way to the draft ----------
const hsStars = [], results = [];
for (let k = 0; k < 16; k++) {
  const A = ctx(); const pos = A.CPOS[k % 8]; const style = A.CSTYLES[pos][k % A.CSTYLES[pos].length][0];
  const path = k < 8 ? 'hs' : 'college';
  try {
    A.newCareer({ pos, style, first: 'Test', last: 'P' + k, num: k, home: ['MI', 'TX', 'CA', 'FL', 'OH', 'GA', 'NY', 'AZ'][k % 8], path, stars: (k % 5) + 1, diff: 'normal', pace: 'sim' });
    A.cs.p.auto = true;
    const info = playOut(A);
    const p = A.cs.p;
    results.push({ pos, path, info, seasons: p.seasons, draft: A.cs.done && A.cs.done.draft, xp: p.xp, attrs: p.a, earned: p.earned });
    if (path === 'hs') hsStars.push(info.stars);
  } catch (e) { results.push({ pos, path, crash: e.stack.split('\n').slice(0, 3).join(' / ') }); }
}
const crashes = results.filter(r => r.crash);
check('16 careers (8 positions × high school or college start) run to the NFL Draft without errors', !crashes.length && results.every(r => r.info.done), crashes.length ? crashes[0].crash : results.filter(r => !r.info.done).map(r => r.pos + ':' + r.info.stuck).join(', '));
check('every signing had offers to choose from', results.every(r => !r.info || r.info.offers >= 3), results.map(r => r.info && r.info.offers).join(','));
check('auto-simulated high school careers land mostly at 3 and 4 stars', hsStars.filter(s => s >= 3 && s <= 4).length >= 5 && !hsStars.some(s => s < 2), hsStars.join(','));
check('skill points never go negative and ratings stay in range', results.every(r => r.xp >= 0 && Object.values(r.attrs || {}).every(v => v >= 20 && v <= 99)));
const colStarts = results.flatMap(r => (r.seasons || []).filter(s => s.lvl === 'col' && s.gs >= 10));
const bad = colStarts.filter(s => { const t = s.st; return (t.pyd || 0) > 6000 || (t.rec || 0) > 140 || (t.ryd || 0) > 2600 || (t.sack || 0) > 24 || (t.tkl || 0) > 170 || (t.dint || 0) > 14; });
check('full-season college stat lines stay realistic', colStarts.length >= 10 && !bad.length, `${colStarts.length} starter seasons${bad.length ? ', e.g. ' + JSON.stringify(bad[0].st) : ''}`);
const aw = results.flatMap(r => (r.seasons || []).flatMap(x => x.awards || []));
const colSeasons = results.flatMap(r => (r.seasons || []).filter(x => x.lvl === 'col')).length;
const cnt = re => aw.filter(a => re.test(a)).length;
check('major awards stay rare', cnt(/^Heisman Trophy$/) <= 3 && cnt(/^First-team All-American$/) <= colSeasons * 0.2 && cnt(/Mr. Football/) <= 3, `${colSeasons} college seasons: ${cnt(/^Heisman Trophy$/)} Heismans, ${cnt(/^First-team All-American$/)} first-team All-Americans; ${cnt(/Mr. Football/)} Mr. Football`);
check('every drafted career has a round and pick or signs as a free agent', results.every(r => !r.draft || r.draft.udfa || (r.draft.round >= 1 && r.draft.round <= 7 && r.draft.pick >= 1 && r.draft.pick <= 257)));

// ---------- NIL money follows stars, school, conference and position ----------
{
  const A = ctx(); A.newCareer({ pos: 'QB', first: 'N', last: 'Q', num: 1, home: 'OH', path: 'college', stars: 5 });
  const qb5 = A.nilOffer('OSU', 5, 80);
  A.cs.p.pos = 'CB'; const cb5 = A.nilOffer('OSU', 5, 80); const cbMac = A.nilOffer('TOL', 5, 80); const cb3mac = A.nilOffer('TOL', 3, 70);
  A.cs.p.pos = 'QB'; const qb1 = A.nilOffer('UMASS', 1, 50);
  check('a 5-star quarterback at a top Big Ten school is offered roughly $2–3.5M a year', qb5 >= 1.8e6 && qb5 <= 3.6e6, '$' + qb5);
  check('quarterbacks are offered the most', qb5 > cb5 * 1.8, `QB $${qb5} vs CB $${cb5}`);
  check('power-conference schools pay more than Group of Five schools', cb5 > cbMac * 2, `OSU $${cb5} vs Toledo $${cbMac}`);
  check('a 3-star at a MAC school gets a modest deal; a 1-star gets little', cb3mac >= 8000 && cb3mac <= 80000 && qb1 < 12000, `$${cb3mac}, $${qb1}`);
}

// ---------- recruiting offers scale with the star rating ----------
{
  const counts = {};
  for (const st of [1, 3, 5]) { const A = ctx(); A.newCareer({ pos: 'WR', first: 'O', last: 'C', num: 1, home: 'GA', path: 'college', stars: st }); const o = A.offersList(); counts[st] = { n: o.length, top: Math.max(...o.map(x => A.teamLevel(x.id))) }; }
  check('more stars bring more offers and better schools', counts[1].n < counts[3].n && counts[3].n < counts[5].n && counts[1].top < counts[5].top, JSON.stringify(counts));
}

// ---------- snap decisions: every option at every position resolves cleanly ----------
{
  const probs = [];
  for (const pos of ['QB', 'RB', 'WR', 'TE', 'CB', 'DE', 'LB', 'S']) {
    const A = ctx(); A.newCareer({ pos, first: 'D', last: 'X', num: 1, home: 'MI', path: 'college', stars: 5 }); A.signWith(A.offersList()[0].id);
    for (let rep = 0; rep < 60; rep++) {
      const g = A.cStartGame(); if (!g) break; g.share = 1; g.plan = [...Array(g.total).keys()];
      let guard = 0;
      while (!g.done && guard++ < 300) {
        if (g.pending) { const opts = g.pending.opts; const k = opts[rep % opts.length]; if (!A.optDef(pos, k)) probs.push(pos + ':' + k + ' missing'); const r = A.cgChoose(g, k); if (!r) probs.push(pos + ':' + k + ' no result'); else if (/\{|\bundefined\b|NaN|\b1 yards\b/.test(r.txt)) probs.push(pos + ':' + k + ' "' + r.txt + '"'); }
        else A.cgStep(g);
      }
      A.cFinishGame(g); A.cEndWeek();
      if (A.cs.phase !== 'col') break;
    }
  }
  check('every snap-decision option at every position resolves with readable text', !probs.length, probs.slice(0, 3).join(' | '));
}

// ---------- redshirt, portal, eligibility and the draft ----------
{
  const A = ctx(); A.newCareer({ pos: 'LB', first: 'R', last: 'S', num: 1, home: 'TX', path: 'college', stars: 3 });
  const tid = A.offersList().sort((a, b) => A.teamLevel(b.id) - A.teamLevel(a.id))[0].id; A.signWith(tid);
  A.cs.col.rs = true; A.cSimUntil(() => A.cs.phase !== 'col', { events: true });
  check('a redshirt season with four games or fewer does not use a year of eligibility', A.cs.col.seasons === 0 && A.cs.col.rsYear && A.cs.col.years === 2, `seasons ${A.cs.col.seasons}, games ${A.cs.p.seasons[0].gp}`);
  while (A.offStep() && A.offStep() !== 'portal') A.offNext();
  const from = A.cs.col.tid; A.enterPortal(); A.portalWait(); A.portalWait();
  const offers = Object.keys(A.cs.portal.offers);
  check('the transfer portal always produces at least two offers', offers.length >= 2, offers.length + ' offers');
  const to = offers.find(t => t !== from) || offers[0]; A.portalCommit(to);
  check('committing in the portal moves the player and resets coach trust', A.cs.col.tid === to && (to === from || (A.cs.p.trust === 45 && A.cs.col.transfers === 1)) && A.cs.col.nil === A.cs.portal.offers[to].nil);
  A.offNext(); while (A.offStep()) A.offNext();
  check('the next season starts at the new school', A.cs.phase === 'col' && A.cs.week === 1 && A.myColGames().filter(g => g.type === 'reg').length === 12);
  A.cs.col.seasons = 4; A.colEndSeason(); A.offNext();
  check('a player out of eligibility cannot return to school', A.offStep() === 'draft' && A.declareDraft(false) === false && A.cs.off.steps.indexOf('portal') < 0);
  A.declareDraft(true);
  check('declaring runs the draft and ends the career', A.cs.phase === 'done' && !!A.cs.done.draft);
}


// ---------- the player's team plays its postseason with him (bowls, title games, playoff) ----------
{
  let seasons = 0, mism = [], post = 0;
  for (let k = 0; k < 6; k++) {
    const A = ctx(); A.newCareer({ pos: ['QB', 'RB', 'WR', 'LB', 'CB', 'DE'][k], first: 'P', last: 'S' + k, num: 1, home: 'OH', path: 'college', stars: 5 });
    A.signWith(A.offersList().sort((a, b) => A.teamLevel(b.id) - A.teamLevel(a.id))[k % 3].id);
    for (let yr = 0; yr < 2; yr++) {
      A.cSimUntil(() => A.cs.phase !== 'col', { events: true });
      const e = A.cs.p.seasons[A.cs.p.seasons.length - 1]; const [w, l] = e.rec.split('-').map(Number); seasons++;
      post += A.cs.ss.games.filter(g => g.wk > 13).length;
      if (w + l !== A.cs.ss.games.length) mism.push(`${e.team} ${e.rec} but ${A.cs.ss.games.length} games played`);
      while (A.offStep()) { if (A.offStep() === 'draft') A.declareDraft(false); A.offNext(); }
    }
  }
  check('the player plays every one of his team\'s games, postseason included', !mism.length && post > 0, `${seasons} seasons, ${post} postseason games${mism.length ? '; ' + mism[0] : ''}`);
}

// ---------- eligibility clock: redshirt fifth year, draft after three years ----------
{
  const A = ctx(); A.newCareer({ pos: 'S', first: 'E', last: 'C', num: 1, home: 'TX', path: 'college', stars: 3 }); A.signWith(A.offersList()[0].id);
  const steps = [];
  for (let yr = 1; yr <= 3; yr++) { A.cSimUntil(() => A.cs.phase !== 'col', { events: true }); steps.push(A.cs.off.steps.includes('draft')); while (A.offStep()) { if (A.offStep() === 'draft') A.declareDraft(false); A.offNext(); } }
  check('the NFL Draft decision first comes after three college seasons', steps.join() === 'false,false,true', steps.join());
  Object.assign(A.cs.col, { years: 5, seasons: 3, rsYear: true });
  const fifth = !A.outOfEligibility() && A.eligibilityLeft() === 1;
  Object.assign(A.cs.col, { years: 6, seasons: 3 });
  check('a redshirted player gets his fifth year, and the five-year clock then ends his career', fifth && A.outOfEligibility());
}

// ---------- a high school injury heals over the offseason ----------
{
  const A = ctx(); A.newCareer({ pos: 'RB', first: 'I', last: 'H', num: 1, home: 'GA', path: 'hs' });
  A.cs.p.inj = 30; A.cs.p.injName = 'Torn ACL';
  A.cSimUntil(() => A.cs.phase === 'hs' && A.cs.hs.cls === 1, { events: true, max: 200 });
  check('a season-ending high school injury is healed by the next season', A.cs.p.inj === 0 && A.cs.hs.cls === 1);
}
// ---------- saves carry the random position, so a loaded career plays out identically ----------
{
  const A = ctx(); A.newCareer({ pos: 'RB', first: 'S', last: 'V', num: 1, home: 'FL', path: 'hs' });
  A.cSimWeek(); A.cs.rng = A.RNG.s; const json = JSON.stringify(A.cs);
  const runFrom = () => { const B = ctx(); B.cs = JSON.parse(json); B.RNG.s = B.cs.rng; for (let i = 0; i < 4; i++) B.cSimWeek(); return JSON.stringify([B.cs.p.a, B.cs.ss.st, B.cs.hs.w, B.cs.league.games.filter(g => g.done).map(g => g.hs + '-' + g.as).join()]); };
  check('a saved career reloads and plays out exactly the same way', runFrom() === runFrom());
}

// ---------- skill point costs ----------
{
  const A = ctx(); A.newCareer({ pos: 'QB', first: 'U', last: 'P', num: 1, home: 'MI', path: 'hs' });
  const p = A.cs.p; p.xp = 7; const before = p.a.acc; const c = A.cCost(before); const n = A.upgrade('acc', 5);
  check('upgrades cost more as a rating climbs and never overspend', A.cCost(50) < A.cCost(70) && A.cCost(70) < A.cCost(90) && p.xp >= 0 && p.a.acc === before + n && n >= 1, `cost ${c}, bought ${n}, left ${p.xp}`);
}

console.log(out.join('\n'));
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
