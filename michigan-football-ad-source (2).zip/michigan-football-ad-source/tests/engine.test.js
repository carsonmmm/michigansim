// Engine and storage regression checks. Runs the real source files in a Node VM with a fake
// browser (localStorage, window, document), so no UI is involved.
//   node tests/engine.test.js [sourceDir]      (default: ../src, the source folder next to tests/)
const fs = require('fs'), path = require('path'), vm = require('vm');
const dir = path.resolve(process.argv[2] || ['src', 'v4'].map(d => path.join(__dirname, '..', d)).find(d => fs.existsSync(d)));
const FIX = [path.join(__dirname, 'fixtures'), path.join(__dirname, '..')].find(d => fs.existsSync(path.join(d, 'v1save.json'))) || __dirname;
// Older builds kept season systems in more.js and had no storage.js; both layouts load so the
// same checks can be pointed at an earlier version for a before/after comparison.
const FILES = ['data.js', 'core.js', 'features.js', fs.existsSync(path.join(dir, 'systems.js')) ? 'systems.js' : 'more.js', 'storage.js'].filter(f => fs.existsSync(path.join(dir, f)));

function makeContext() {
  const store = new Map();
  const localStorage = { getItem: k => (store.has(k) ? store.get(k) : null), setItem: (k, v) => store.set(k, String(v)), removeItem: k => store.delete(k), clear: () => store.clear(), _store: store };
  const noop = () => {};
  const ctx = {
    console, setTimeout, clearTimeout, performance, Promise, JSON, Math, Date, Blob, Response,
    localStorage, window: { addEventListener: noop }, document: { addEventListener: noop, getElementById: () => null, visibilityState: 'visible' },
    btoa: s => Buffer.from(s, 'binary').toString('base64'), atob: s => Buffer.from(s, 'base64').toString('binary'),
    escape, unescape, ui: {}, applyTheme: noop, render: noop,
  };
  vm.createContext(ctx);
  vm.runInContext(FILES.map(f => fs.readFileSync(path.join(dir, f), 'utf8')).join('\n'), ctx, { filename: 'engine' });
  return ctx;
}
const run = (ctx, code) => vm.runInContext("{" + code + "\n}", ctx); // block-scoped so each check can reuse names

let pass = 0, fail = 0; const results = [];
async function sec(fn) { try { await fn(); } catch (e) { fail++; results.push('FAIL  section error: ' + String(e.message).split('\n')[0]); } }
function check(name, cond, detail) { (cond ? pass++ : fail++); results.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail ? '  (' + detail + ')' : ''}`); }

(async () => {
  // ---------- Issue 3: offer / withdraw cannot farm interest ----------
  await sec(async () => {
    const c = makeContext();
    const r = run(c, `newGame('normal', null, 7); const r = state.rec.list.find(x => x.status === 'open' && x.interest < 80 && !x.offered); const start = r.interest;
      for (let i = 0; i < 5; i++) { toggleOffer(r.id); toggleOffer(r.id); }
      const afterCycles = r.interest; toggleOffer(r.id); const offered = r.interest;
      const hi = state.rec.list.find(x => x.status === 'open' && !x.offered && x.id !== r.id); hi.interest = 97; toggleOffer(hi.id); const hiOn = hi.interest; toggleOffer(hi.id);
      ({ start, afterCycles, offered, stillOffered: r.offered, hiOn, hiOff: hi.interest })`);
    check('offer/withdraw x5 leaves interest unchanged', r.afterCycles === r.start, `${r.start} -> ${r.afterCycles}`);
    check('a standing offer still gives its one-time +4', r.offered === Math.min(99, r.start + 4) && r.stillOffered, `${r.start} -> ${r.offered}`);
    check('withdrawing near the 99 cap returns the exact bump', r.hiOn === 99 && r.hiOff === 97, `97 -> ${r.hiOn} -> ${r.hiOff}`);
  });

  // ---------- Issue 4: finance levers only move meters when the value moves ----------
  await sec(async () => {
    const c = makeContext();
    const r = run(c, `newGame('normal', null, 11); const m = state.meters; const out = {};
      state.fin.ticket = 40; m.fan = 60; out.tDown = adjustLever('ticket', -1); out.fanAtMin = m.fan;
      state.fin.revPct = 100; m.morale = 60; out.rUp = adjustLever('revPct', 1); out.moraleAtMax = m.morale;
      out.limits = [leverAt('ticket', -1), leverAt('revPct', 1)];
      state.fin.recruit = 10; out.recUp = adjustLever('recruit', 1); state.fin.compliance = 0.5; out.compDown = adjustLever('compliance', -1);
      state.fin.ticket = 100; m.fan = 60; adjustLever('ticket', 1); out.fanUp = m.fan; adjustLever('ticket', -1); out.fanRound = m.fan; out.ticketRound = state.fin.ticket;
      state.fin.ticket = 40; m.fan = 60; state.off = { boardRes: null, vote: null }; presentBoard({ stance: 'balanced', fac: 'none', tix: 'cut', vote: 'yes' }); out.boardCutFan = m.fan; out.boardCutTicket = state.fin.ticket;
      const f2 = m.fan; presentBoard({ stance: 'balanced', fac: 'none', tix: 'cut', vote: 'yes' }); out.boardTwice = m.fan === f2;
      state.fin.recruit = 1; m.board = 50; state.off = { boardRes: null, vote: null }; presentBoard({ stance: 'lean', fac: 'none', tix: 'hold', vote: 'yes' }); out.leanBoard = m.board;
      state.fin.ticket = 200; m.fan = 60; state.off = { boardRes: null, vote: null }; presentBoard({ stance: 'balanced', fac: 'none', tix: 'raise', vote: 'yes' }); out.raiseTicket = state.fin.ticket; out.raiseFan = m.fan;
      out`);
    check('ticket decrease at $40 changes nothing', r.tDown === false && r.fanAtMin === 60);
    check('revenue share increase at 100% changes nothing', r.rUp === false && r.moraleAtMax === 60);
    check('recruiting budget and compliance respect their limits', r.recUp === false && r.compDown === false);
    check('controls report being at their limits', r.limits[0] === true && r.limits[1] === true);
    check('ticket +$5 then -$5 is meter-neutral', r.fanUp === 59 && r.fanRound === 60 && r.ticketRound === 100, `fan 60 -> ${r.fanUp} -> ${r.fanRound}`);
    check('board "cut tickets" at $40 gives no fan bump', r.boardCutFan === 60 && r.boardCutTicket === 40);
    check('board meeting can only be held once per offseason', r.boardTwice);
    check('board "leaner budget" at the $1M floor gives no board bump', r.leanBoard === 50);
    check('board ticket raise stops at $200', r.raiseTicket === 200 && r.raiseFan === 60);
  });

  // ---------- Issue 5: a w-week injury costs w weeks ----------
  await sec(async () => {
    const c = makeContext(); let checked = 0, bad = [];
    for (let seed = 1; seed <= 14; seed++) {
      // Record each injury at the moment it happens (the duration the news story announces),
      // then count the weeks the player starts unavailable.
      const r = run(c, `newGame('normal', null, ${seed}); const track = {}; const fresh = []; const real = rollInjuries;
        rollInjuries = function () { const before = {}; state.roster.forEach(p => before[p.id] = p.inj || 0); real(); state.roster.forEach(p => { if (!before[p.id] && p.inj > 0 && p.inj < 99) fresh.push({ id: p.id, stated: p.inj, wk: state.week }); }); };
        while (state.phase === 'regular') {
          Object.values(track).forEach(t => { if (!t.done) { if (P(t.id).inj > 0) t.missed++; else t.done = true; } });
          advance();
          fresh.splice(0).forEach(f => { if (f.wk <= 8 && !track[f.id]) track[f.id] = Object.assign(f, { missed: 0, done: false }); });
        }
        rollInjuries = real;
        Object.values(track).filter(t => t.done)`);
      r.forEach(t => { checked++; if (t.missed !== t.stated) bad.push(`seed ${seed} wk ${t.wk}: stated ${t.stated}, missed ${t.missed}`); });
    }
    check('every injury keeps a player out for its stated number of weeks', checked > 5 && bad.length === 0, `${checked} injuries checked${bad.length ? '; ' + bad.slice(0, 3).join('; ') : ''}`);
    const r1 = run(c, `newGame('normal', null, 3); const qb = starters('QB')[0]; const real = rollInjuries;
      rollInjuries = function () { real(); if (state.week === 1) { qb.inj = 1; qb.injFresh = true; qb.injType = 'Test'; } };
      advance(); rollInjuries = real; const afterWk1 = avail(qb); advance(); ({ afterWk1, afterWk2: avail(qb) })`);
    check('a one-week injury in week 1 sidelines the player for week 2 only', r1.afterWk1 === false && r1.afterWk2 === true);
    const r2 = run(c, `newGame('normal', null, 5); const byeWk = [...Array(13)].map((_, i) => i + 1).find(w => !state.games.some(g => g.wk === w && (g.h === 'MICH' || g.a === 'MICH')));
      while (state.week < byeWk) advance(); const p = starters('WR')[0]; p.susp = 1; advance(); const afterBye = p.susp; advance(); ({ byeWk, afterBye, afterGame: p.susp })`);
    check('an open week does not count toward a suspension', r2.byeWk && r2.afterBye === 1 && r2.afterGame === 0, `bye week ${r2.byeWk}`);
  });

  // ---------- Item 10: seeded, reproducible simulation ----------
  await sec(async () => {
    const c = makeContext();
    const fp = `(() => { const m = T('MICH'); return JSON.stringify([m.w, m.l, state.games.filter(g => g.done).slice(0, 60).map(g => g.hs + '-' + g.as), state.history.map(h => h.champ)]); })()`;
    const a = run(c, `newGame('normal', null, 424242); autoSeason(); ${fp}`);
    const b = run(c, `newGame('normal', null, 424242); autoSeason(); ${fp}`);
    const d = run(c, `newGame('normal', null, 99); autoSeason(); ${fp}`);
    check('same seed, same season', a === b);
    check('different seed, different season', a !== d);
    const m = run(c, `newGame('normal', null, 2026); for (let i = 0; i < 3; i++) advance(); save(); const snap = JSON.stringify(state); const rng = RNG.s;
      for (let i = 0; i < 6; i++) advance(); const first = ${fp};
      state = JSON.parse(snap); rebuildPMap(); rebuildConfs(); RNG.s = rng; for (let i = 0; i < 6; i++) advance(); ({ first, second: ${fp}, savedRng: JSON.parse(snap).rng === rng })`);
    check('a saved game replays identically from its saved random position', m.first === m.second && m.savedRng);
  });

  // ---------- Item 11: season-aware labels ----------
  await sec(async () => {
    const c = makeContext();
    const r = run(c, `newGame('normal', null, 1); ({ a: weekLabel(15, 2026), b: weekLabel(15, 2027), c: weekLabel(14, 2027), d: weekLabel(14, 2026), e: weekLabel(18, 2029), f: weekLabel(1, 2027) })`);
    check('2026 playoff labels keep the published dates', /Dec 18/.test(r.a), r.a);
    check('later playoff labels show the round without invented dates', r.b === 'CFP First Round' && r.e === 'National Championship', r.b);
    check('championship Saturday follows the calendar', /Dec 4/.test(r.c) && /Dec 5/.test(r.d), `${r.d} | ${r.c}`);
    check('regular-season weeks carry that season\'s dates', /^Week 1 · /.test(r.f), r.f);
  });

  // ---------- Related exploits found during review ----------
  await sec(async () => {
    const c = makeContext();
    const r = run(c, `newGame('normal', null, 8); const role = 'DC'; const co = state.staff[role]; const offer = { sal: co.salary * 3, yrs: 4, buy: 1, incConf: true, incCFP: true };
      const m0 = state.meters.morale; const first = negotiateExt(role, offer); const m1 = state.meters.morale; const second = negotiateExt(role, offer); const m2 = state.meters.morale;
      const d = state.deals[0]; d.thru = state.season + 5; const bal = state.fin.balance; signDeal(d.id, 'long');
      ({ first, second, moraleSame: m1 === m2, dealBlocked: state.fin.balance === bal && d.thru === state.season + 5, canNow: canExtend(co) })`);
    check('a coach can be extended once per season', r.first === 'signed' && r.second === 'done' && r.moraleSame && !r.canNow, `${r.first}, then ${r.second}`);
    check('a sponsorship deal that is not open cannot be re-signed', r.dealBlocked);
  });

  // ---------- Issue 2: loading validates a candidate and keeps the current game on failure ----------
  await sec(async () => {
    const c = makeContext();
    const r = run(c, `newGame('normal', null, 12); const good = JSON.parse(JSON.stringify(state)); state.fin.balance = 123.4; const cur = state; const rng = RNG.s; const out = {};
      const tryAdopt = cand => { try { adoptState(cand); return 'ok'; } catch (e) { return e.message; } };
      out.empty = tryAdopt({ v: 1, teams: {}, roster: [] });
      const broken = JSON.parse(JSON.stringify(good)); broken.teams.MICH.conf = 'SEC'; broken.roster[3].pos = 'XX'; out.broken = tryAdopt(broken);
      out.kept = state === cur && state.fin.balance === 123.4 && P(cur.roster[0].id) === cur.roster[0] && RNG.s === rng && CONFS.B1G.teams.includes('MICH') && !CONFS.SEC.teams.includes('MICH');
      const noDepth = JSON.parse(JSON.stringify(good)); delete noDepth.depth.QB; out.noDepth = tryAdopt(noDepth); out.kept2 = state === cur;
      const ok = JSON.parse(JSON.stringify(good)); ok.fin.balance = 7; ok.rng = 555; out.good = tryAdopt(ok); out.adopted = state.fin.balance === 7 && RNG.s === 555;
      out`);
    check('a save with no league data is rejected', r.empty !== 'ok', r.empty);
    check('a save with a damaged player is rejected', r.broken !== 'ok', r.broken);
    check('after a rejected load the previous game, index, conferences and seed are intact', r.kept && r.kept2);
    check('a save missing a depth chart is rejected', r.noDepth !== 'ok', r.noDepth);
    check('a valid save is adopted with its random position', r.good === 'ok' && r.adopted);
    for (const f of ['v1save.json', 'v2save.json', 'v2save_off.json', 'v3save.json', 'v3custom.json']) {
      const p = path.join(FIX, f); if (!fs.existsSync(p)) continue;
      const res = run(c, `(() => { try { adoptState(JSON.parse(${JSON.stringify(fs.readFileSync(p, 'utf8'))})); for (let i = 0; i < 3; i++) { if (state.phase === 'offseason') autoOffseason(); else advance(); } return 'ok v' + state.v; } catch (e) { return 'ERR ' + e.message; } })()`);
      check(`older save ${f} migrates and keeps playing`, res === 'ok v3', res);
    }
  });

  // ---------- An unfinished live game in a save is settled, the same way every time ----------
  await sec(async () => {
    const c = makeContext();
    const r = run(c, `newGame('normal', null, 64); simOthers(1); state.liveWk = 1; state.liveRng = RNG.s; state.rng = RNG.s; const snap = JSON.stringify(state);
      const score = () => { const g = state.games.find(x => x.wk === 1 && (x.h === 'MICH' || x.a === 'MICH')); return g.done ? g.hs + '-' + g.as : 'not played'; };
      const sim = createSim(michGameThisWeek(1), { live: true }); for (let i = 0; i < 8; i++) simStep(sim); // part of the game watched, random position moved on
      adoptState(JSON.parse(snap)); const a = { score: score(), week: state.week, flag: state.liveWk, flash: ui.flash };
      for (let i = 0; i < 50; i++) R();
      const later = JSON.parse(snap); later.rng = RNG.s; adoptState(later); ({ a, b: score() })`);
    check('an unfinished live game in a save is played to the final on load', r.a.week === 2 && r.a.score !== 'not played' && r.a.flag === null && /played to the final/.test(r.a.flash || ''), r.a.score);
    check('reloading cannot replay it for a different result', r.a.score === r.b, `${r.a.score} and ${r.b}`);
  });

  // ---------- Issue 1: saves are queued per slot and never go backwards ----------
  await sec(async () => {
    const c = makeContext();
    const r = await run(c, `(async () => {
      const read = async i => JSON.parse(await gunz(localStorage.getItem(SLOT_KEY(i))));
      newGame('normal', null, 21); setActiveSlot(1); state.fin.ticket = 150; save();
      // switch careers before the debounce fires: the outgoing slot must still be written
      setActiveSlot(2); newGame('normal', null, 22); state.fin.ticket = 60; save();
      await flushSave(); const s1 = (await read(1)).fin.ticket, s2 = (await read(2)).fin.ticket;
      // older snapshot slow to compress, newer one fast: the newer one must win
      const realGz = gz; let calls = 0; gz = async str => { const n = ++calls; await new Promise(r => setTimeout(r, n === 1 ? 60 : 1)); return realGz(str); };
      state.fin.ticket = 70; save(); const p1 = flushSave(); state.fin.ticket = 80; save(); await flushSave(); await p1; gz = realGz;
      const s2b = (await read(2)).fin.ticket;
      // leaving the page: pending snapshot written synchronously
      state.fin.ticket = 90; save(); flushSync(); const raw = localStorage.getItem(SLOT_KEY(2)); const s2c = JSON.parse(raw.slice(4)).fin.ticket;
      await new Promise(r => setTimeout(r, 250)); const s2d = (await read(2)).fin.ticket;
      // deleting a slot retires writes still queued for it
      state.fin.ticket = 95; save(); await deleteSlot(2); await flushSave(); const gone = localStorage.getItem(SLOT_KEY(2)) === null && !slotsMeta()[2];
      const meta = slotsMeta();
      return { s1, s2, s2b, s2c, s2d, rawPrefix: raw.slice(0, 4), gone, meta1: !!meta[1] };
    })()`);
    check('switching careers does not drop the outgoing save', r.s1 === 150 && r.s2 === 60, `slot1 ${r.s1}, slot2 ${r.s2}`);
    check('an older, slower write never overwrites a newer snapshot', r.s2b === 80, `stored ${r.s2b}`);
    check('pending saves are written synchronously when the page is hidden', r.s2c === 90 && r.rawPrefix === 'RAW:' && r.s2d === 90);
    check('a deleted slot stays deleted even with a save queued', r.gone && r.meta1);
  });

  // ---------- Quick-sim soak: three full seasons, including offseasons ----------
  await sec(async () => {
    const c = makeContext();
    const r = run(c, `(() => { newGame('normal', null, 31337); const errs = [];
      for (let s = 0; s < 3; s++) { try { autoSeason(); } catch (e) { errs.push(e.message); break; } }
      const bad = POS_ORDER.filter(p => !Array.isArray(state.depth[p]) || state.depth[p].some(id => !P(id)));
      return { errs, season: state.season, hist: state.history.length, bad, roster: state.roster.length, limit: rosterLimit() }; })()`);
    check('three automated seasons complete', r.errs.length === 0 && r.hist === 3 && r.season === 2029, `season ${r.season}, ${r.hist} in history${r.errs.length ? ', ' + r.errs[0] : ''}`);
    check('depth charts only reference rostered players', r.bad.length === 0, r.bad.join(','));
    check('roster within its limit', r.roster <= r.limit, `${r.roster}/${r.limit}`);
  });

  console.log(results.join('\n'));
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
