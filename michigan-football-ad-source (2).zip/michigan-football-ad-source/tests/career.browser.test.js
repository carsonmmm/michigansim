// Player Career and home screen checks in headless Chromium.
//   NODE_PATH=$(npm root -g) node tests/career.browser.test.js [path/to/game.html]
const { chromium } = require('playwright');
const path = require('path');
const file = path.resolve(process.argv[2] || path.join(__dirname, '..', 'michigan-football-ad.html'));
const url = 'file://' + file;
let pass = 0, fail = 0; const out = [];
function check(name, cond, detail) { (cond ? pass++ : fail++); out.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail != null && detail !== '' ? '  (' + detail + ')' : ''}`); }
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function fresh(browser, opts) {
  const ctx = await browser.newContext(opts || {}); await ctx.addInitScript(() => { if (!localStorage.getItem('mfad-prefs')) localStorage.setItem('mfad-prefs', JSON.stringify({ seen: 1, liveSpeed: 3, anim: 'off' })); });
  const page = await ctx.newPage(); const errors = [];
  page.on('pageerror', e => errors.push(e.message)); page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push('console: ' + m.text()); });
  await page.goto(url); await page.waitForSelector('#view .modes');
  return { ctx, page, errors };
}
async function createPlayer(page, o) {
  await page.click('#view [data-act=gocareer]'); await page.waitForSelector('#cnewform');
  await page.fill('#cf-first', o.first || 'Test'); await page.fill('#cf-last', o.last || 'Player');
  await page.click(`[data-act=cform][data-k=pos][data-v=${o.pos || 'WR'}]`);
  if (o.path === 'college') { await page.click('[data-act=cform][data-k=path][data-v=college]'); await page.click(`[data-act=cform][data-k=stars][data-v="${o.stars || 3}"]`); }
  await page.click('[data-act=cstart]'); await page.waitForFunction(() => cs && appMode === 'career');
}
async function playToEnd(page) {
  for (let i = 0; i < 200; i++) {
    const st = await page.evaluate(() => ({ pend: !!(cg && cg.pending), done: !!(cg && cg.done) }));
    if (st.done) return true;
    if (st.pend) await page.click('#cdec .evopt >> nth=0'); else await sleep(40);
  }
  return false;
}

(async () => {
  const browser = await chromium.launch();

  // ---------- home screen, both modes ----------
  {
    const { ctx, page, errors } = await fresh(browser);
    const h = await page.evaluate(() => ({ app: document.documentElement.dataset.app, modes: document.querySelectorAll('#view .mode').length, tabs: document.getElementById('tabs').offsetParent === null, ad: !!document.querySelector('[data-act=goad]'), pc: !!document.querySelector('[data-act=gocareer]') }));
    check('the site opens on a home screen offering AD mode and Player Career', h.app === 'home' && h.modes === 2 && h.ad && h.pc && h.tabs, JSON.stringify(h));
    await page.click('[data-act=goad]'); await page.waitForFunction(() => appMode === 'ad' && state && document.querySelector('#hdr [data-act=primary]'));
    await page.click('#hdr [data-act=gohome]'); await page.waitForSelector('#view .modes');
    const adSaved = await page.evaluate(() => !!localStorage.getItem('mfad-slot-1'));
    check('AD mode starts from the home screen and Home returns to it', adSaved);
    // new player: validation, then creation
    await page.click('#view [data-act=gocareer]'); await page.waitForSelector('#cnewform');
    await page.fill('#cf-first', ''); await page.click('[data-act=cstart]');
    check('the new-player form asks for a name', await page.evaluate(() => /name/.test(document.querySelector('#cnewform .flash') ? document.querySelector('#cnewform .flash').textContent : '')));
    await page.fill('#cf-first', 'Jalen'); await page.fill('#cf-last', 'Brooks'); await page.click('[data-act=cform][data-k=pos][data-v=CB]');
    const styles = await page.evaluate(() => [...document.querySelectorAll('[data-act=cform][data-k=style]')].map(b => b.dataset.v).join(','));
    await page.click('[data-act=cstart]'); await page.waitForFunction(() => cs && cs.p.pos === 'CB');
    const c = await page.evaluate(() => ({ phase: cs.phase, cls: cs.hs.cls, name: cName(cs.p), slot: !!localStorage.getItem('mfpc-slot-1') || !!(csave.pending), ad: !!localStorage.getItem('mfad-slot-1') }));
    check('creating a cornerback starts a high school career with cornerback play styles', c.phase === 'hs' && c.cls === 0 && c.name === 'Jalen Brooks' && styles === 'lockdown,ballhawk,speed' && c.ad, JSON.stringify(c) + ' ' + styles);
    // play a game with snap decisions, leave it mid-game, resume it (as a starter, so there are several)
    await page.evaluate(() => { Object.keys(cs.p.a).forEach(k => cs.p.a[k] = 72); render(); });
    await page.click('#hdr .btn.primary'); await page.waitForSelector('#modal:not([hidden]) .cgame');
    await page.waitForSelector('#cdec .evopt', { timeout: 20000 });
    const focusOpt = await page.evaluate(() => document.activeElement && document.activeElement.dataset.act === 'cpick');
    await page.click('#cdec .evopt >> nth=0');
    await page.keyboard.press('Escape'); await sleep(100);
    const mid = await page.evaluate(() => ({ hidden: document.getElementById('modal').hidden, label: document.querySelector('#hdr .btn.primary').textContent, week: cs.week }));
    await page.click('#hdr [data-act=csim]').catch(() => { });
    const blocked = await page.evaluate(() => cs.week);
    await page.click('#hdr .btn.primary'); await page.waitForSelector('#modal:not([hidden]) .cgame');
    const finished = await playToEnd(page);
    const fin = await page.evaluate(() => ({ grade: !!document.querySelector('.gsum'), week: cs.week }));
    await page.click('#cgdonebtn');
    const after = await page.evaluate(() => ({ week: cs.week, games: cs.ss.games.length, hidden: document.getElementById('modal').hidden }));
    check('a game stops for snap decisions and focus lands on the choices', focusOpt);
    check('closing a game keeps it paused, blocks sims and offers to resume', mid.hidden && /Resume/.test(mid.label) && blocked === mid.week, mid.label);
    check('finishing a game shows the grade and moves to the next week', finished && fin.grade && after.week === 2 && after.games === 1 && after.hidden, JSON.stringify(after));
    // an unfinished game is played to the final after a reload
    await page.click('#hdr .btn.primary'); await page.waitForSelector('#cdec .evopt', { timeout: 20000 });
    await page.evaluate(() => cFlushSync());
    await page.reload(); await page.waitForSelector('#view .modes'); await page.click('#view [data-act=gocareer]'); await page.waitForFunction(() => cs && appMode === 'career').catch(async e => { console.log('ERRS', errors); throw e; });
    const set = await page.evaluate(() => ({ week: cs.week, games: cs.ss.games.length, flash: (document.querySelector('#view .flash') || {}).textContent || '' }));
    check('a game left unfinished is played to the final after a reload, with a notice', set.week === 3 && set.games === 2 && /played to the final/.test(set.flash), JSON.stringify(set));
    // upgrades
    await page.evaluate(() => { cs.p.xp = 20; cui.tab = 'player'; render(); });
    const a0 = await page.evaluate(() => cs.p.a.man); await page.click('[data-act=cup][data-k=man]:not([data-n])');
    const a1 = await page.evaluate(() => ({ v: cs.p.a.man, xp: cs.p.xp, focus: document.activeElement && document.activeElement.dataset.k }));
    check('spending a skill point raises the rating and keeps focus on the button', a1.v === a0 + 1 && a1.xp < 20 && a1.focus === 'man', JSON.stringify(a1));
    // sim ahead to signing day
    await page.evaluate(() => { cui.tab = 'home'; render(); });
    await page.click('#hdr .simmenu summary'); await page.click('[data-act=csimto][data-v=signing]');
    await page.waitForSelector('#modal:not([hidden])'); await page.click('#modal [data-act=close]');
    const sg = await page.evaluate(() => ({ step: offStep(), offers: offersList().length, stars: cs.p.stars, seasons: cs.p.seasons.length }));
    check('"Sim to signing day" plays out high school and stops at signing day', sg.step === 'signing' && sg.offers >= 3 && sg.seasons === 4, JSON.stringify(sg));
    await page.click('#tabs [data-tab=recruit]');
    const tid = await page.evaluate(() => offersList().sort((a, b) => teamLevel(b.id) - teamLevel(a.id))[0].id);
    await page.click(`[data-act=cask2][data-k="sign-${tid}"]`);
    const conf = await page.evaluate(() => document.activeElement && document.activeElement.dataset.act);
    await page.click(`[data-act=csign][data-id="${tid}"]`);
    const col = await page.evaluate(() => ({ lvl: cs.lvl, phase: cs.phase, tid: cs.col && cs.col.tid, nil: cs.col && cs.col.nil, tab: cui.tab }));
    check('signing takes a confirmation and starts the college career', conf === 'csign' && col.lvl === 'col' && col.phase === 'col' && col.tid === tid && col.tab === 'home', JSON.stringify(col));
    // every career tab renders
    const tabs = await page.evaluate(() => [...document.querySelectorAll('#tabs [data-act=ctab]')].map(b => b.dataset.tab));
    const empty = []; for (const t of tabs) { await page.click(`#tabs [data-tab="${t}"]`); const n = await page.evaluate(() => document.querySelector('#view').textContent.trim().length); if (n < 40) empty.push(t); }
    check('every Player Career tab renders', tabs.length >= 9 && !empty.length, tabs.join(',') + (empty.length ? ' empty: ' + empty : ''));
    // season, offseason, portal
    await page.evaluate(() => { cui.tab = 'home'; render(); cSimTo('season'); hideModal(); while (cs.event) { cResolveEvent(0); cSimTo('season'); hideModal(); } render(); });
    const off = await page.evaluate(() => ({ phase: cs.phase, steps: cs.off && cs.off.steps.join(','), review: !!document.querySelector('.offc') }));
    check('the college season ends in an offseason with review, portal and training steps', off.phase === 'coloff' && /review.*portal.*train/.test(off.steps) && off.review, JSON.stringify(off));
    await page.click('.offc [data-act=coffnext]');
    await page.click('[data-act=cportal]');
    await page.waitForSelector('#view [data-act=cpwait]'); await page.click('#view [data-act=cpwait]');
    const pt = await page.evaluate(() => Object.keys(cs.portal.offers).find(t => t !== cs.portal.from));
    await page.click(`[data-act=cask2][data-k="port-${pt}"]`); await page.click(`[data-act=cpcommit][data-id="${pt}"]`);
    const moved = await page.evaluate(() => ({ tid: cs.col.tid, tr: cs.col.transfers }));
    check('entering the portal, waiting a round and committing moves the player', moved.tid === pt && moved.tr === 1, JSON.stringify(moved));
    await page.click('#view [data-act=coffnext]'); await page.click('#hdr [data-act=coffnext]');
    check('the next season starts at the new school', await page.evaluate(() => cs.phase === 'col' && cs.week === 1 && cs.col.tid === cs.col.teams[1]));
    // the draft
    await page.evaluate(() => { cs.col.years = 4; cs.col.seasons = 3; cSimTo('season'); hideModal(); while (cs.event) { cResolveEvent(0); cSimTo('season'); hideModal(); } cui.tab = 'home'; render(); });
    await page.click('.offc [data-act=coffnext]');
    await page.waitForSelector('[data-act=cdraft][data-v=yes]'); await page.click('[data-act=cdraft][data-v=yes]');
    await page.waitForSelector('#modal:not([hidden])'); await page.click('#modal [data-act=close]');
    const dr = await page.evaluate(() => ({ phase: cs.phase, done: !!document.querySelector('.donec'), draft: cs.done && cs.done.draft }));
    check('declaring for the draft ends the career with a draft result and summary', dr.phase === 'done' && dr.done && !!dr.draft, JSON.stringify(dr.draft));
    // admin
    await page.click('#tabs [data-tab=admin]');
    await page.fill('[data-cadm="a:man"]', '99'); await page.dispatchEvent('[data-cadm="a:man"]', 'change');
    await page.selectOption('#cadmteam', 'UMASS'); await page.fill('[data-cadm="t:rating"]', '90'); await page.dispatchEvent('[data-cadm="t:rating"]', 'change');
    const adm = await page.evaluate(() => ({ man: cs.p.a.man, um: cs.league.teams.UMASS.rating }));
    check('admin edits personal ratings and team ratings', adm.man === 99 && adm.um === 90, JSON.stringify(adm));
    check('no page errors across a whole career', errors.length === 0, errors[0]);
    await ctx.close();
  }

  // ---------- five separate career slots, and AD slots untouched ----------
  {
    const { ctx, page, errors } = await fresh(browser);
    await createPlayer(page, { first: 'One', pos: 'QB', path: 'college', stars: 4 });
    await page.evaluate(() => cFlush());
    await page.click('#tabs [data-tab=saves]'); await page.click('[data-act=cnew][data-i="2"]');
    await page.fill('#cf-first', 'Two'); await page.click('[data-act=cstart]'); await page.waitForFunction(() => cs && cs.p.first === 'Two' && cslot === 2);
    await page.evaluate(() => cFlush());
    await page.click('#tabs [data-tab=saves]'); await page.click('[data-act=cload][data-i="1"]'); await page.waitForFunction(() => cs.p.first === 'One' && cui.tab === 'home');
    await page.click('#tabs [data-tab=saves]');
    const l1 = await page.evaluate(() => ({ n: cs.p.first, slot: cslot }));
    await page.click('[data-act=cask2][data-k="cdel-2"]'); await page.click('[data-act=cdel][data-i="2"]'); await sleep(200);
    const s = await page.evaluate(() => ({ s1: !!localStorage.getItem('mfpc-slot-1'), s2: !!localStorage.getItem('mfpc-slot-2'), ad: Object.keys(localStorage).filter(k => k.startsWith('mfad-slot-')).length, n: cs.p.first }));
    check('career slots load and delete independently', l1.n === 'One' && l1.slot === 1 && s.s1 && !s.s2 && s.n === 'One', JSON.stringify(s));
    check('Player Career never writes to the AD save slots', s.ad === 0);
    await page.click('#hdr [data-act=gohome]'); await page.waitForSelector('#view .modes');
    const hm = await page.evaluate(() => document.querySelectorAll('#view .mode')[1].textContent);
    check('the home screen shows the last player career', /One/.test(hm) && /1 of 5/.test(hm), hm.replace(/\s+/g, ' ').slice(0, 120));
    check('no page errors with several careers', errors.length === 0, errors[0]);
    await ctx.close();
  }

  // ---------- phone width ----------
  {
    const { ctx, page, errors } = await fresh(browser, { viewport: { width: 390, height: 844 } });
    const hw = await page.evaluate(() => document.documentElement.scrollWidth - innerWidth);
    await createPlayer(page, { first: 'Maximilian', last: 'Castellanos-Whitfield', pos: 'DE', path: 'college', stars: 5 });
    const widths = []; const bar = await page.evaluate(() => getComputedStyle(document.getElementById('mnav')).display);
    for (const t of ['home', 'player', 'schedule', 'stats', 'recruit', 'nil', 'team', 'league', 'settings', 'saves', 'admin']) { await page.evaluate(t => { cui.tab = t; render(); }, t); widths.push(await page.evaluate(() => document.documentElement.scrollWidth - innerWidth)); }
    const ov = await page.evaluate(() => { const b = [...document.querySelectorAll('#hdr .brand .wm span')].find(x => x.getClientRects().length).getBoundingClientRect(), t = document.querySelector('#hdr .tools').getBoundingClientRect(); return b.right > t.left && b.top < t.bottom && b.bottom > t.top; });
    check('no sideways scrolling on any career screen at phone width', hw <= 0 && widths.every(w => w <= 0) && bar !== 'none', widths.join(','));
    check('a long name doesn\'t run under the header buttons on a phone', !ov);
    check('no page errors at phone width', errors.length === 0, errors[0]);
    await ctx.close();
  }

  await browser.close();
  console.log(out.join('\n'));
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.log(out.join('\n')); console.error(e); process.exit(2); });
