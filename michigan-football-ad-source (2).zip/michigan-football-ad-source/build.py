# Builds the standalone single-file game (michigan-football-ad.html) from the source modules.
#   Engine, no DOM:      data.js (league data, seeded RNG, helpers), core.js (game sim, weeks,
#                        postseason), features.js (events, recruiting, offseason, migration),
#                        systems.js (season systems: carousel, deals, board, compliance, Auto-AD)
#   Persistence:         storage.js (save slots, save queue, loading, save codes)
#   Appearance:          theme.js (per-device theme, light/dark, navigation and motion preferences)
#   Player Career:       career.js (player, recruiting, NIL, league, college, portal, draft), cgame.js (games and snap decisions)
#   Rendering:           ui.js (views, dialogs, live game), admin.js (admin panel), cui.js (home screen, Player Career views)
#   Input and startup:   app.js (actions, event handlers, multi-season sim, AD boot), capp.js (home screen and career actions, startup)
#   python3 build.py [output.html]
import os, sys
here = os.path.dirname(os.path.abspath(__file__))
src = os.path.join(here, 'src') if os.path.isdir(os.path.join(here, 'src')) else here
FILES = ['data.js', 'core.js', 'features.js', 'systems.js', 'storage.js', 'theme.js', 'career.js', 'cgame.js', 'ui.js', 'admin.js', 'cui.js', 'app.js', 'capp.js']
out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, 'michigan-football-ad.html')
js = '\n'.join(open(os.path.join(src, f), encoding='utf-8').read() for f in FILES)
html = open(os.path.join(src, 'shell.html'), encoding='utf-8').read().replace('/*JS*/', js)
open(out, 'w', encoding='utf-8').write(html)
print('built', out, len(html), 'bytes')
